import type {
  PriceBar,
  AfterHoursWaveSettings,
  AnalysisResult,
  AnalysisStatus,
  Market,
  Timeframe,
  ExtendedQuote,
} from "@/types";
import { STATUS_LABELS_AR, DEFAULT_AFTER_HOURS_SETTINGS } from "@/types";
import { computeIndicators, calculateFibonacci, retracementPercent } from "@/lib/indicators";
import {
  avgVolume,
  percentChange,
  findSwingHigh,
  findSwingLow,
  emptyAnnotations,
  makeLevel,
  makeZone,
} from "./helpers";

export interface AfterHoursWaveInput {
  symbol: string;
  market: Market;
  timeframe: Timeframe;
  bars5m: PriceBar[];
  bars15m?: PriceBar[];
  bars4h?: PriceBar[];
  extended: ExtendedQuote | null;
  previousClose?: number | null;
  settings?: Partial<AfterHoursWaveSettings>;
  dataSource?: string;
  dataSourceTime?: string | null;
  /** minutes since regular session open; null if unknown */
  minutesSinceOpen?: number | null;
}

function base(
  input: AfterHoursWaveInput,
  status: AnalysisStatus,
  score: number | null,
  extras: Partial<AnalysisResult>,
): AnalysisResult {
  return {
    strategy: "after_hours_wave",
    symbol: input.symbol,
    market: input.market,
    timeframe: input.timeframe,
    status,
    statusLabel: STATUS_LABELS_AR[status],
    score,
    dataQuality: extras.dataQuality || "partial",
    lastUpdatedAt: new Date().toISOString(),
    dataSource: input.dataSource || "unknown",
    dataSourceTime: input.dataSourceTime ?? null,
    supportZones: extras.supportZones || [],
    resistanceLevels: extras.resistanceLevels || [],
    entryZones: extras.entryZones || [],
    stopLoss: extras.stopLoss ?? null,
    targets: extras.targets || [],
    indicators: extras.indicators || {},
    warnings: extras.warnings || [],
    explanation: extras.explanation || [],
    annotations: extras.annotations || emptyAnnotations(),
    meta: extras.meta,
  };
}

/**
 * after_hours_wave — pure strategy engine.
 * Requires real extended-hours data; never invents AH move.
 */
export function analyzeAfterHoursWave(
  input: AfterHoursWaveInput,
): AnalysisResult {
  const s: AfterHoursWaveSettings = {
    ...DEFAULT_AFTER_HOURS_SETTINGS,
    ...input.settings,
  };
  const bars = input.bars5m;
  const warnings: string[] = [];

  if (!input.extended || !input.extended.available) {
    return base(input, "AH_DATA_UNAVAILABLE", null, {
      dataQuality: "insufficient",
      warnings: [
        input.extended?.message ||
          "بيانات الأفتر/البري ماركت غير متوفرة من المصدر الحالي.",
      ],
      explanation: [
        "لا يمكن تحليل موجات ما بعد الإغلاق بدون بيانات الأفتر ماركت.",
      ],
    });
  }

  if (!bars || bars.length < 5) {
    return base(input, "INSUFFICIENT_DATA", null, {
      dataQuality: "insufficient",
      warnings: ["الشارت لا يحتوي على شموع كافية."],
      explanation: ["يلزم فريم 5 دقائق ببيانات كافية."],
    });
  }

  const prevClose =
    input.previousClose ??
    input.bars4h?.[input.bars4h.length - 2]?.close ??
    null;
  const ahPrice = input.extended.afterHoursPrice;

  if (ahPrice == null || prevClose == null || prevClose === 0) {
    return base(input, "AH_DATA_UNAVAILABLE", null, {
      dataQuality: "insufficient",
      warnings: ["تعذر حساب نسبة صعود الأفتر ماركت (ينقص سعر الإغلاق السابق أو سعر الأفتر)."],
      explanation: ["بيانات الأفتر ماركت غير مكتملة."],
    });
  }

  const ahMove = percentChange(prevClose, ahPrice);
  if (ahMove < s.minAfterHoursMovePercent) {
    return base(input, "AH_MOVE_INSUFFICIENT", Math.round(ahMove), {
      dataQuality: "good",
      explanation: [
        `صعود الأفتر ماركت: ${ahMove.toFixed(1)}%.`,
        `الحد الأدنى المطلوب: ${s.minAfterHoursMovePercent}%.`,
      ],
      meta: { ahMove, ahPrice, prevClose },
    });
  }

  const volAvg = avgVolume(bars, 20);
  const ahVol = input.extended.afterHoursVolume ?? 0;
  const volMult = volAvg > 0 ? ahVol / volAvg : 0;

  // If AH volume unknown, warn but don't fake it; use session volume proxy
  if (ahVol <= 0) {
    warnings.push("حجم الأفتر ماركت غير متوفر — التحقق من الحجم غير مكتمل.");
  } else if (volMult < s.minVolumeMultiplier) {
    return base(input, "VOLUME_INSUFFICIENT", Math.round(volMult * 20), {
      dataQuality: "good",
      warnings,
      explanation: [
        `مضاعف الحجم: ${volMult.toFixed(2)}× (المطلوب ≥ ${s.minVolumeMultiplier}×).`,
      ],
      meta: { volMult, ahVol, volAvg },
    });
  }

  const mins = input.minutesSinceOpen;
  if (mins != null && mins < s.premarketObservationMinutes) {
    return base(input, "WAITING_OBSERVATION_WINDOW", 30, {
      dataQuality: "good",
      warnings,
      explanation: [
        `مضى ${mins} دقيقة منذ الافتتاح.`,
        `نافذة الرصد: ${s.premarketObservationMinutes}–${s.premarketObservationMaxMinutes} دقيقة.`,
      ],
    });
  }

  // Wave 1: session start low → first impulsive high, then Wave 2 pullback.
  // Avoid treating a later Wave-3 high as Wave-1 by requiring a pullback after the peak.
  const w1Start = findSwingLow(bars, 0, Math.min(6, bars.length - 1));
  if (!w1Start) {
    return base(input, "WAVE_1_FORMING", 40, {
      dataQuality: "good",
      warnings,
      explanation: ["الموجة الأولى الصاعدة قيد التكوين."],
    });
  }

  let w1End: { index: number; price: number; time: string } | null = null;
  let w2: { index: number; price: number; time: string } | null = null;

  // Scan candidate peaks after start; pick first peak that is followed by a meaningful pullback
  const scanTo = Math.min(bars.length - 1, w1Start.index + 30);
  for (let peakIdx = w1Start.index + 1; peakIdx <= scanTo; peakIdx++) {
    const peakPrice = bars[peakIdx].high;
    // peak should be local-ish: higher than prior bar
    if (peakIdx > 0 && peakPrice < bars[peakIdx - 1].high) continue;
    if (peakPrice <= w1Start.price * 1.01) continue;

    // Look ahead for pullback low before a new high exceeds this peak
    let pullLow = peakPrice;
    let pullIdx = peakIdx;
    let foundPull = false;
    for (let j = peakIdx + 1; j < bars.length; j++) {
      if (bars[j].high > peakPrice * 1.002) break; // new high → wave3 territory
      if (bars[j].low < pullLow) {
        pullLow = bars[j].low;
        pullIdx = j;
      }
      const pullPct =
        peakPrice > w1Start.price
          ? ((peakPrice - pullLow) / (peakPrice - w1Start.price)) * 100
          : 0;
      if (pullPct >= s.wave2RetracementMinPercent * 0.5 && j > peakIdx + 1) {
        foundPull = true;
        // continue to find deepest pull before break
      }
    }
    if (foundPull && pullIdx > peakIdx) {
      w1End = {
        index: peakIdx,
        price: peakPrice,
        time: bars[peakIdx].barTime,
      };
      w2 = {
        index: pullIdx,
        price: pullLow,
        time: bars[pullIdx].barTime,
      };
      break;
    }
  }

  // Fallback: simple swing high in early window if structure not yet clear
  if (!w1End) {
    w1End = findSwingHigh(
      bars,
      w1Start.index,
      Math.min(bars.length - 1, w1Start.index + 12),
    );
  }

  if (!w1End || w1End.index <= w1Start.index) {
    return base(input, "WAVE_1_FORMING", 40, {
      dataQuality: "good",
      warnings,
      explanation: ["الموجة الأولى الصاعدة قيد التكوين."],
    });
  }

  const wave1Size = w1End.price - w1Start.price;
  if (wave1Size <= 0) {
    return base(input, "WAVE_1_FORMING", 35, {
      dataQuality: "partial",
      warnings,
      explanation: ["لم تكتمل الموجة الأولى بعد."],
    });
  }

  // Wave 2: pullback after wave 1 (if not already found)
  if (!w2) {
    const afterW1 = bars.slice(w1End.index);
    if (afterW1.length < 2) {
      return base(input, "WAVE_2_FORMING", 50, {
        dataQuality: "good",
        warnings,
        explanation: [
          "الموجة الأولى اكتملت مبدئياً.",
          "الموجة الثانية (التصحيح) قيد التكوين.",
        ],
        annotations: waveAnnotations(w1Start, w1End, null, null, null, bars),
      });
    }

    const w2Low = findSwingLow(afterW1, 0, afterW1.length - 1);
    if (!w2Low) {
      return base(input, "WAVE_2_FORMING", 52, {
        dataQuality: "good",
        warnings,
        explanation: ["تعذر تحديد قاع الموجة الثانية."],
      });
    }

    w2 = {
      index: w1End.index + w2Low.index,
      price: w2Low.price,
      time: w2Low.time,
    };
  }

  const retr = retracementPercent(w1End.price, w1Start.price, w2.price);
  // For upswing: retracementPercent uses high=w1End low=w1Start → 0 at high, 100 at low
  // Actually our fib helper: top=max, bottom=min, percent from top down.
  // Wave2 retracement of wave1: from w1End toward w1Start.
  const retrOfWave1 =
    wave1Size === 0
      ? null
      : ((w1End.price - w2.price) / wave1Size) * 100;

  const invalidFloor =
    w1Start.price * (1 - s.wave2InvalidationBufferPercent / 100);

  if (w2.price < invalidFloor) {
    return base(input, "FAILED_WAVE_2_BROKEN", 15, {
      dataQuality: "good",
      warnings,
      explanation: [
        "كُسر بداية الموجة الأولى — فشل النموذج.",
        `قاع الموجة الثانية ${w2.price.toFixed(4)} تحت ${invalidFloor.toFixed(4)}.`,
      ],
      annotations: waveAnnotations(w1Start, w1End, w2, null, null, bars),
    });
  }

  if (
    retrOfWave1 == null ||
    retrOfWave1 < s.wave2RetracementMinPercent
  ) {
    return base(input, "WAVE_2_FORMING", 55, {
      dataQuality: "good",
      warnings,
      explanation: [
        `تصحيح الموجة الثانية: ${retrOfWave1?.toFixed(1) ?? "—"}%.`,
        `النطاق المقبول: ${s.wave2RetracementMinPercent}%–${s.wave2RetracementMaxPercent}%.`,
      ],
      annotations: waveAnnotations(w1Start, w1End, w2, null, null, bars),
      meta: { retrOfWave1 },
    });
  }

  if (retrOfWave1 > s.wave2RetracementMaxPercent) {
    // Deep pullback but not invalidated
    warnings.push(
      `التصحيح عميق (${retrOfWave1.toFixed(1)}%) — أعلى من ${s.wave2RetracementMaxPercent}%.`,
    );
  }

  const indicators = computeIndicators(bars);
  const last = bars[bars.length - 1];
  const lastPrice = last.close;

  // Entry zone near wave 2 low / fib zone
  let fib = null;
  try {
    fib = calculateFibonacci(w1End.price, w1Start.price);
  } catch {
    /* ignore */
  }

  const entryLow = w2.price;
  const entryHigh = w2.price + wave1Size * 0.15;
  const entryZone = makeZone(
    "entry",
    "منطقة الدخول",
    entryLow,
    entryHigh,
    "entry",
  );

  const stop = makeLevel(
    "sl",
    "وقف الخسارة",
    w2.price * (1 - s.wave2InvalidationBufferPercent / 100),
    "stop",
    "dashed",
    "#d96a62",
  );

  const t1 = makeLevel(
    "t1",
    "الهدف الأول",
    w1End.price,
    "target",
    "solid",
    "#118476",
  );
  const t2 = makeLevel(
    "t2",
    "الهدف الثاني",
    w1End.price + wave1Size,
    "target",
    "solid",
    "#d6a441",
  );

  const r1 = w1End.price;
  const r2 = w1End.price + wave1Size * 0.5;

  // Wave 3 triggers
  const microHigh = findSwingHigh(bars, w2.index, bars.length - 1);
  const bounceFromFib =
    retrOfWave1 >= s.wave2RetracementMinPercent &&
    retrOfWave1 <= s.wave2RetracementMaxPercent &&
    lastPrice > w2.price * 1.01;

  const microBreak =
    microHigh != null &&
    lastPrice > microHigh.price * 0.998 &&
    microHigh.index > w2.index;

  const closeAboveTrigger =
    last.close > r1 && last.timeframe === "5m";

  const volOk = volAvg > 0 && last.volume > 0 && last.volume >= volAvg * s.wave3VolumeMultiplier;
  if (volAvg <= 0 || last.volume <= 0) warnings.push("بيانات الحجم غير متوفرة أو غير كافية لتأكيد الاختراق.");
  if (indicators.rsi14 == null) warnings.push("بيانات RSI 14 غير كافية — لن يُستخدم RSI كتأكيد.");

  // Higher TF agreement
  let htAgree = false;
  if (input.bars15m && input.bars15m.length > 5) {
    const last15 = input.bars15m[input.bars15m.length - 1];
    const prev15 = input.bars15m[input.bars15m.length - 2];
    htAgree = last15.close > prev15.close;
  }
  let h4Agree = false;
  if (input.bars4h && input.bars4h.length > 2) {
    const h4 = input.bars4h;
    h4Agree = h4[h4.length - 1].close > h4[h4.length - 2].close;
  }
  const multiTfConfirmed = htAgree && h4Agree;
  if (!input.bars15m || input.bars15m.length <= 5) warnings.push("بيانات 15 دقيقة غير كافية لتأكيد التصحيح والارتداد.");
  if (!input.bars4h || input.bars4h.length <= 2) warnings.push("بيانات 4 ساعات غير كافية لتأكيد الاتجاه العام.");

  const triggers = [
    bounceFromFib && "ارتداد واضح من منطقة فيبوناتشي",
    microBreak && "اختراق قمة صغيرة داخل التصحيح",
    closeAboveTrigger && "إغلاق 5 دقائق فوق المحفز",
    volOk && "حجم أعلى من المتوسط",
    multiTfConfirmed && "توافق فريمَي 15 دقيقة و4 ساعات",
  ].filter(Boolean) as string[];

  const explanation: string[] = [
    `صعود الأفتر ماركت: ${ahMove.toFixed(1)}%.`,
    `الموجة الأولى: من ${w1Start.price.toFixed(4)} إلى ${w1End.price.toFixed(4)}.`,
    `تصحيح الموجة الثانية عند ${retrOfWave1.toFixed(1)}% (قاع ${w2.price.toFixed(4)}).`,
    "قاع التصحيح لم يكسر بداية الموجة الأولى.",
  ];

  if (retr != null) {
    // quiet
  }
  if (fib) {
    const nearest = [38.2, 50, 61.8].map((x) => ({
      x,
      d: Math.abs(retrOfWave1 - x),
    }));
    nearest.sort((a, b) => a.d - b.d);
    if (nearest[0].d <= 5) {
      explanation.push(`التصحيح قرب فيبوناتشي ${nearest[0].x}%.`);
    }
  }

  let status: AnalysisStatus = "WAVE_2_DONE_WAVE_3_FORMING";
  let score = 70;

  if (!multiTfConfirmed) {
    status = "WAVE_2_DONE_WAVE_3_FORMING";
    score = 68;
    explanation.push("الموجة الثانية انتهت — الموجة الثالثة قيد التكوين.");
    explanation.push("الجاهزية: مثال مشروط للمراقبة فقط؛ يلزم توافق 15 دقيقة و4 ساعات.");
    explanation.push("المحفز المطلوب: إغلاق شمعة 5 دقائق فوق المقاومة الأولى مع حجم أعلى من المتوسط.");
  } else if (triggers.length === 0) {
    status = "WAVE_2_DONE_WAVE_3_FORMING";
    score = 72;
    explanation.push("الموجة الثالثة قيد التكوين — بانتظار محفز مؤكد.");
    explanation.push("انتهاء الموجة الثانية وحده لا يكفي لدخول.");
  } else if (triggers.length < 2) {
    status = "READY_CONDITIONAL_SIGNAL";
    score = 80;
    explanation.push("جاهز للمراقبة — إشارة مشروطة.");
    for (const t of triggers) explanation.push(`محفز: ${t}.`);
  } else {
    const brokeW1High = lastPrice > w1End.price;
    if (brokeW1High && closeAboveTrigger && volOk && multiTfConfirmed) {
      status = "WAVE_3_STARTED";
      score = 90;
      explanation.push("الموجة الثالثة بدأت — اختراق مؤكد.");
      for (const t of triggers) explanation.push(`محفز: ${t}.`);
    } else {
      status = "READY_CONDITIONAL_SIGNAL";
      score = 85;
      explanation.push("إشارة مشروطة — محفزات جزئية ظهرت.");
      for (const t of triggers) explanation.push(`محفز: ${t}.`);
    }
  }

  explanation.push("تحليل فني فقط — ليست توصية تداول.");

  const ann = waveAnnotations(w1Start, w1End, w2, entryZone, { stop, t1, t2 }, bars);
  if (fib) {
    ann.fibonacci = {
      highPrice: fib.high,
      lowPrice: fib.low,
      highTime: w1End.time,
      lowTime: w1Start.time,
      levels: fib.levels.map((l) => l.ratio),
    };
    // الشارت: نسب مختصرة فقط 38.2 / 50 / 61.8
    const main = new Set([0.236, 0.382, 0.5, 0.618, 0.786]);
    for (const lvl of fib.levels) {
      if (!main.has(lvl.ratio)) continue;
      const pct = (lvl.ratio * 100).toFixed(1).replace(/\.0$/, "");
      ann.levels.push(
        makeLevel(
          `fib-${lvl.ratio}`,
          `${pct}%`,
          lvl.price,
          "fibonacci",
          "dashed",
          "#a78bfa",
        ),
      );
    }
  }
  ann.levels.push(
    makeLevel("r1", "المقاومة الأولى", r1, "resistance", "solid", "#d96a62"),
  );
  ann.levels.push(
    makeLevel("r2", "المقاومة الثانية", r2, "resistance", "solid", "#d6a441"),
  );

  // Projected wave 3 dashed arrow marker
  ann.markers.push({
    id: "w3-proj",
    time: last.barTime,
    price: (entryZone.priceLow + entryZone.priceHigh) / 2,
    label: "③",
    shape: "arrowUp",
  });

  if (indicators.ema20)
    ann.levels.push(
      makeLevel("ema20", "EMA 20", indicators.ema20, "ema", "solid", "#3b82f6"),
    );
  if (indicators.vwap)
    ann.levels.push(
      makeLevel("vwap", "VWAP", indicators.vwap, "vwap", "dotted", "#94a3b8"),
    );

  return base(input, status, score, {
    dataQuality: warnings.length ? "partial" : "good",
    supportZones: [
      makeZone("w2-sup", "الدعم الثانوي — قاع الموجة 2", w2.price * 0.995, w2.price * 1.005, "support"),
    ],
    resistanceLevels: [
      makeLevel("r1", "المقاومة الأولى", r1, "resistance", "solid", "#d96a62"),
      makeLevel("r2", "المقاومة الثانية", r2, "resistance", "solid", "#d6a441"),
    ],
    entryZones: [entryZone],
    stopLoss: stop,
    targets: [t1, t2],
    indicators: {
      ema20: indicators.ema20,
      ema30: indicators.ema30,
      ema50: indicators.ema50,
      rsi14: indicators.rsi14,
      vwap: indicators.vwap,
    },
    warnings,
    explanation,
    annotations: ann,
    meta: {
      ahMove,
      retrOfWave1,
      triggers,
      wave1: { start: w1Start.price, end: w1End.price },
      wave2: w2.price,
      statusColor:
        status === "WAVE_3_STARTED"
          ? "confirmed"
          : status === "READY_CONDITIONAL_SIGNAL"
            ? "conditional"
            : "forming",
    },
  });
}

function waveAnnotations(
  w1Start: { index: number; price: number; time: string },
  w1End: { index: number; price: number; time: string },
  w2: { index: number; price: number; time: string } | null,
  entry: ReturnType<typeof makeZone> | null,
  levels: {
    stop: ReturnType<typeof makeLevel>;
    t1: ReturnType<typeof makeLevel>;
    t2: ReturnType<typeof makeLevel>;
  } | null,
  bars: PriceBar[],
) {
  const ann = emptyAnnotations();
  // Exactly one first-wave label, at the end of wave 1.
  ann.markers.push({
    id: "w1e",
    time: w1End.time,
    price: w1End.price,
    label: "①",
    shape: "circle",
  });
  if (w2) {
    ann.markers.push({
      id: "w2",
      time: w2.time,
      price: w2.price,
      label: "②",
      shape: "circle",
    });
  }
  if (entry) ann.zones.push(entry);
  if (levels) {
    ann.levels.push(levels.stop, levels.t1, levels.t2);
  }
  return ann;
}
