import { describe, it, expect } from "vitest";
import { analyzeWeeklyChannel } from "./weekly-channel";
import type { PriceBar, MarketCap } from "@/types";

function day(
  i: number,
  open: number,
  high: number,
  low: number,
  close: number,
): PriceBar {
  const d = new Date(Date.UTC(2024, 0, 1));
  d.setUTCDate(d.getUTCDate() + i);
  return {
    timeframe: "1d",
    barTime: d.toISOString(),
    open,
    high,
    low,
    close,
    volume: 1_000_000,
    vwap: null,
    source: "test",
  };
}

function channelBars(): PriceBar[] {
  // Oscillate between ~6 support and ~9 resistance
  const bars: PriceBar[] = [];
  for (let i = 0; i < 60; i++) {
    const phase = Math.sin(i / 5);
    const mid = 7.5;
    const amp = 1.4;
    const c = mid + phase * amp;
    bars.push(day(i, c - 0.1, c + 0.35, c - 0.35, c));
  }
  return bars;
}

const bigCap: MarketCap = {
  symbol: "CH",
  market: "US",
  marketCap: 5_000_000_000,
  currency: "USD",
  asOf: new Date().toISOString(),
  source: "test",
};

describe("weekly_price_channel", () => {
  it("INSUFFICIENT_DATA with few bars", () => {
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: [day(0, 7, 7.2, 6.8, 7)],
      marketCap: bigCap,
    });
    expect(r.status).toBe("INSUFFICIENT_DATA");
  });

  it("PRICE_OUT_OF_RANGE below min", () => {
    const bars = channelBars().map((b) => ({
      ...b,
      open: 2,
      high: 2.2,
      low: 1.8,
      close: 2,
    }));
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: bars,
      marketCap: bigCap,
      lastPrice: 2,
    });
    expect(r.status).toBe("PRICE_OUT_OF_RANGE");
  });

  it("MARKET_CAP_UNAVAILABLE when null", () => {
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: channelBars(),
      marketCap: null,
      lastPrice: 7.5,
    });
    expect(r.status).toBe("MARKET_CAP_UNAVAILABLE");
    expect(r.warnings.some((w) => w.includes("السوقية"))).toBe(true);
  });

  it("detects channel for large-cap in range", () => {
    const bars = channelBars();
    const last = bars[bars.length - 1].close;
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: bars,
      marketCap: bigCap,
      lastPrice: last,
      settings: { minPrice: 5, maxPrice: 10, channelTouchCount: 2 },
    });
    expect([
      "CHANNEL_UNCLEAR",
      "NEAR_SUPPORT",
      "POSSIBLE_BOUNCE",
      "MID_CHANNEL",
      "NEAR_RESISTANCE",
      "RESISTANCE_BREAKOUT",
      "SUPPORT_BROKEN",
      "TARGET_HIT",
    ]).toContain(r.status);
    expect(r.explanation.length).toBeGreaterThan(0);
  });

  it("SUPPORT_BROKEN when price crushes channel", () => {
    const bars = channelBars();
    bars.push(day(61, 5.5, 5.6, 4.0, 4.2));
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: bars,
      marketCap: bigCap,
      lastPrice: 4.2,
      settings: { minPrice: 1, maxPrice: 20 },
    });
    // price 4.2 may be out of default 5-10 — use wide range
    if (r.status !== "PRICE_OUT_OF_RANGE") {
      expect(
        ["SUPPORT_BROKEN", "CHANNEL_UNCLEAR", "NEAR_SUPPORT"].includes(
          r.status,
        ),
      ).toBe(true);
    }
  });

  it("rejects low market cap", () => {
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: channelBars(),
      marketCap: { ...bigCap, marketCap: 1_000 },
      lastPrice: 7,
      settings: { minMarketCap: 1_000_000_000 },
    });
    expect(r.warnings.length + r.explanation.length).toBeGreaterThan(0);
  });

  it("target 3 is above resistance — never under support", () => {
    const bars = channelBars();
    const last = bars[bars.length - 1].close;
    const r = analyzeWeeklyChannel({
      symbol: "X",
      market: "US",
      timeframe: "1d",
      barsDaily: bars,
      marketCap: bigCap,
      lastPrice: last,
      settings: { minPrice: 5, maxPrice: 10, channelTouchCount: 2 },
    });
    if (r.targets.length >= 3 && r.supportZones.length) {
      const [t1, t2, t3] = r.targets;
      const support = r.supportZones[0].priceHigh;
      const resistance =
        r.resistanceLevels[0]?.price ?? t2.price;
      expect(t1.price).toBeGreaterThan(support * 0.98);
      expect(t2.price).toBeGreaterThanOrEqual(t1.price * 0.99);
      expect(t3.price).toBeGreaterThan(t2.price);
      expect(t3.price).toBeGreaterThan(resistance);
      // never under support
      expect(t3.price).toBeGreaterThan(support);
    }
  });
});
