import type {
  PriceBar,
  CorporateAction,
  ReverseSplitSettings,
  AnalysisResult,
  AnalysisStatus,
  Market,
  Timeframe,
} from "@/types";
import { STATUS_LABELS_AR, DEFAULT_REVERSE_SPLIT_SETTINGS } from "@/types";
import { computeIndicators } from "@/lib/indicators";
import { calculateFibonacci } from "@/lib/indicators/fibonacci";
import {
  avgVolume,
  percentChange,
  findSwingHigh,
  findSwingLow,
  findTroughs,
  emptyAnnotations,
  makeLevel,
  makeZone,
  uniqueSessionDays,
  barsPerSessionDay,
  shortFibLabel,
  indexOnOrAfter,
} from "./helpers";

export interface ReverseSplitInput {
  symbol: string;
  market: Market;
  timeframe: Timeframe;
  bars: PriceBar[];
  reverseSplits: CorporateAction[];
  settings?: Partial<ReverseSplitSettings>;
  dataSource?: string;
  dataSourceTime?: string | null;
}

function resultBase(
  input: ReverseSplitInput,
  status: AnalysisStatus,
  score: number | null,
  extras: Partial<AnalysisResult>,
): AnalysisResult {
  return {
    strategy: "reverse_split_support",
    symbol: input.symbol,
    market: input.market,
    timeframe: input.timeframe,
    status,
    statusLabel: STATUS_LABELS_AR[status],
    score,
    dataQuality: extras.dataQuality || "partial",
    lastUpdatedAt: new Date().toISOString(),
    dataSource: input.dataSource || "unknown",
    dataSourceTime: input.dataSourceTime ?? null,
    supportZones: extras.supportZones || [],
    resistanceLevels: extras.resistanceLevels || [],
    entryZones: extras.entryZones || [],
    stopLoss: extras.stopLoss ?? null,
    targets: extras.targets || [],
    indicators: extras.indicators || {},
    warnings: extras.warnings || [],
    explanation: extras.explanation || [],
    annotations: extras.annotations || emptyAnnotations(),
    meta: extras.meta,
  };
}

/**
 * reverse_split_support strategy engine — pure function, no I/O.
 */
export function analyzeReverseSplit(input: ReverseSplitInput): AnalysisResult {
  const s: ReverseSplitSettings = {
    ...DEFAULT_REVERSE_SPLIT_SETTINGS,
    ...input.settings,
  };
  const bars = input.bars;
  const warnings: string[] = [];

  if (!bars || bars.length < 10) {
    return resultBase(input, "INSUFFICIENT_DATA", null, {
      dataQuality: "insufficient",
      warnings: ["الشارت لا يحتوي على شموع كافية."],
      explanation: ["عدد الشموع المتوفرة أقل من الحد الأدنى للتحليل."],
    });
  }

  const confirmed = (input.reverseSplits || []).filter(
    (a) => a.actionType === "reverse_split" && a.isConfirmed,
  );

  if (confirmed.length === 0) {
    return resultBase(input, "SPLIT_DATA_UNAVAILABLE", null, {
      dataQuality: "insufficient",
      warnings: ["بيانات التقسيم غير متوفرة."],
      explanation: [
        "لا يوجد تقسيم عكسي مؤكد في البيانات المصدر.",
        "لا تُنتج إشارة فنية بدون تأكيد التقسيم.",
      ],
    });
  }

  const split = confirmed.sort((a, b) =>
    b.actionDate.localeCompare(a.actionDate),
  )[0];

  const splitIdx = indexOnOrAfter(bars, split.actionDate);
  if (splitIdx < 0) {
    return resultBase(input, "SPLIT_DATA_UNAVAILABLE", null, {
      dataQuality: "insufficient",
      warnings: ["بيانات التقسيم غير متوفرة ضمن نطاق الشموع."],
      explanation: [
        `تاريخ التقسيم ${split.actionDate} خارج نطاق البيانات السعرية.`,
      ],
    });
  }

  // عدّ الجلسات بأيام التداول الفريدة — يعمل على 1d و 4h بنفس المنطق
  const bps = barsPerSessionDay(input.timeframe, bars);
  const sessionsAfter = uniqueSessionDays(bars, splitIdx);
  const barCountAfter = bars.length - splitIdx;

  if (
    sessionsAfter < s.splitLookbackMinSessions ||
    sessionsAfter > s.splitLookbackMaxSessions
  ) {
    return resultBase(input, "OUTSIDE_SESSION_WINDOW", null, {
      dataQuality: "good",
      explanation: [
        `عدد الجلسات (أيام التداول) منذ التقسيم: ${sessionsAfter}.`,
        `النطاق المطلوب: ${s.splitLookbackMinSessions}–${s.splitLookbackMaxSessions} جلسة.`,
        input.timeframe === "4h"
          ? `الفريم الحالي 4 ساعات · ${barCountAfter} شمعة ≈ ${sessionsAfter} جلسة.`
          : `الفريم: ${input.timeframe}.`,
      ],
      meta: {
        sessionsAfter,
        barCountAfter,
        barsPerSession: bps,
        timeframe: input.timeframe,
        splitDate: split.actionDate,
      },
      annotations: {
        levels: [
          makeLevel(
            "split",
            "التقسيم العكسي",
            bars[splitIdx].open,
            "split",
            "dashed",
            "#d6a441",
          ),
        ],
        zones: [],
        markers: [
          {
            id: "split-m",
            time: bars[splitIdx].barTime,
            price: bars[splitIdx].open,
            label: "تقسيم عكسي",
            shape: "square",
          },
        ],
      },
    });
  }

  const post = bars.slice(splitIdx);
  const openAfterSplit = post[0].open;

  // نافذة القمة الأولى: ~10–15 جلسة يومية → تُحوَّل لشموع حسب الفريم
  const rallyWindow = Math.min(
    Math.max(8, Math.round(12 * bps)),
    post.length - 1,
  );
  const peak = findSwingHigh(post, 0, rallyWindow);
  if (!peak) {
    return resultBase(input, "INSUFFICIENT_DATA", null, {
      dataQuality: "partial",
      warnings: ["تعذر تحديد القمة الأولى بعد التقسيم."],
      explanation: ["بيانات غير كافية لتحديد القمة الأولى."],
    });
  }

  const rallyPct = percentChange(openAfterSplit, peak.price);

  if (rallyPct < s.initialRallyMinPercent) {
    return resultBase(input, "INITIAL_RALLY_NOT_MET", Math.round(rallyPct), {
      dataQuality: "good",
      explanation: [
        `الارتفاع الأولي من افتتاح ما بعد التقسيم: ${rallyPct.toFixed(1)}%.`,
        `المطلوب بين ${s.initialRallyMinPercent}% و ${s.initialRallyMaxPercent}%.`,
      ],
      meta: { openAfterSplit, peakPrice: peak.price, rallyPct },
    });
  }

  // Decline from peak to subsequent low
  const afterPeak = post.slice(peak.index);
  if (afterPeak.length < 3) {
    return resultBase(input, "DECLINE_FORMING", 20, {
      dataQuality: "partial",
      explanation: ["الهبوط اللاحق ما زال قيد التكوين — شموع غير كافية بعد القمة."],
    });
  }

  const trough = findSwingLow(afterPeak, 0, afterPeak.length - 1);
  if (!trough) {
    return resultBase(input, "DECLINE_FORMING", 25, {
      dataQuality: "partial",
      explanation: ["لم يُحدد قاع واضح بعد القمة الأولى."],
    });
  }

  // Map trough index back to post array
  const troughPostIdx = peak.index + trough.index;
  const declinePct = -percentChange(peak.price, trough.price); // positive = drop

  if (declinePct < s.declineMinPercent) {
    return resultBase(input, "DECLINE_FORMING", Math.min(40, Math.round(declinePct)), {
      dataQuality: "good",
      explanation: [
        `الهبوط من القمة: ${declinePct.toFixed(1)}%.`,
        `المطلوب بين ${s.declineMinPercent}% و ${s.declineMaxPercent}%.`,
      ],
      meta: { peakPrice: peak.price, troughPrice: trough.price, declinePct },
      annotations: buildAnnotations({
        bars: post,
        splitIdx: 0,
        openAfterSplit,
        peak,
        trough: { ...trough, index: troughPostIdx },
        support: null,
        higherLow: null,
        resistance1: null,
        resistance2: null,
        entries: [],
        targets: [],
        stop: null,
        fib: null,
      }),
    });
  }

  // Support zone around trough
  const supportCenter = trough.price;
  const tol = (s.supportTolerancePercent / 100) * supportCenter;
  const supportLow = supportCenter - tol;
  const supportHigh = supportCenter + tol;

  // Count consecutive-ish sessions holding above support low near zone
  let supportSessions = 0;
  let supportBroken = false;
  const fromSupport = troughPostIdx;
  for (let i = fromSupport; i < post.length; i++) {
    if (post[i].close < supportLow) {
      if (i > fromSupport + 2) {
        supportBroken = true;
        break;
      }
    }
    if (post[i].low <= supportHigh && post[i].low >= supportLow * 0.98) {
      supportSessions += 1;
    } else if (post[i].low > supportHigh) {
      // price lifted off support — still count as holding if not broken
      supportSessions += 1;
    }
  }

  // عدّ أيام ثبات الدعم (جلسات) وليس مجرد عدد الشموع — مهم جداً على 4h
  supportBroken = false;
  const holdDayKeys: string[] = [];
  const seenDays = new Set<string>();
  for (let i = fromSupport; i < post.length; i++) {
    if (post[i].close < supportLow) {
      supportBroken = true;
      break;
    }
    const day = post[i].barTime.slice(0, 10);
    if (!seenDays.has(day)) {
      seenDays.add(day);
      holdDayKeys.push(day);
    }
  }
  supportSessions = holdDayKeys.length;
  // الحد الأدنى للشموع على الفريم اللحظي لضمان عدم احتساب يوم واحد بشموع قليلة
  const minSupportBars = Math.max(s.supportSessions, Math.round(s.supportSessions * bps * 0.6));
  const barsHeld = supportBroken
    ? 0
    : post.length - fromSupport;
  if (!supportBroken && barsHeld < minSupportBars && supportSessions >= s.supportSessions) {
    // أيام كافية نظرياً لكن شموع قليلة — أبقِ الحالة قيد التكوين
    supportSessions = Math.min(supportSessions, s.supportSessions - 1);
  }

  const indicators = computeIndicators(bars);
  const lastPrice = post[post.length - 1].close;

  if (supportBroken && lastPrice < supportLow) {
    return resultBase(input, "PATTERN_FAILED_SUPPORT_BROKEN", 10, {
      dataQuality: "good",
      indicators: snapIndicators(indicators),
      warnings: ["كُسر الدعم المؤكد سابقاً."],
      explanation: [
        "النموذج فشل — الإغلاق تحت منطقة الدعم.",
        `الدعم عند ${supportCenter.toFixed(4)}.`,
      ],
      supportZones: [
        makeZone("sup", "الدعم الرئيسي", supportLow, supportHigh, "support"),
      ],
      annotations: buildAnnotations({
        bars: post,
        splitIdx: 0,
        openAfterSplit,
        peak,
        trough: { ...trough, index: troughPostIdx },
        support: { low: supportLow, high: supportHigh, sessions: supportSessions },
        higherLow: null,
        resistance1: null,
        resistance2: null,
        entries: [],
        targets: [],
        stop: null,
        fib: null,
      }),
    });
  }

  if (supportSessions < s.supportSessions) {
    return resultBase(input, "SUPPORT_FORMING", 45, {
      dataQuality: "good",
      indicators: snapIndicators(indicators),
      explanation: [
        `جلسات الثبات عند الدعم: ${supportSessions} من ${s.supportSessions} مطلوبة.`,
        `منطقة الدعم: ${supportLow.toFixed(4)} – ${supportHigh.toFixed(4)}.`,
      ],
      supportZones: [
        makeZone("sup", "الدعم الرئيسي", supportLow, supportHigh, "support"),
      ],
      annotations: buildAnnotations({
        bars: post,
        splitIdx: 0,
        openAfterSplit,
        peak,
        trough: { ...trough, index: troughPostIdx },
        support: { low: supportLow, high: supportHigh, sessions: supportSessions },
        higherLow: null,
        resistance1: null,
        resistance2: null,
        entries: [],
        targets: [],
        stop: null,
        fib: null,
      }),
      meta: { supportSessions, supportCenter },
    });
  }

  // Support confirmed — look for higher low and resistances
  const afterSupport = post.slice(fromSupport);
  const localTroughs = findTroughs(afterSupport, 1, 1);
  // Preserve the two-stage base: first low / second retest low, even before
  // the second one qualifies as a higher low.
  const secondLow = localTroughs.length >= 2
    ? {
        index: fromSupport + localTroughs[1].index,
        price: localTroughs[1].price,
        time: localTroughs[1].time,
      }
    : localTroughs.length === 1
      ? {
          index: fromSupport + localTroughs[0].index,
          price: localTroughs[0].price,
          time: localTroughs[0].time,
        }
      : null;
  let higherLow: { index: number; price: number; time: string } | null = null;
  if (localTroughs.length >= 2) {
    const first = localTroughs[0];
    for (let i = 1; i < localTroughs.length; i++) {
      const hlPct = percentChange(first.price, localTroughs[i].price);
      if (hlPct >= s.higherLowMinPercent) {
        higherLow = {
          index: fromSupport + localTroughs[i].index,
          price: localTroughs[i].price,
          time: localTroughs[i].time,
        };
        break;
      }
    }
  }

  // Resistances: peaks between trough and now
  const peak1 = findSwingHigh(post, troughPostIdx, post.length - 1);
  let resistance1 = peak1 && peak1.price > supportHigh ? peak1.price : peak.price * 0.7;
  let resistance2 = peak.price * 0.85;

  // Fib from peak to support trough
  let fib = null;
  try {
    fib = calculateFibonacci(peak.price, trough.price);
    resistance1 = fib.prices["50"] ?? resistance1;
    resistance2 = fib.prices["23.6"] ?? resistance2;
  } catch {
    warnings.push("تعذر حساب فيبوناتشي.");
  }

  const entry1 = makeZone(
    "e1",
    "منطقة الدخول 1 — قرب الدعم",
    supportLow,
    supportHigh,
    "entry",
  );
  const entry2 = higherLow
    ? makeZone(
        "e2",
        "منطقة الدخول 2 — بعد قاع أعلى",
        higherLow.price * 0.99,
        higherLow.price * 1.02,
        "entry",
      )
    : null;

  const stop = makeLevel(
    "sl",
    "وقف الخسارة",
    supportLow * 0.97,
    "stop",
    "dashed",
    "#d96a62",
  );

  const t1Price = resistance1;
  const t2Price = resistance2;
  const t3Price = openAfterSplit; // first day open / 100% area

  const targets = [
    makeLevel("t1", "الهدف الأول", t1Price, "target", "solid", "#118476"),
    makeLevel("t2", "الهدف الثاني", t2Price, "target", "solid", "#d6a441"),
    makeLevel("t3", "الهدف الثالث", t3Price, "target", "solid", "#7c5cbf"),
  ];

  // Breakout check
  const recent = post.slice(-3);
  const volAvg = avgVolume(post, 20);
  const breakoutVol =
    recent.some((b) => b.volume >= volAvg * s.breakoutVolumeMultiplier);
  const brokeResistance = recent.some((b) => b.close > resistance1);

  let status: AnalysisStatus = "SUPPORT_CONFIRMED";
  let score = 60;
  const explanation: string[] = [
    `تقسيم عكسي مؤكد بتاريخ ${split.actionDate}.`,
    `القاع الأول بعد الهبوط: ${trough.price.toFixed(4)}.`,
    ...(secondLow
      ? [`إعادة اختبار القاع الثاني: ${secondLow.price.toFixed(4)}${secondLow.price >= trough.price ? " — قاع أعلى" : " — دون القاع الأول"}.`]
      : ["القاع الثاني / إعادة الاختبار لم يتأكد بعد." ]),
    `أقرب مقاومة: ${resistance1.toFixed(4)}${lastPrice >= resistance1 * 0.98 && lastPrice <= resistance1 * 1.02 ? " — السعر يختبرها الآن" : ""}.`,
    ...(lastPrice <= supportHigh * 1.03 && lastPrice >= supportLow * 0.97
      ? ["السعر يعيد اختبار منطقة القاع/الدعم الرئيسي."]
      : []),
    `الفريم: ${input.timeframe === "4h" ? "4 ساعات" : input.timeframe === "1d" ? "يومي" : input.timeframe === "1w" ? "أسبوعي" : input.timeframe}.`,
    `الجلسات (أيام التداول) منذ التقسيم: ${sessionsAfter} · الشموع: ${barCountAfter}.`,
    `الارتفاع الأولي: ${rallyPct.toFixed(1)}%.`,
    `الهبوط من القمة: ${declinePct.toFixed(1)}%.`,
    `أيام ثبات الدعم: ${supportSessions} (المطلوب ${s.supportSessions}).`,
  ];
  if (input.timeframe === "4h") {
    explanation.push(
      "تحليل فريم 4 ساعات نشط — القمة/القاع/الدعم/الاختراق محسوبة على شموع 4 ساعات مع عدّ الجلسات بالأيام.",
    );
  }

  if (lastPrice > supportHigh && lastPrice < resistance1) {
    status = "TESTING_RESISTANCE_1";
    score = 68;
    explanation.push("السعر يختبر المقاومة الأولى.");
  }

  if (higherLow) {
    status = "HIGHER_LOW_POSSIBLE";
    score = 75;
    explanation.push(
      `قاع أعلى عند ${higherLow.price.toFixed(4)} (+${percentChange(trough.price, higherLow.price).toFixed(1)}%).`,
    );
  }

  if (higherLow && !brokeResistance) {
    status = "BREAKOUT_PENDING";
    score = 80;
    explanation.push("اختراق المقاومة قيد الانتظار.");
  }

  if (brokeResistance) {
    if (breakoutVol) {
      status = "PATTERN_COMPLETE";
      score = 90;
      explanation.push("اختراق المقاومة مع حجم مرتفع — النموذج مكتمل فنياً.");
      explanation.push("إشارة مشروطة — تحليل فني فقط، ليست توصية تداول.");
    } else {
      status = "BREAKOUT_PENDING";
      score = 78;
      explanation.push("اختراق سعري دون تأكيد حجم كافٍ.");
      warnings.push("الحجم غير كافٍ لتأكيد الاختراق.");
    }
  }

  if (indicators.rsi14 != null) {
    explanation.push(`RSI(14) = ${indicators.rsi14.toFixed(1)}.`);
    if (indicators.rsiExitOversold) {
      explanation.push("خروج RSI من منطقة التشبع البيعي.");
      score = Math.min(100, score + 3);
    }
    if (indicators.rsiHigherLow) {
      explanation.push("قاع أعلى في RSI.");
      score = Math.min(100, score + 3);
    }
  }

  const entryZones = [entry1, entry2].filter(Boolean) as typeof entry1[];
  if (brokeResistance && breakoutVol) {
    entryZones.push(
      makeZone(
        "e3",
        "منطقة الدخول 3 — إعادة اختبار المقاومة",
        resistance1 * 0.98,
        resistance1 * 1.01,
        "entry",
      ),
    );
  }

  const annotations = buildAnnotations({
    bars: post,
    splitIdx: 0,
    openAfterSplit,
    peak,
    trough: { ...trough, index: troughPostIdx },
    secondLow,
    support: { low: supportLow, high: supportHigh, sessions: supportSessions },
    higherLow,
    resistance1,
    resistance2,
    entries: entryZones,
    targets,
    stop,
    fib,
  });

  // Add EMA levels
  if (indicators.ema20 != null) {
    annotations.levels.push(
      makeLevel("ema20", "EMA 20", indicators.ema20, "ema", "solid", "#3b82f6"),
    );
  }
  if (indicators.ema30 != null) {
    annotations.levels.push(
      makeLevel("ema30", "EMA 30", indicators.ema30, "ema", "solid", "#d6a441"),
    );
  }
  if (indicators.ema50 != null) {
    annotations.levels.push(
      makeLevel("ema50", "EMA 50", indicators.ema50, "ema", "solid", "#7c5cbf"),
    );
  }
  if (indicators.vwap != null) {
    annotations.levels.push(
      makeLevel("vwap", "VWAP", indicators.vwap, "vwap", "dotted", "#94a3b8"),
    );
  }

  return resultBase(input, status, score, {
    dataQuality: "good",
    supportZones: [
      makeZone("sup", "الدعم الرئيسي", supportLow, supportHigh, "support"),
    ],
    resistanceLevels: [
      makeLevel("r1", "المقاومة الأولى", resistance1, "resistance", "solid", "#d96a62"),
      makeLevel("r2", "المقاومة الثانية", resistance2, "resistance", "solid", "#d6a441"),
    ],
    entryZones,
    stopLoss: stop,
    targets,
    indicators: snapIndicators(indicators),
    warnings,
    explanation,
    annotations,
    meta: {
      splitDate: split.actionDate,
      sessionsAfter,
      barCountAfter,
      barsPerSession: bps,
      timeframe: input.timeframe,
      openAfterSplit,
      peakPrice: peak.price,
      rallyPct,
      declinePct,
      supportSessions,
      supportCenter,
      fourHourAnalysis: input.timeframe === "4h",
    },
  });
}

function snapIndicators(
  ind: ReturnType<typeof computeIndicators>,
): Record<string, number | null> {
  return {
    ema20: ind.ema20,
    ema30: ind.ema30,
    ema50: ind.ema50,
    rsi14: ind.rsi14,
    vwap: ind.vwap,
  };
}

function buildAnnotations(p: {
  bars: PriceBar[];
  splitIdx: number;
  openAfterSplit: number;
  peak: { index: number; price: number; time: string };
  trough: { index: number; price: number; time: string };
  secondLow?: { index: number; price: number; time: string } | null;
  support: { low: number; high: number; sessions: number } | null;
  higherLow: { index: number; price: number; time: string } | null;
  resistance1: number | null;
  resistance2: number | null;
  entries: ReturnType<typeof makeZone>[];
  targets: ReturnType<typeof makeLevel>[];
  stop: ReturnType<typeof makeLevel> | null;
  fib: ReturnType<typeof calculateFibonacci> | null;
}) {
  const ann = emptyAnnotations();
  ann.levels.push(
    makeLevel("split-open", "افتتاح ما بعد التقسيم", p.openAfterSplit, "split", "dashed", "#d6a441"),
  );
  ann.levels.push(
    makeLevel("peak1", "القمة الأولى", p.peak.price, "resistance", "solid", "#e11d48"),
  );
  ann.markers.push({
    id: "peak-m",
    time: p.peak.time,
    price: p.peak.price,
    label: "القمة الأولى",
    shape: "arrowDown",
  });
  ann.markers.push({
    id: "trough-m",
    time: p.trough.time,
    price: p.trough.price,
    label: "القاع الأول",
    shape: "arrowUp",
  });

  if (p.support) {
    ann.zones.push(
      makeZone("sup-z", `الدعم الرئيسي (${p.support.sessions} جلسات)`, p.support.low, p.support.high, "support"),
    );
  }
  if (p.secondLow && p.secondLow.time !== p.trough.time) {
    ann.markers.push({
      id: "second-low-m",
      time: p.secondLow.time,
      price: p.secondLow.price,
      label: "القاع الثاني",
      shape: "arrowUp",
    });
  }
  if (p.higherLow) {
    ann.markers.push({
      id: "hl-m",
      time: p.higherLow.time,
      price: p.higherLow.price,
      label: "قاع أعلى",
      shape: "arrowUp",
    });
  }
  if (p.resistance1 != null) {
    ann.levels.push(
      makeLevel("r1", "المقاومة الأولى", p.resistance1, "resistance", "solid", "#d96a62"),
    );
  }
  if (p.resistance2 != null) {
    ann.levels.push(
      makeLevel("r2", "المقاومة الثانية", p.resistance2, "resistance", "solid", "#d6a441"),
    );
  }
  for (const e of p.entries) ann.zones.push(e);
  for (const t of p.targets) ann.levels.push(t);
  if (p.stop) ann.levels.push(p.stop);

  if (p.fib) {
    ann.fibonacci = {
      highPrice: p.fib.high,
      lowPrice: p.fib.low,
      highTime: p.peak.time,
      lowTime: p.trough.time,
      levels: p.fib.levels.map((l) => l.ratio),
    };
    // مستويات رئيسية فقط وبسيطة: 38.2 / 50 / 61.8 — بدون كلمة فيبوناتشي وبدون سعر
    const mainFib = new Set([0.236, 0.382, 0.5, 0.618, 0.786]);
    for (const lvl of p.fib.levels) {
      if (!mainFib.has(lvl.ratio)) continue;
      ann.levels.push(
        makeLevel(
          `fib-${lvl.ratio}`,
          shortFibLabel(lvl.ratio),
          lvl.price,
          "fibonacci",
          "dashed",
          "#a78bfa",
        ),
      );
    }
  }

  return ann;
}
