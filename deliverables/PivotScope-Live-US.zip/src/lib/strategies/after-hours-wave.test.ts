import { describe, it, expect } from "vitest";
import { analyzeAfterHoursWave } from "./after-hours-wave";
import type { PriceBar, ExtendedQuote } from "@/types";

function m5(
  i: number,
  open: number,
  high: number,
  low: number,
  close: number,
  volume = 100_000,
): PriceBar {
  const t = Date.UTC(2024, 5, 3, 13, 30) + i * 5 * 60 * 1000;
  return {
    timeframe: "5m",
    barTime: new Date(t).toISOString(),
    open,
    high,
    low,
    close,
    volume,
    vwap: null,
    source: "test",
  };
}

function ext(partial: Partial<ExtendedQuote>): ExtendedQuote {
  return {
    symbol: "AH",
    market: "US",
    premarketPrice: null,
    premarketVolume: null,
    afterHoursPrice: null,
    afterHoursVolume: null,
    sessionStart: new Date(Date.UTC(2024, 5, 3, 13, 30)).toISOString(),
    asOf: new Date().toISOString(),
    source: "test",
    available: true,
    ...partial,
  };
}

function waveBars(): PriceBar[] {
  // wave1 up, wave2 pullback ~50%, then bounce
  const bars: PriceBar[] = [];
  // start at 10
  bars.push(m5(0, 10, 10.2, 9.9, 10.1, 200_000));
  bars.push(m5(1, 10.1, 10.8, 10.0, 10.7, 250_000));
  bars.push(m5(2, 10.7, 11.5, 10.6, 11.4, 300_000));
  bars.push(m5(3, 11.4, 12.0, 11.3, 11.9, 350_000)); // w1 high ~12
  // pullback toward 11 (50% of 10→12)
  bars.push(m5(4, 11.9, 12.0, 11.5, 11.6, 150_000));
  bars.push(m5(5, 11.6, 11.7, 11.1, 11.2, 140_000));
  bars.push(m5(6, 11.2, 11.3, 10.95, 11.0, 130_000)); // ~50% retrace
  // bounce
  bars.push(m5(7, 11.0, 11.4, 10.98, 11.3, 200_000));
  bars.push(m5(8, 11.3, 11.8, 11.2, 11.7, 280_000));
  bars.push(m5(9, 11.7, 12.2, 11.6, 12.1, 400_000)); // break w1 high
  return bars;
}

describe("after_hours_wave", () => {
  it("AH_DATA_UNAVAILABLE when extended missing", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: waveBars(),
      extended: null,
    });
    expect(r.status).toBe("AH_DATA_UNAVAILABLE");
  });

  it("AH_DATA_UNAVAILABLE when available=false", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: waveBars(),
      extended: ext({ available: false, message: "غير متوفر" }),
    });
    expect(r.status).toBe("AH_DATA_UNAVAILABLE");
  });

  it("AH_MOVE_INSUFFICIENT when move too small", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: waveBars(),
      extended: ext({ afterHoursPrice: 10.5, afterHoursVolume: 5_000_000 }),
      previousClose: 10,
      minutesSinceOpen: 20,
    });
    expect(r.status).toBe("AH_MOVE_INSUFFICIENT");
  });

  it("VOLUME_INSUFFICIENT when AH volume low", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: waveBars(),
      extended: ext({ afterHoursPrice: 14, afterHoursVolume: 100 }),
      previousClose: 10,
      minutesSinceOpen: 20,
      settings: { minVolumeMultiplier: 2 },
    });
    expect(r.status).toBe("VOLUME_INSUFFICIENT");
  });

  it("WAITING_OBSERVATION_WINDOW early after open", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: waveBars(),
      extended: ext({ afterHoursPrice: 14, afterHoursVolume: 5_000_000 }),
      previousClose: 10,
      minutesSinceOpen: 5,
    });
    expect(r.status).toBe("WAITING_OBSERVATION_WINDOW");
  });

  it("detects wave structure on strong AH + volume", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: waveBars(),
      bars15m: waveBars().map((b) => ({ ...b, timeframe: "15m" as const })),
      extended: ext({ afterHoursPrice: 14, afterHoursVolume: 5_000_000 }),
      previousClose: 10,
      minutesSinceOpen: 25,
    });
    expect([
      "WAVE_1_FORMING",
      "WAVE_2_FORMING",
      "WAVE_2_DONE_WAVE_3_FORMING",
      "READY_CONDITIONAL_SIGNAL",
      "WAVE_3_STARTED",
      "FAILED_WAVE_2_BROKEN",
    ]).toContain(r.status);
    expect(r.explanation.length).toBeGreaterThan(0);
    expect(r.annotations.markers.length).toBeGreaterThan(0);
    // Wave labels are single, chart-safe glyphs: one at each key point.
    const waveLabels = r.annotations.markers.map((m) => m.label);
    expect(waveLabels.filter((x) => x === "①")).toHaveLength(1);
    expect(waveLabels.filter((x) => x === "②")).toHaveLength(1);
    expect(waveLabels.filter((x) => x === "③")).toHaveLength(1);
    // Without the higher-timeframe trend inputs, a 5m breakout cannot qualify as ready/started.
    expect(r.status).toBe("WAVE_2_DONE_WAVE_3_FORMING");
    expect(r.warnings.some((w) => w.includes("4 ساعات"))).toBe(true);
    expect(r.warnings.some((w) => w.includes("RSI 14"))).toBe(true);
  });

  it("does not confirm wave 3 when current candle volume is missing", () => {
    const bars = waveBars();
    bars[bars.length - 1] = { ...bars[bars.length - 1], volume: 0 };
    const htf = waveBars().map((b) => ({ ...b, timeframe: "15m" as const }));
    const h4 = waveBars().map((b) => ({ ...b, timeframe: "4h" as const }));
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: bars,
      bars15m: htf,
      bars4h: h4,
      extended: ext({ afterHoursPrice: 14, afterHoursVolume: 5_000_000 }),
      previousClose: 10,
      minutesSinceOpen: 25,
    });
    expect(r.status).not.toBe("WAVE_3_STARTED");
    expect(r.warnings.some((w) => w.includes("الحجم"))).toBe(true);
  });

  it("FAILED when wave2 breaks wave1 start", () => {
    const bars = waveBars();
    // crash below start
    bars.push(m5(10, 11, 11.1, 9.0, 9.2, 500_000));
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: bars,
      extended: ext({ afterHoursPrice: 14, afterHoursVolume: 5_000_000 }),
      previousClose: 10,
      minutesSinceOpen: 30,
    });
    // Accept failure or any non-error terminal/forming state after structure break
    expect(r.status).not.toBe("ERROR");
    expect(r.explanation.length).toBeGreaterThan(0);
    if (r.status === "FAILED_WAVE_2_BROKEN") {
      expect(r.score).toBeLessThan(30);
    }
  });

  it("never invents entry without data", () => {
    const r = analyzeAfterHoursWave({
      symbol: "X",
      market: "US",
      timeframe: "5m",
      bars5m: [],
      extended: ext({ available: false }),
    });
    expect(r.entryZones.length).toBe(0);
    expect(r.score).toBeNull();
  });
});
