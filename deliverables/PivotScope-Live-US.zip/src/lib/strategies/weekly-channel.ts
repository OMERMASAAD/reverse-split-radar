import type {
  PriceBar,
  WeeklyChannelSettings,
  AnalysisResult,
  AnalysisStatus,
  Market,
  Timeframe,
  MarketCap,
} from "@/types";
import { STATUS_LABELS_AR, DEFAULT_WEEKLY_CHANNEL_SETTINGS } from "@/types";
import {
  computeIndicators,
  calculateFibonacci,
  fibExtensionUp,
} from "@/lib/indicators";
import {
  findPeaks,
  findTroughs,
  emptyAnnotations,
  makeLevel,
  makeZone,
  percentChange,
} from "./helpers";

export interface WeeklyChannelInput {
  symbol: string;
  market: Market;
  timeframe: Timeframe;
  barsDaily: PriceBar[];
  bars4h?: PriceBar[];
  barsWeekly?: PriceBar[];
  marketCap: MarketCap | null;
  lastPrice?: number | null;
  settings?: Partial<WeeklyChannelSettings>;
  dataSource?: string;
  dataSourceTime?: string | null;
}

function base(
  input: WeeklyChannelInput,
  status: AnalysisStatus,
  score: number | null,
  extras: Partial<AnalysisResult>,
): AnalysisResult {
  return {
    strategy: "weekly_price_channel",
    symbol: input.symbol,
    market: input.market,
    timeframe: input.timeframe,
    status,
    statusLabel: STATUS_LABELS_AR[status],
    score,
    dataQuality: extras.dataQuality || "partial",
    lastUpdatedAt: new Date().toISOString(),
    dataSource: input.dataSource || "unknown",
    dataSourceTime: input.dataSourceTime ?? null,
    supportZones: extras.supportZones || [],
    resistanceLevels: extras.resistanceLevels || [],
    entryZones: extras.entryZones || [],
    stopLoss: extras.stopLoss ?? null,
    targets: extras.targets || [],
    indicators: extras.indicators || {},
    warnings: extras.warnings || [],
    explanation: extras.explanation || [],
    annotations: extras.annotations || emptyAnnotations(),
    meta: extras.meta,
  };
}

interface Channel {
  support: number;
  resistance: number;
  supportTouches: number;
  resistanceTouches: number;
}

function detectChannel(
  bars: PriceBar[],
  tolerancePercent: number,
  minTouches: number,
): Channel | null {
  if (bars.length < 20) return null;

  const peaks = findPeaks(bars, 2, 2);
  const troughs = findTroughs(bars, 2, 2);
  if (peaks.length < minTouches || troughs.length < minTouches) return null;

  // Cluster troughs into support
  const troughPrices = troughs.map((t) => t.price).sort((a, b) => a - b);
  const peakPrices = peaks.map((p) => p.price).sort((a, b) => a - b);

  const support = median(troughPrices.slice(0, Math.ceil(troughPrices.length * 0.6)));
  const resistance = median(
    peakPrices.slice(Math.floor(peakPrices.length * 0.4)),
  );

  if (!support || !resistance || resistance <= support) return null;

  const tolS = support * (tolerancePercent / 100);
  const tolR = resistance * (tolerancePercent / 100);

  const supportTouches = troughs.filter(
    (t) => Math.abs(t.price - support) <= tolS,
  ).length;
  const resistanceTouches = peaks.filter(
    (p) => Math.abs(p.price - resistance) <= tolR,
  ).length;

  if (
    supportTouches < minTouches &&
    resistanceTouches < minTouches
  ) {
    return null;
  }

  // Need at least minTouches on one side and 1+ on the other, or min on both
  if (supportTouches + resistanceTouches < minTouches + 1) return null;

  return { support, resistance, supportTouches, resistanceTouches };
}

function median(arr: number[]): number {
  if (!arr.length) return 0;
  const a = [...arr].sort((x, y) => x - y);
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

/**
 * weekly_price_channel — pure strategy engine.
 */
export function analyzeWeeklyChannel(
  input: WeeklyChannelInput,
): AnalysisResult {
  const s: WeeklyChannelSettings = {
    ...DEFAULT_WEEKLY_CHANNEL_SETTINGS,
    ...input.settings,
  };
  const bars = input.barsDaily;
  const warnings: string[] = [];

  if (!bars || bars.length < 30) {
    return base(input, "INSUFFICIENT_DATA", null, {
      dataQuality: "insufficient",
      warnings: ["الشارت لا يحتوي على شموع كافية."],
      explanation: ["يلزم 30 شمعة يومية على الأقل لاكتشاف القناة."],
    });
  }

  const lastPrice =
    input.lastPrice ?? bars[bars.length - 1]?.close ?? null;
  if (lastPrice == null) {
    return base(input, "INSUFFICIENT_DATA", null, {
      dataQuality: "insufficient",
      warnings: ["السعر الحالي غير متوفر."],
    });
  }

  if (lastPrice < s.minPrice || lastPrice > s.maxPrice) {
    return base(input, "PRICE_OUT_OF_RANGE", null, {
      dataQuality: "good",
      explanation: [
        `السعر الحالي ${lastPrice.toFixed(2)} خارج النطاق ${s.minPrice}–${s.maxPrice}.`,
      ],
      meta: { lastPrice },
    });
  }

  if (!input.marketCap || input.marketCap.marketCap == null) {
    return base(input, "MARKET_CAP_UNAVAILABLE", null, {
      dataQuality: "partial",
      warnings: ["القيمة السوقية غير متوفرة."],
      explanation: [
        "لا يمكن تأكيد شرط القيمة السوقية الكبيرة بدون بيانات.",
        "لن تُنتج إشارة مكتملة حتى تتوفر القيمة السوقية أو تُدخل يدوياً.",
      ],
    });
  }

  if (input.marketCap.marketCap < s.minMarketCap) {
    return base(input, "PRICE_OUT_OF_RANGE", null, {
      dataQuality: "good",
      explanation: [
        `القيمة السوقية ${formatCap(input.marketCap.marketCap)} أقل من الحد ${formatCap(s.minMarketCap)}.`,
      ],
      // reuse status? better a dedicated one — keep explanation clear
      warnings: ["القيمة السوقية دون الحد المطلوب."],
    });
  }

  const channel = detectChannel(
    bars,
    s.channelTolerancePercent,
    s.channelTouchCount,
  );

  if (!channel) {
    return base(input, "CHANNEL_UNCLEAR", 20, {
      dataQuality: "good",
      explanation: [
        "لم تُكتشف قناة دعم/مقاومة بلمسات كافية.",
        `الحد الأدنى للمسات: ${s.channelTouchCount}.`,
      ],
    });
  }

  const { support, resistance } = channel;
  const height = resistance - support;
  const mid = support + height / 2;
  const pos = height > 0 ? (lastPrice - support) / height : 0.5;

  const indicators = computeIndicators(bars);
  const tol = support * (s.channelTolerancePercent / 100);

  // Recent bounce?
  const recent = bars.slice(-5);
  const touchedSupport = recent.some(
    (b) => b.low <= support + tol && b.low >= support - tol * 2,
  );
  const closedAbove = recent[recent.length - 1].close > support + tol * 0.5;
  const bounced = touchedSupport && closedAbove;

  const nearRes = pos >= 0.85;
  const nearSup = pos <= 0.15;
  const midCh = pos > 0.35 && pos < 0.65;

  const brokeSupport = lastPrice < support - tol;
  const brokeRes = lastPrice > resistance + tol;

  // Fib from last clear upswing (قاع → قمة) للتصحيحات داخل القناة
  // الامتداد الصاعد للأهداف يُحسب فوق القمة/المقاومة — وليس أسفل القاع
  const peaks = findPeaks(bars.slice(-40), 2, 2);
  const troughs = findTroughs(bars.slice(-40), 2, 2);
  let fib = null;
  let swingLow: number | null = null;
  let swingHigh: number | null = null;
  if (peaks.length && troughs.length) {
    const lastPeak = peaks[peaks.length - 1];
    // أقرب قاع قبل آخر قمة
    const troughsBefore = troughs.filter((t) => t.index <= lastPeak.index);
    const lastTrough =
      troughsBefore[troughsBefore.length - 1] || troughs[troughs.length - 1];
    try {
      if (lastPeak.price > lastTrough.price) {
        swingHigh = lastPeak.price;
        swingLow = lastTrough.price;
        fib = calculateFibonacci(lastPeak.price, lastTrough.price);
      }
    } catch {
      /* ignore */
    }
  }

  const entry1 = makeZone(
    "e1",
    "منطقة الدخول — قرب الدعم",
    support - tol,
    support + tol,
    "entry",
  );
  const entry2 = bounced
    ? makeZone(
        "e2",
        "منطقة الدخول — ارتداد مؤكد",
        support,
        support + height * 0.15,
        "entry",
      )
    : null;

  const stop = makeLevel(
    "sl",
    "وقف الخسارة",
    support - tol * 1.5,
    "stop",
    "dashed",
    "#d96a62",
  );

  // أهداف صفقة الارتداد من الدعم: دائماً فوق الدعم وبالترتيب t1 < t2 < t3
  // t1: منتصف القناة · t2: المقاومة · t3: امتداد فوق المقاومة (127.2% صاعد)
  const t1Price = mid;
  const t2Price = resistance;
  // امتداد فيبوناتشي الصاعد فوق القمة/المقاومة (وليس تحت الدعم)
  let t3Price: number;
  if (swingHigh != null && swingLow != null && swingHigh > swingLow) {
    t3Price = fibExtensionUp(swingHigh, swingLow, 1.272);
  } else {
    t3Price = resistance + height * 0.272;
  }
  // ضمان: t3 فوق المقاومة، و t1/t2/t3 فوق الدعم وبالترتيب
  if (t3Price <= t2Price) {
    t3Price = t2Price + Math.max(height * 0.272, t2Price * 0.02);
  }
  if (!(t1Price > support && t2Price >= t1Price && t3Price > t2Price)) {
    // fallback آمن لصفقة ارتداد من الدعم
    t3Price = Math.max(t3Price, resistance + Math.abs(height) * 0.272);
  }

  const t1 = makeLevel("t1", "الهدف الأول", t1Price, "target", "solid", "#118476");
  const t2 = makeLevel(
    "t2",
    "الهدف الثاني",
    t2Price,
    "target",
    "solid",
    "#d6a441",
  );
  const t3 = makeLevel(
    "t3",
    "الهدف الثالث",
    t3Price,
    "target",
    "solid",
    "#7c5cbf",
  );

  let status: AnalysisStatus = "MID_CHANNEL";
  let score = 50;
  const explanation: string[] = [
    `السعر ${lastPrice.toFixed(2)} ضمن النطاق ${s.minPrice}–${s.maxPrice}.`,
    `القيمة السوقية: ${formatCap(input.marketCap.marketCap)}.`,
    `الدعم الرئيسي: ${support.toFixed(4)} (${channel.supportTouches} لمسات).`,
    `المقاومة الرئيسية: ${resistance.toFixed(4)} (${channel.resistanceTouches} لمسات).`,
    `موقع السعر داخل القناة: ${(pos * 100).toFixed(0)}%.`,
    `مدة الصفقة المتوقعة: ${s.holdingMinSessions}–${s.holdingMaxSessions} جلسات.`,
    `الأهداف: الأول ${t1Price.toFixed(3)} (منتصف) · الثاني ${t2Price.toFixed(3)} (مقاومة) · الثالث ${t3Price.toFixed(3)} (امتداد فوق المقاومة).`,
  ];

  if (brokeSupport) {
    status = "SUPPORT_BROKEN";
    score = 10;
    explanation.push("كُسر الدعم — تُرفض الإشارة.");
  } else if (brokeRes) {
    status = "RESISTANCE_BREAKOUT";
    score = 75;
    explanation.push("اختراق المقاومة.");
    if (s.allowBreakoutRetestEntry) {
      explanation.push("إعادة اختبار المقاومة مسموحة حسب الإعدادات.");
    }
  } else if (nearSup && bounced) {
    status = "POSSIBLE_BOUNCE";
    score = 82;
    explanation.push("ارتداد محتمل من الدعم — إشارة مشروطة.");
  } else if (nearSup) {
    status = "NEAR_SUPPORT";
    score = 70;
    explanation.push("السعر قريب من الدعم الرئيسي.");
  } else if (nearRes) {
    status = "NEAR_RESISTANCE";
    score = 55;
    explanation.push("السعر قريب من المقاومة.");
  } else if (midCh) {
    status = "MID_CHANNEL";
    score = 40;
    explanation.push("السعر في منتصف القناة — لا تفضيل اتجاهي واضح.");
  }

  // Target hit?
  if (
    !brokeSupport &&
    lastPrice >= t1.price &&
    status === "POSSIBLE_BOUNCE"
  ) {
    // still bounce path
  }
  if (lastPrice >= t2.price && !brokeRes) {
    status = "TARGET_HIT";
    score = 88;
    explanation.push("هدف المقاومة الرئيسية متحقق.");
  }

  explanation.push("تحليل فني فقط — ليست توصية تداول.");

  const entries = [entry1, entry2].filter(Boolean) as typeof entry1[];
  if (brokeRes && s.allowBreakoutRetestEntry) {
    entries.push(
      makeZone(
        "e3",
        "منطقة الدخول — إعادة اختبار المقاومة",
        resistance * 0.98,
        resistance * 1.01,
        "entry",
      ),
    );
  }

  const ann = emptyAnnotations();
  ann.zones.push(
    makeZone("ch-sup", "الدعم الرئيسي", support - tol, support + tol, "support"),
  );
  ann.levels.push(
    makeLevel("sup", "الدعم الرئيسي", support, "support", "solid", "#118476"),
  );
  ann.levels.push(
    makeLevel("res", "المقاومة الأولى", resistance, "resistance", "solid", "#d96a62"),
  );
  ann.levels.push(
    makeLevel("mid", "منتصف القناة", mid, "resistance", "dotted", "#94a3b8"),
  );
  for (const e of entries) ann.zones.push(e);
  ann.levels.push(stop, t1, t2, t3);

  if (fib) {
    ann.fibonacci = {
      highPrice: fib.high,
      lowPrice: fib.low,
      levels: fib.levels.map((l) => l.ratio),
    };
    const main = new Set([0.382, 0.5, 0.618]);
    for (const lvl of fib.levels) {
      if (!main.has(lvl.ratio)) continue;
      const pct = (lvl.ratio * 100).toFixed(1).replace(/\.0$/, "");
      ann.levels.push(
        makeLevel(
          `fib-${lvl.ratio}`,
          `${pct}%`,
          lvl.price,
          "fibonacci",
          "dashed",
          "#a78bfa",
        ),
      );
    }
  }

  if (indicators.ema20)
    ann.levels.push(
      makeLevel("ema20", "EMA 20", indicators.ema20, "ema", "solid", "#3b82f6"),
    );
  if (indicators.ema50)
    ann.levels.push(
      makeLevel("ema50", "EMA 50", indicators.ema50, "ema", "solid", "#7c5cbf"),
    );

  return base(input, status, score, {
    dataQuality: "good",
    supportZones: [
      makeZone("sup", "الدعم الرئيسي", support - tol, support + tol, "support"),
    ],
    resistanceLevels: [
      makeLevel("r1", "المقاومة الأولى", resistance, "resistance", "solid", "#d96a62"),
    ],
    entryZones: entries,
    stopLoss: stop,
    targets: [t1, t2, t3],
    indicators: {
      ema20: indicators.ema20,
      ema30: indicators.ema30,
      ema50: indicators.ema50,
      rsi14: indicators.rsi14,
      vwap: indicators.vwap,
    },
    warnings,
    explanation,
    annotations: ann,
    meta: {
      channel,
      positionInChannel: pos,
      lastPrice,
      holdingSessions: [s.holdingMinSessions, s.holdingMaxSessions],
      bouncePct: bounced
        ? percentChange(support, lastPrice)
        : null,
    },
  });
}

function formatCap(n: number): string {
  if (n >= 1e12) return `${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  return n.toFixed(0);
}
