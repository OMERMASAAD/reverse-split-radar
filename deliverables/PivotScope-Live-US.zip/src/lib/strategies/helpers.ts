import type { PriceBar, Level, Zone, ChartAnnotation } from "@/types";

export function avgVolume(bars: PriceBar[], lookback = 20): number {
  if (bars.length === 0) return 0;
  const slice = bars.slice(-lookback);
  return slice.reduce((s, b) => s + b.volume, 0) / slice.length;
}

export function percentChange(from: number, to: number): number {
  if (from === 0) return 0;
  return ((to - from) / from) * 100;
}

export function findSwingHigh(
  bars: PriceBar[],
  fromIdx: number,
  toIdx: number,
): { index: number; price: number; time: string } | null {
  if (fromIdx < 0 || toIdx >= bars.length || fromIdx > toIdx) return null;
  let best = fromIdx;
  for (let i = fromIdx; i <= toIdx; i++) {
    if (bars[i].high > bars[best].high) best = i;
  }
  return {
    index: best,
    price: bars[best].high,
    time: bars[best].barTime,
  };
}

export function findSwingLow(
  bars: PriceBar[],
  fromIdx: number,
  toIdx: number,
): { index: number; price: number; time: string } | null {
  if (fromIdx < 0 || toIdx >= bars.length || fromIdx > toIdx) return null;
  let best = fromIdx;
  for (let i = fromIdx; i <= toIdx; i++) {
    if (bars[i].low < bars[best].low) best = i;
  }
  return {
    index: best,
    price: bars[best].low,
    time: bars[best].barTime,
  };
}

/** Local peaks: high greater than `left` and `right` neighbors */
export function findPeaks(
  bars: PriceBar[],
  left = 2,
  right = 2,
): Array<{ index: number; price: number; time: string }> {
  const peaks: Array<{ index: number; price: number; time: string }> = [];
  for (let i = left; i < bars.length - right; i++) {
    let isPeak = true;
    for (let j = i - left; j <= i + right; j++) {
      if (j === i) continue;
      if (bars[j].high >= bars[i].high) {
        isPeak = false;
        break;
      }
    }
    if (isPeak) {
      peaks.push({ index: i, price: bars[i].high, time: bars[i].barTime });
    }
  }
  return peaks;
}

export function findTroughs(
  bars: PriceBar[],
  left = 2,
  right = 2,
): Array<{ index: number; price: number; time: string }> {
  const troughs: Array<{ index: number; price: number; time: string }> = [];
  for (let i = left; i < bars.length - right; i++) {
    let isTrough = true;
    for (let j = i - left; j <= i + right; j++) {
      if (j === i) continue;
      if (bars[j].low <= bars[i].low) {
        isTrough = false;
        break;
      }
    }
    if (isTrough) {
      troughs.push({ index: i, price: bars[i].low, time: bars[i].barTime });
    }
  }
  return troughs;
}

export function emptyAnnotations(): ChartAnnotation {
  return { levels: [], zones: [], markers: [] };
}

export function makeLevel(
  id: string,
  label: string,
  price: number,
  kind: Level["kind"],
  style: Level["style"] = "solid",
  color?: string,
): Level {
  return { id, label, price, kind, style, color };
}

export function makeZone(
  id: string,
  label: string,
  priceLow: number,
  priceHigh: number,
  kind: Zone["kind"],
): Zone {
  const lo = Math.min(priceLow, priceHigh);
  const hi = Math.max(priceLow, priceHigh);
  return { id, label, priceLow: lo, priceHigh: hi, kind };
}

export function sessionsSince(
  bars: PriceBar[],
  fromDate: string,
): number {
  const t = new Date(fromDate).getTime();
  return bars.filter((b) => new Date(b.barTime).getTime() >= t).length;
}

/** عدد أيام التداول (جلسات) الفريدة — صحيح على 1d و 4h و 5m */
export function uniqueSessionDays(
  bars: PriceBar[],
  fromIdx = 0,
  toIdx?: number,
): number {
  const end = toIdx ?? bars.length - 1;
  const days = new Set<string>();
  for (let i = Math.max(0, fromIdx); i <= end && i < bars.length; i++) {
    days.add(sessionDayKey(bars[i].barTime));
  }
  return days.size;
}

export function sessionDayKey(barTime: string): string {
  return new Date(barTime).toISOString().slice(0, 10);
}

/** تقدير عدد الشموع لكل جلسة يومية من الفريم أو من تباعد البيانات */
export function barsPerSessionDay(
  timeframe: string,
  bars?: PriceBar[],
): number {
  if (timeframe === "1d") return 1;
  if (timeframe === "1w") return 1;
  if (timeframe === "4h") {
    if (bars && bars.length >= 4) {
      const gaps: number[] = [];
      for (let i = 1; i < Math.min(bars.length, 40); i++) {
        gaps.push(
          new Date(bars[i].barTime).getTime() -
            new Date(bars[i - 1].barTime).getTime(),
        );
      }
      gaps.sort((a, b) => a - b);
      const med = gaps[Math.floor(gaps.length / 2)] || 4 * 3600 * 1000;
      const hours = med / 3600000;
      if (hours > 0 && hours <= 8) return Math.max(1, Math.round(6.5 / hours));
    }
    return 2;
  }
  if (timeframe === "15m") return 26;
  if (timeframe === "5m") return 78;
  return 1;
}

export function indexOnOrAfter(bars: PriceBar[], dateIso: string): number {
  const t = new Date(dateIso).getTime();
  for (let i = 0; i < bars.length; i++) {
    if (new Date(bars[i].barTime).getTime() >= t) return i;
  }
  return -1;
}

/** تسمية فيبوناتشي مختصرة للشارت: "38.2%" فقط بدون كلمة فيبوناتشي أو سعر */
export function shortFibLabel(ratio: number): string {
  const pct = ratio * 100;
  const s = pct % 1 === 0 ? pct.toFixed(0) : pct.toFixed(1);
  return `${s}%`;
}
