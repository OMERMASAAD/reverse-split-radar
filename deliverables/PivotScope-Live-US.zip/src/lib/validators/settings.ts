import { z } from "zod";
import type { AppSettings } from "@/types";
import { DEFAULT_APP_SETTINGS } from "@/types";

const reverseSplitSchema = z
  .object({
    splitLookbackMinSessions: z.number().int().min(1).max(200),
    splitLookbackMaxSessions: z.number().int().min(1).max(500),
    initialRallyMinPercent: z.number().min(0).max(500),
    initialRallyMaxPercent: z.number().min(0).max(1000),
    declineMinPercent: z.number().min(0).max(100),
    declineMaxPercent: z.number().min(0).max(100),
    supportSessions: z.number().int().min(1).max(50),
    supportTolerancePercent: z.number().min(0.1).max(20),
    higherLowMinPercent: z.number().min(0).max(50),
    breakoutVolumeMultiplier: z.number().min(0.5).max(10),
  })
  .refine((v) => v.splitLookbackMinSessions <= v.splitLookbackMaxSessions, {
    message: "الحد الأدنى للجلسات أكبر من الحد الأقصى",
    path: ["splitLookbackMinSessions"],
  })
  .refine((v) => v.initialRallyMinPercent <= v.initialRallyMaxPercent, {
    message: "حد الارتفاع الأدنى أكبر من الأقصى",
    path: ["initialRallyMinPercent"],
  })
  .refine((v) => v.declineMinPercent <= v.declineMaxPercent, {
    message: "حد الهبوط الأدنى أكبر من الأقصى",
    path: ["declineMinPercent"],
  });

const afterHoursSchema = z
  .object({
    minAfterHoursMovePercent: z.number().min(1).max(500),
    minVolumeMultiplier: z.number().min(0.5).max(20),
    premarketObservationMinutes: z.number().int().min(1).max(120),
    premarketObservationMaxMinutes: z.number().int().min(1).max(240),
    wave2RetracementMinPercent: z.number().min(0).max(100),
    wave2RetracementMaxPercent: z.number().min(0).max(100),
    wave2InvalidationBufferPercent: z.number().min(0).max(10),
    wave3VolumeMultiplier: z.number().min(0.5).max(10),
  })
  .refine(
    (v) => v.premarketObservationMinutes <= v.premarketObservationMaxMinutes,
    {
      message: "حد نافذة الرصد الأدنى أكبر من الأقصى",
      path: ["premarketObservationMinutes"],
    },
  )
  .refine(
    (v) => v.wave2RetracementMinPercent <= v.wave2RetracementMaxPercent,
    {
      message: "حد تصحيح فيبوناتشي الأدنى أكبر من الأقصى",
      path: ["wave2RetracementMinPercent"],
    },
  );

const weeklySchema = z
  .object({
    minPrice: z.number().min(0.01).max(10000),
    maxPrice: z.number().min(0.01).max(100000),
    minMarketCap: z.number().min(0).max(1e15),
    holdingMinSessions: z.number().int().min(1).max(30),
    holdingMaxSessions: z.number().int().min(1).max(60),
    channelTouchCount: z.number().int().min(1).max(20),
    channelTolerancePercent: z.number().min(0.1).max(20),
    breakoutConfirmationSessions: z.number().int().min(0).max(10),
    allowBreakoutRetestEntry: z.boolean(),
  })
  .refine((v) => v.minPrice <= v.maxPrice, {
    message: "السعر الأدنى أكبر من السعر الأقصى",
    path: ["minPrice"],
  })
  .refine((v) => v.holdingMinSessions <= v.holdingMaxSessions, {
    message: "حد مدة الصفقة الأدنى أكبر من الأقصى",
    path: ["holdingMinSessions"],
  });

export const appSettingsSchema = z.object({
  theme: z.enum(["light", "dark"]),
  language: z.literal("ar"),
  defaultMarket: z.enum(["US", "SA", "OTHER"]),
  currency: z.string().min(1).max(8),
  timezone: z.string().min(1).max(64),
  dataProvider: z.enum(["yahoo", "demo"]),
  cacheTtlSeconds: z.number().int().min(0).max(86400),
  reverseSplit: reverseSplitSchema,
  afterHoursWave: afterHoursSchema,
  weeklyChannel: weeklySchema,
});

export function validateSettings(
  input: unknown,
): { ok: true; data: AppSettings } | { ok: false; errors: string[] } {
  const parsed = appSettingsSchema.safeParse(input);
  if (!parsed.success) {
    return {
      ok: false,
      errors: parsed.error.issues.map(
        (i) => `${i.path.join(".")}: ${i.message}`,
      ),
    };
  }
  return { ok: true, data: parsed.data as AppSettings };
}

export function resetSettings(): AppSettings {
  return structuredClone(DEFAULT_APP_SETTINGS);
}
