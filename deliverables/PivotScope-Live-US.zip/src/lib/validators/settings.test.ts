import { describe, it, expect } from "vitest";
import { validateSettings } from "./settings";
import { DEFAULT_APP_SETTINGS } from "@/types";

describe("settings validation", () => {
  it("accepts defaults", () => {
    const r = validateSettings(DEFAULT_APP_SETTINGS);
    expect(r.ok).toBe(true);
  });

  it("rejects min > max sessions", () => {
    const bad = structuredClone(DEFAULT_APP_SETTINGS);
    bad.reverseSplit.splitLookbackMinSessions = 80;
    bad.reverseSplit.splitLookbackMaxSessions = 20;
    const r = validateSettings(bad);
    expect(r.ok).toBe(false);
  });

  it("rejects negative-like invalid fib range", () => {
    const bad = structuredClone(DEFAULT_APP_SETTINGS);
    bad.afterHoursWave.wave2RetracementMinPercent = 80;
    bad.afterHoursWave.wave2RetracementMaxPercent = 30;
    const r = validateSettings(bad);
    expect(r.ok).toBe(false);
  });

  it("rejects minPrice > maxPrice", () => {
    const bad = structuredClone(DEFAULT_APP_SETTINGS);
    bad.weeklyChannel.minPrice = 20;
    bad.weeklyChannel.maxPrice = 5;
    const r = validateSettings(bad);
    expect(r.ok).toBe(false);
  });
});
