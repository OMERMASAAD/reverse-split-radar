import type { PriceBar } from "@/types";

/**
 * VWAP = Σ(typical_price * volume) / Σ(volume)
 * typical_price = (high + low + close) / 3
 *
 * For intraday frames: resets conceptually per session when session breaks detected.
 * For higher frames: cumulative over the provided window.
 */
export function calculateVWAP(bars: PriceBar[]): Array<number | null> {
  const out: Array<number | null> = Array(bars.length).fill(null);
  let cumTPV = 0;
  let cumVol = 0;
  let lastSessionKey = "";

  for (let i = 0; i < bars.length; i++) {
    const b = bars[i];
    const sessionKey = sessionKeyFor(b.barTime, b.timeframe);

    if (
      (b.timeframe === "5m" || b.timeframe === "15m") &&
      sessionKey !== lastSessionKey &&
      lastSessionKey !== ""
    ) {
      cumTPV = 0;
      cumVol = 0;
    }
    lastSessionKey = sessionKey;

    const tp = (b.high + b.low + b.close) / 3;
    const vol = b.volume > 0 ? b.volume : 0;
    if (vol === 0) {
      out[i] = cumVol > 0 ? cumTPV / cumVol : tp;
      continue;
    }
    cumTPV += tp * vol;
    cumVol += vol;
    out[i] = cumVol > 0 ? cumTPV / cumVol : null;
  }
  return out;
}

function sessionKeyFor(barTime: string, timeframe: string): string {
  const d = new Date(barTime);
  if (timeframe === "1w") {
    // ISO week-ish
    return `${d.getUTCFullYear()}-W${Math.ceil(d.getUTCDate() / 7)}`;
  }
  // Calendar day UTC as session proxy
  return d.toISOString().slice(0, 10);
}

export function vwapLast(bars: PriceBar[]): number | null {
  const series = calculateVWAP(bars);
  for (let i = series.length - 1; i >= 0; i--) {
    if (series[i] != null) return series[i];
  }
  return null;
}

export const VWAP_TOOLTIP_AR =
  "VWAP = مجموع (السعر النموذجي × الحجم) ÷ مجموع الحجم. السعر النموذجي = (الأعلى + الأدنى + الإغلاق) ÷ 3. يُعاد ضبطه لكل جلسة على الفريمات اللحظية.";
