/**
 * RSI (Wilder) — period default 14
 * Uses Wilder's smoothing after initial average gain/loss.
 */
export function calculateRSI(
  closes: number[],
  period = 14,
): Array<number | null> {
  if (period <= 0) throw new Error("RSI period must be positive");
  const out: Array<number | null> = Array(closes.length).fill(null);
  if (closes.length <= period) return out;

  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gain += diff;
    else loss -= diff;
  }

  let avgGain = gain / period;
  let avgLoss = loss / period;

  const rsiAt = (g: number, l: number): number => {
    if (l === 0) return 100;
    if (g === 0) return 0;
    const rs = g / l;
    return 100 - 100 / (1 + rs);
  };

  out[period] = rsiAt(avgGain, avgLoss);

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const g = diff > 0 ? diff : 0;
    const l = diff < 0 ? -diff : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = rsiAt(avgGain, avgLoss);
  }
  return out;
}

export function rsiLast(closes: number[], period = 14): number | null {
  const series = calculateRSI(closes, period);
  for (let i = series.length - 1; i >= 0; i--) {
    if (series[i] != null) return series[i];
  }
  return null;
}

/** Detect higher low in RSI over a lookback window */
export function rsiHigherLow(
  rsi: Array<number | null>,
  lookback = 10,
): boolean {
  const vals: number[] = [];
  for (let i = rsi.length - 1; i >= 0 && vals.length < lookback; i--) {
    if (rsi[i] != null) vals.push(rsi[i]!);
  }
  if (vals.length < 4) return false;
  vals.reverse();
  // Find two troughs
  const troughs: number[] = [];
  for (let i = 1; i < vals.length - 1; i++) {
    if (vals[i] < vals[i - 1] && vals[i] < vals[i + 1]) {
      troughs.push(vals[i]);
    }
  }
  if (troughs.length < 2) return false;
  const a = troughs[troughs.length - 2];
  const b = troughs[troughs.length - 1];
  return b > a;
}

/** Exit from oversold: was <= 30 and now rising above 30 */
export function rsiExitOversold(
  rsi: Array<number | null>,
  oversold = 30,
): boolean {
  const recent: number[] = [];
  for (let i = rsi.length - 1; i >= 0 && recent.length < 5; i--) {
    if (rsi[i] != null) recent.push(rsi[i]!);
  }
  if (recent.length < 3) return false;
  recent.reverse();
  const hadOversold = recent.slice(0, -1).some((v) => v <= oversold);
  const now = recent[recent.length - 1];
  const prev = recent[recent.length - 2];
  return hadOversold && now > oversold && now > prev;
}
