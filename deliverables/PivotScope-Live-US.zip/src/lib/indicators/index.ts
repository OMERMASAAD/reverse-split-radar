export * from "./ema";
export * from "./rsi";
export * from "./vwap";
export * from "./fibonacci";

import type { PriceBar } from "@/types";
import { calculateEMA } from "./ema";
import { calculateRSI, rsiExitOversold, rsiHigherLow } from "./rsi";
import { calculateVWAP, vwapLast } from "./vwap";

export interface IndicatorSnapshot {
  ema20: number | null;
  ema30: number | null;
  ema50: number | null;
  rsi14: number | null;
  vwap: number | null;
  ema20Series: Array<number | null>;
  ema30Series: Array<number | null>;
  ema50Series: Array<number | null>;
  rsi14Series: Array<number | null>;
  vwapSeries: Array<number | null>;
  rsiExitOversold: boolean;
  rsiHigherLow: boolean;
  priceAboveVwap: boolean | null;
  priceAboveEma20: boolean | null;
}

export function computeIndicators(bars: PriceBar[]): IndicatorSnapshot {
  const closes = bars.map((b) => b.close);
  const ema20Series = calculateEMA(closes, 20);
  const ema30Series = calculateEMA(closes, 30);
  const ema50Series = calculateEMA(closes, 50);
  const rsi14Series = calculateRSI(closes, 14);
  const vwapSeries = calculateVWAP(bars);

  const last = <T>(arr: Array<T | null>): T | null => {
    for (let i = arr.length - 1; i >= 0; i--) {
      if (arr[i] != null) return arr[i] as T;
    }
    return null;
  };

  const ema20 = last(ema20Series);
  const ema30 = last(ema30Series);
  const ema50 = last(ema50Series);
  const rsi14 = last(rsi14Series);
  const vwap = vwapLast(bars);
  const price = closes.length ? closes[closes.length - 1] : null;

  return {
    ema20,
    ema30,
    ema50,
    rsi14,
    vwap,
    ema20Series,
    ema30Series,
    ema50Series,
    rsi14Series,
    vwapSeries,
    rsiExitOversold: rsiExitOversold(rsi14Series),
    rsiHigherLow: rsiHigherLow(rsi14Series),
    priceAboveVwap:
      price != null && vwap != null ? price >= vwap : null,
    priceAboveEma20:
      price != null && ema20 != null ? price >= ema20 : null,
  };
}
