/**
 * Fibonacci retracement / extension levels.
 * Direction: if high > low (upswing then pullback), levels measured from high down.
 * levels are percentages of the range.
 */

export const FIB_LEVELS = [
  0, 0.236, 0.382, 0.5, 0.618, 0.786, 1, 1.272, 1.618,
] as const;

export type FibLevel = (typeof FIB_LEVELS)[number];

export interface FibResult {
  high: number;
  low: number;
  range: number;
  /** price at each level — for retracement from high toward low */
  prices: Record<string, number>;
  levels: Array<{ ratio: number; price: number; label: string }>;
}

export function calculateFibonacci(
  high: number,
  low: number,
  customLevels: number[] = [...FIB_LEVELS],
): FibResult {
  if (!Number.isFinite(high) || !Number.isFinite(low)) {
    throw new Error("Fibonacci requires finite high/low");
  }
  if (high === low) {
    throw new Error("Fibonacci high and low must differ");
  }

  const top = Math.max(high, low);
  const bottom = Math.min(high, low);
  const range = top - bottom;
  const prices: Record<string, number> = {};
  const levels: FibResult["levels"] = [];

  for (const ratio of customLevels) {
    // Standard retracement: 0% at top (swing high), 100% at bottom
    const price = top - range * ratio;
    const key = (ratio * 100).toFixed(1).replace(/\.0$/, "");
    prices[key] = price;
    const pct = (ratio * 100).toFixed(1).replace(/\.0$/, "");
    levels.push({
      ratio,
      price,
      // تسمية مختصرة للشارت — بدون كلمة «فيبوناتشي» وبدون السعر
      label: `${pct}%`,
    });
  }

  return { high: top, low: bottom, range, prices, levels };
}

/** Retracement percent of current price between swing high and low (0=high, 100=low) */
export function retracementPercent(
  high: number,
  low: number,
  price: number,
): number | null {
  const top = Math.max(high, low);
  const bottom = Math.min(high, low);
  const range = top - bottom;
  if (range === 0) return null;
  return ((top - price) / range) * 100;
}

export function nearestFibLevel(
  high: number,
  low: number,
  price: number,
  tolerancePercent = 2,
): { ratio: number; price: number; label: string } | null {
  const fib = calculateFibonacci(high, low);
  let best: FibResult["levels"][0] | null = null;
  let bestDist = Infinity;
  for (const lvl of fib.levels) {
    const dist = (Math.abs(lvl.price - price) / price) * 100;
    if (dist < bestDist) {
      bestDist = dist;
      best = lvl;
    }
  }
  if (!best || bestDist > tolerancePercent) return null;
  return best;
}

/**
 * امتداد فيبوناتشي الصاعد بعد موجة (قاع → قمة).
 * ratio 1.272 → high + range*0.272  (فوق القمة)
 * لا تستخدم top - range*1.272 — ذلك ينزل تحت القاع.
 */
export function fibExtensionUp(
  swingHigh: number,
  swingLow: number,
  ratio = 1.272,
): number {
  const top = Math.max(swingHigh, swingLow);
  const bottom = Math.min(swingHigh, swingLow);
  const range = top - bottom;
  if (range <= 0) return top;
  // 1.0 = القمة، 1.272 = امتداد 27.2% فوق القمة
  return top + range * (ratio - 1);
}
