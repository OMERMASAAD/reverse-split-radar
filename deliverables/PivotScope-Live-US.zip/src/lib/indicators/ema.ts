/**
 * Exponential Moving Average
 * EMA_t = price_t * k + EMA_{t-1} * (1 - k)
 * k = 2 / (period + 1)
 * Seeded with SMA of first `period` values.
 * Returns null for indices before enough data.
 */
export function calculateEMA(
  values: number[],
  period: number,
): Array<number | null> {
  if (period <= 0) throw new Error("EMA period must be positive");
  const out: Array<number | null> = Array(values.length).fill(null);
  if (values.length < period) return out;

  let sum = 0;
  for (let i = 0; i < period; i++) {
    if (!Number.isFinite(values[i])) return out;
    sum += values[i];
  }
  let ema = sum / period;
  out[period - 1] = ema;

  const k = 2 / (period + 1);
  for (let i = period; i < values.length; i++) {
    if (!Number.isFinite(values[i])) {
      out[i] = null;
      continue;
    }
    ema = values[i] * k + ema * (1 - k);
    out[i] = ema;
  }
  return out;
}

export function emaLast(values: number[], period: number): number | null {
  const series = calculateEMA(values, period);
  for (let i = series.length - 1; i >= 0; i--) {
    if (series[i] != null) return series[i];
  }
  return null;
}
