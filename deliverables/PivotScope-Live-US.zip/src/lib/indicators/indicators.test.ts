import { describe, it, expect } from "vitest";
import { calculateEMA } from "./ema";
import { calculateRSI } from "./rsi";
import { calculateVWAP } from "./vwap";
import {
  calculateFibonacci,
  retracementPercent,
  fibExtensionUp,
} from "./fibonacci";
import type { PriceBar } from "@/types";

describe("EMA", () => {
  it("returns nulls until period filled", () => {
    const values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const ema = calculateEMA(values, 5);
    expect(ema[0]).toBeNull();
    expect(ema[3]).toBeNull();
    expect(ema[4]).not.toBeNull();
    // SMA seed = (1+2+3+4+5)/5 = 3
    expect(ema[4]).toBeCloseTo(3, 5);
  });

  it("does not compute before enough bars", () => {
    const ema = calculateEMA([1, 2, 3], 5);
    expect(ema.every((v) => v === null)).toBe(true);
  });

  it("matches known step", () => {
    // period 3: seed SMA(1,2,3)=2; next close 4 → 4*(2/4)+2*(1-0.5)=2+1=3
    const ema = calculateEMA([1, 2, 3, 4], 3);
    expect(ema[2]).toBeCloseTo(2, 8);
    expect(ema[3]).toBeCloseTo(3, 8);
  });
});

describe("RSI", () => {
  it("returns nulls until period+1 closes", () => {
    const closes = Array.from({ length: 14 }, (_, i) => 100 + i);
    const rsi = calculateRSI(closes, 14);
    expect(rsi[13]).toBeNull();
  });

  it("is 100 on pure gains", () => {
    const closes = Array.from({ length: 20 }, (_, i) => 100 + i);
    const rsi = calculateRSI(closes, 14);
    const last = rsi[rsi.length - 1];
    expect(last).toBeCloseTo(100, 5);
  });

  it("is 0 on pure losses", () => {
    const closes = Array.from({ length: 20 }, (_, i) => 100 - i);
    const rsi = calculateRSI(closes, 14);
    const last = rsi[rsi.length - 1];
    expect(last).toBeCloseTo(0, 5);
  });
});

describe("VWAP", () => {
  it("computes cumulative typical*vol / vol", () => {
    const bars: PriceBar[] = [
      {
        timeframe: "1d",
        barTime: "2024-01-01T00:00:00Z",
        open: 10,
        high: 12,
        low: 9,
        close: 11,
        volume: 100,
        vwap: null,
        source: "test",
      },
      {
        timeframe: "1d",
        barTime: "2024-01-02T00:00:00Z",
        open: 11,
        high: 13,
        low: 10,
        close: 12,
        volume: 100,
        vwap: null,
        source: "test",
      },
    ];
    const vwap = calculateVWAP(bars);
    // bar0 tp=(12+9+11)/3=10.666..., vwap=tp
    expect(vwap[0]).toBeCloseTo((12 + 9 + 11) / 3, 6);
    const tp0 = (12 + 9 + 11) / 3;
    const tp1 = (13 + 10 + 12) / 3;
    expect(vwap[1]).toBeCloseTo((tp0 * 100 + tp1 * 100) / 200, 6);
  });
});

describe("Fibonacci", () => {
  it("computes standard levels from high to low", () => {
    const fib = calculateFibonacci(100, 0);
    expect(fib.prices["0"]).toBeCloseTo(100, 6);
    expect(fib.prices["50"]).toBeCloseTo(50, 6);
    expect(fib.prices["61.8"]).toBeCloseTo(38.2, 6);
    expect(fib.prices["100"]).toBeCloseTo(0, 6);
    // تسمية مختصرة بدون كلمة فيبوناتشي
    const lvl50 = fib.levels.find((l) => l.ratio === 0.5);
    expect(lvl50?.label).toBe("50%");
  });

  it("rejects equal high/low", () => {
    expect(() => calculateFibonacci(10, 10)).toThrow();
  });

  it("retracement percent", () => {
    expect(retracementPercent(100, 0, 50)).toBeCloseTo(50, 6);
    expect(retracementPercent(100, 0, 100)).toBeCloseTo(0, 6);
  });

  it("fib extension goes ABOVE high not below low", () => {
    // swing 10 → 20, 1.272 extension = 20 + 10*0.272 = 22.72
    expect(fibExtensionUp(20, 10, 1.272)).toBeCloseTo(22.72, 5);
    expect(fibExtensionUp(20, 10, 1.272)).toBeGreaterThan(20);
    // must NOT equal the mistaken retracement formula top - range*1.272 = 7.28
    expect(fibExtensionUp(20, 10, 1.272)).not.toBeCloseTo(7.28, 1);
  });
});
