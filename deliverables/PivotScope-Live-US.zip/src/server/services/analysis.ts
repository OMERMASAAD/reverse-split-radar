import type {
  Market,
  Timeframe,
  StrategyKey,
  AnalysisResult,
  AppSettings,
} from "@/types";
import {
  analyzeReverseSplit,
  analyzeAfterHoursWave,
  analyzeWeeklyChannel,
} from "@/lib/strategies";
import {
  fetchBars,
  fetchCorporateActions,
  fetchExtendedHours,
  fetchMarketCap,
  fetchQuote,
  ensureSymbol,
} from "./market-data";
import {
  getAppSettings,
  saveAnalysisRun,
  getLatestShortData,
} from "@/server/db/repositories";
import { ProviderError } from "@/server/providers";

export interface AnalysisWithBars {
  result: AnalysisResult;
  bars: import("@/types").PriceBar[];
}

export async function runAnalysis(opts: {
  symbol: string;
  market?: Market;
  strategy: StrategyKey;
  timeframe?: Timeframe;
  demo?: boolean;
}): Promise<AnalysisWithBars> {
  const market = opts.market || "US";
  const settings = getAppSettings();
  const symbol = opts.symbol.trim().toUpperCase();
  const sym = ensureSymbol(symbol, market);
  // A Live request must never inherit a Demo provider selected in settings.
  const providerName = opts.demo ? "demo" : settings.dataProvider === "demo" ? "yahoo" : settings.dataProvider;

  try {
    switch (opts.strategy) {
      case "reverse_split_support":
        return await runReverseSplit(symbol, market, settings, sym.id, opts.timeframe, providerName);
      case "after_hours_wave":
        return await runAfterHours(symbol, market, settings, sym.id, opts.timeframe, providerName);
      case "weekly_price_channel":
        return await runWeekly(symbol, market, settings, sym.id, opts.timeframe, providerName);
      default:
        throw new Error(`Unknown strategy: ${opts.strategy}`);
    }
  } catch (e) {
    const msg =
      e instanceof ProviderError
        ? e.message
        : e instanceof Error
          ? e.message
          : "خطأ غير معروف";
    const result: AnalysisResult = {
      strategy: opts.strategy,
      symbol,
      market,
      timeframe: opts.timeframe || "1d",
      status: "ERROR",
      statusLabel: "خطأ في التحليل",
      score: null,
      dataQuality: "insufficient",
      lastUpdatedAt: new Date().toISOString(),
      dataSource: settings.dataProvider,
      dataSourceTime: null,
      supportZones: [],
      resistanceLevels: [],
      entryZones: [],
      stopLoss: null,
      targets: [],
      indicators: {},
      warnings: [msg],
      explanation: ["فشل التحليل بسبب خطأ في جلب أو معالجة البيانات."],
      annotations: { levels: [], zones: [], markers: [] },
    };
    return { result, bars: [] };
  }
}

async function runReverseSplit(
  symbol: string,
  market: Market,
  settings: AppSettings,
  symbolId: number,
  timeframe?: Timeframe,
  providerName?: string,
): Promise<AnalysisWithBars> {
  // الفريمات المدعومة: 1d (أساسي) · 4h (تحليل كامل) · 1w (سياق)
  const tf: Timeframe =
    timeframe === "4h" || timeframe === "1w" || timeframe === "1d"
      ? timeframe
      : "1d";

  // اجلب الفريم المطلوب + يومي للسياق عند 4h (للشرح فقط إن لزم)
  const [barsRes, dailyRes, corpRes] = await Promise.all([
    fetchBars({ symbol, market, timeframe: tf, providerName }),
    tf === "4h"
      ? fetchBars({ symbol, market, timeframe: "1d", providerName })
      : Promise.resolve(null),
    fetchCorporateActions(symbol, market, providerName),
  ]);

  // استخدم شموع الفريم المختار للتحليل — 4h يُحلَّل على 4h مباشرة
  const bars = barsRes.bars;
  const shortData = getLatestShortData(symbolId);
  const result = analyzeReverseSplit({
    symbol,
    market,
    timeframe: tf,
    bars,
    reverseSplits: corpRes.actions,
    settings: settings.reverseSplit,
    dataSource: barsRes.source,
    dataSourceTime: barsRes.fetchedAt,
  });

  if (barsRes.warning) result.warnings.push(barsRes.warning);
  if (barsRes.stale) result.warnings.push("بيانات السعر متأخرة.");
  if (corpRes.warning) result.warnings.push(corpRes.warning);
  if (tf === "4h" && dailyRes && dailyRes.bars.length > 0) {
    result.meta = {
      ...(result.meta || {}),
      dailyBarsAvailable: dailyRes.bars.length,
      primaryTimeframe: "4h",
    };
  }
  if (!shortData) {
    result.warnings.push("بيانات الشورت غير متوفرة.");
  } else if (shortData.reportedAt) {
    const age =
      Date.now() - new Date(shortData.reportedAt).getTime();
    if (age > 30 * 86400000) {
      result.warnings.push("بيانات الاقتراض قديمة.");
    }
  }

  if (bars.length === 0) {
    result.warnings.push("لا توجد شموع على الفريم المختار.");
  }

  result.explanation.push("لم يتم فحص الأخبار آلياً.");

  persist(symbolId, result);
  return { result, bars };
}

async function runAfterHours(
  symbol: string,
  market: Market,
  settings: AppSettings,
  symbolId: number,
  timeframe?: Timeframe,
  providerName?: string,
): Promise<AnalysisWithBars> {
  const tf: Timeframe = timeframe || "5m";
  const [bars5, bars15, bars4h, ext, quote] = await Promise.all([
    fetchBars({ symbol, market, timeframe: "5m", providerName }),
    fetchBars({ symbol, market, timeframe: "15m", providerName }),
    fetchBars({ symbol, market, timeframe: "4h", providerName }),
    fetchExtendedHours(symbol, market, providerName),
    fetchQuote(symbol, market, providerName).catch(() => null),
  ]);

  let minutesSinceOpen: number | null = null;
  if (ext.sessionStart) {
    minutesSinceOpen = Math.max(
      0,
      Math.round((Date.now() - new Date(ext.sessionStart).getTime()) / 60000),
    );
  }

  const result = analyzeAfterHoursWave({
    symbol,
    market,
    timeframe: tf,
    bars5m: bars5.bars,
    bars15m: bars15.bars,
    bars4h: bars4h.bars,
    extended: ext,
    previousClose: quote?.previousClose ?? null,
    minutesSinceOpen,
    settings: settings.afterHoursWave,
    dataSource: bars5.source,
    dataSourceTime: bars5.fetchedAt,
  });

  if (bars5.warning) result.warnings.push(bars5.warning);
  if (bars5.stale) result.warnings.push("بيانات السعر متأخرة.");
  result.explanation.push("لم يتم فحص الأخبار آلياً.");

  persist(symbolId, result);

  const bars =
    tf === "15m" ? bars15.bars : tf === "4h" ? bars4h.bars : bars5.bars;
  return { result, bars };
}

async function runWeekly(
  symbol: string,
  market: Market,
  settings: AppSettings,
  symbolId: number,
  timeframe?: Timeframe,
  providerName?: string,
): Promise<AnalysisWithBars> {
  const tf: Timeframe = timeframe || "1d";
  const [daily, h4, weekly, mcap, quote] = await Promise.all([
    fetchBars({ symbol, market, timeframe: "1d", providerName }),
    fetchBars({ symbol, market, timeframe: "4h", providerName }),
    fetchBars({ symbol, market, timeframe: "1w", providerName }),
    fetchMarketCap(symbol, market, providerName),
    fetchQuote(symbol, market, providerName).catch(() => null),
  ]);

  const result = analyzeWeeklyChannel({
    symbol,
    market,
    timeframe: tf,
    barsDaily: daily.bars,
    bars4h: h4.bars,
    barsWeekly: weekly.bars,
    marketCap: mcap,
    lastPrice: quote?.price ?? null,
    settings: settings.weeklyChannel,
    dataSource: daily.source,
    dataSourceTime: daily.fetchedAt,
  });

  if (daily.warning) result.warnings.push(daily.warning);
  if (daily.stale) result.warnings.push("بيانات السعر متأخرة.");
  result.explanation.push("لم يتم فحص الأخبار آلياً.");

  persist(symbolId, result);

  const bars =
    tf === "4h" ? h4.bars : tf === "1w" ? weekly.bars : daily.bars;
  return { result, bars };
}

function persist(symbolId: number, result: AnalysisResult): void {
  try {
    saveAnalysisRun({
      symbolId,
      strategyKey: result.strategy,
      timeframe: result.timeframe,
      analysisDate: new Date().toISOString(),
      status: result.status,
      score: result.score,
      resultJson: JSON.stringify(result),
      dataSourceTime: result.dataSourceTime,
    });
  } catch {
    // storage failure should not hide analysis result
    result.warnings.push("فشل حفظ نتيجة التحليل في قاعدة البيانات.");
  }
}
