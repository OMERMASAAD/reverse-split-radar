import type {
  Market,
  Timeframe,
  PriceBar,
  CorporateAction,
  Quote,
  ExtendedQuote,
  MarketCap,
} from "@/types";
import { getProvider, ProviderError } from "@/server/providers";
import {
  upsertSymbol,
  getSymbolByTicker,
  upsertBars,
  getBars,
  insertCorporateAction,
  getCorporateActions,
  getCache,
  setCache,
  isCacheFresh,
  getAppSettings,
} from "@/server/db/repositories";

export interface BarsResult {
  bars: PriceBar[];
  source: string;
  fetchedAt: string;
  fromCache: boolean;
  stale: boolean;
  warning?: string;
}

function defaultRange(timeframe: Timeframe): { from: string; to: string } {
  const to = new Date();
  const from = new Date(to);
  switch (timeframe) {
    case "5m":
      from.setUTCDate(from.getUTCDate() - 5);
      break;
    case "15m":
      from.setUTCDate(from.getUTCDate() - 10);
      break;
    case "4h":
      from.setUTCDate(from.getUTCDate() - 60);
      break;
    case "1d":
      from.setUTCFullYear(from.getUTCFullYear() - 1);
      break;
    case "1w":
      from.setUTCFullYear(from.getUTCFullYear() - 5);
      break;
  }
  return { from: from.toISOString(), to: to.toISOString() };
}

export async function fetchBars(opts: {
  symbol: string;
  market?: Market;
  timeframe: Timeframe;
  from?: string;
  to?: string;
  forceRefresh?: boolean;
  providerName?: string;
}): Promise<BarsResult> {
  const market = opts.market || "US";
  const settings = getAppSettings();
  const range =
    opts.from && opts.to
      ? { from: opts.from, to: opts.to }
      : defaultRange(opts.timeframe);

  const provider = getProvider(opts.providerName || settings.dataProvider);
  const cacheKey = `bars:${provider.name}:${market}:${opts.symbol.toUpperCase()}:${opts.timeframe}:${range.from.slice(0, 10)}:${range.to.slice(0, 10)}`;
  const cached = getCache(cacheKey);

  if (cached && isCacheFresh(cached.expiresAt) && !opts.forceRefresh) {
    const bars = JSON.parse(cached.payload) as PriceBar[];
    return {
      bars,
      source: cached.source,
      fetchedAt: cached.fetchedAt,
      fromCache: true,
      stale: false,
    };
  }

  const sym = upsertSymbol({ symbol: opts.symbol, market });

  try {
    const bars = await provider.getBars(
      opts.symbol.toUpperCase(),
      market,
      opts.timeframe,
      range.from,
      range.to,
    );

    if (bars.length) {
      upsertBars(sym.id, bars);
      setCache(
        cacheKey,
        JSON.stringify(bars),
        provider.name,
        settings.cacheTtlSeconds,
      );
    }

    return {
      bars,
      source: provider.name,
      fetchedAt: new Date().toISOString(),
      fromCache: false,
      stale: false,
    };
  } catch (e) {
    // On failure: return last DB/cache data with warning — never invent
    const dbBars = getBars(sym.id, opts.timeframe, range.from, range.to)
      .filter((bar) => bar.source === provider.name);
    if (dbBars.length) {
      return {
        bars: dbBars,
        source: dbBars[0]?.source || "cache",
        fetchedAt: cached?.fetchedAt || new Date().toISOString(),
        fromCache: true,
        stale: true,
        warning:
          e instanceof ProviderError
            ? `انقطاع المزود: ${e.message}. تُعرض آخر بيانات محفوظة.`
            : "انقطاع المزود. تُعرض آخر بيانات محفوظة.",
      };
    }
    if (cached) {
      return {
        bars: JSON.parse(cached.payload) as PriceBar[],
        source: cached.source,
        fetchedAt: cached.fetchedAt,
        fromCache: true,
        stale: true,
        warning: "انقطاع المزود. تُعرض بيانات مخبأة قديمة.",
      };
    }
    throw e;
  }
}

export async function fetchCorporateActions(
  symbol: string,
  market: Market = "US",
  providerName?: string,
): Promise<{ actions: CorporateAction[]; source: string; warning?: string }> {
  const settings = getAppSettings();
  const provider = getProvider(providerName || settings.dataProvider);
  const sym = upsertSymbol({ symbol, market });
  const cacheKey = `corp:${provider.name}:${market}:${symbol.toUpperCase()}`;
  const cached = getCache(cacheKey);

  if (cached && isCacheFresh(cached.expiresAt)) {
    return {
      actions: JSON.parse(cached.payload) as CorporateAction[],
      source: cached.source,
    };
  }

  try {
    const actions = await provider.getCorporateActions(
      symbol.toUpperCase(),
      market,
    );
    // Persist confirmed ones
    const existing = getCorporateActions(sym.id);
    const existingKeys = new Set(
      existing.map((a) => `${a.actionType}:${a.actionDate}`),
    );
    for (const a of actions) {
      const key = `${a.actionType}:${a.actionDate}`;
      if (!existingKeys.has(key)) {
        insertCorporateAction(sym.id, a);
      }
    }
    setCache(
      cacheKey,
      JSON.stringify(actions),
      provider.name,
      Math.max(settings.cacheTtlSeconds, 3600),
    );
    return { actions, source: provider.name };
  } catch (e) {
    const existing = getCorporateActions(sym.id).filter((action) => action.source === provider.name);
    if (existing.length) {
      return {
        actions: existing,
        source: existing[0]?.source || "db",
        warning: "تعذر تحديث إجراءات الشركة — تُعرض المحفوظة.",
      };
    }
    if (cached) {
      return {
        actions: JSON.parse(cached.payload) as CorporateAction[],
        source: cached.source,
        warning: "تعذر تحديث إجراءات الشركة — بيانات مخبأة.",
      };
    }
    return { actions: [], source: provider.name, warning: "لا توجد بيانات تقسيم." };
  }
}

export async function fetchQuote(
  symbol: string,
  market: Market = "US",
  providerName?: string,
): Promise<Quote> {
  const settings = getAppSettings();
  const provider = getProvider(providerName || settings.dataProvider);
  return provider.getQuote(symbol.toUpperCase(), market);
}

export async function fetchExtendedHours(
  symbol: string,
  market: Market = "US",
  providerName?: string,
): Promise<ExtendedQuote> {
  const settings = getAppSettings();
  const provider = getProvider(providerName || settings.dataProvider);
  return provider.getExtendedHours(symbol.toUpperCase(), market);
}

export async function fetchMarketCap(
  symbol: string,
  market: Market = "US",
  providerName?: string,
): Promise<MarketCap | null> {
  const settings = getAppSettings();
  const provider = getProvider(providerName || settings.dataProvider);
  return provider.getMarketCap(symbol.toUpperCase(), market);
}

export function ensureSymbol(symbol: string, market: Market = "US") {
  return upsertSymbol({ symbol, market });
}

export function getStoredSymbol(symbol: string, market: Market = "US") {
  return getSymbolByTicker(symbol, market);
}
