import type {
  PriceBar,
  Timeframe,
  Market,
  CorporateAction,
  Quote,
  ExtendedQuote,
  MarketCap,
} from "@/types";
import {
  MarketDataProvider,
  ProviderError,
  normalizeBars,
} from "./types";

/**
 * Yahoo Finance public chart API adapter (no API key required).
 * Used as default live provider. Never invents data.
 */

const TF_MAP: Record<
  Timeframe,
  { interval: string; range: string }
> = {
  "5m": { interval: "5m", range: "5d" },
  "15m": { interval: "15m", range: "10d" },
  "4h": { interval: "60m", range: "60d" }, // will resample to 4h
  "1d": { interval: "1d", range: "1y" },
  "1w": { interval: "1wk", range: "5y" },
};

export function yahooSymbol(symbol: string, market: Market): string {
  const clean = symbol.trim().toUpperCase();
  // Tadawul tickers are listed by Yahoo with the .SR suffix.
  return market === "SA" && !clean.includes(".") ? `${clean}.SR` : clean;
}

let lastRequestAt = 0;
let requestQueue: Promise<void> = Promise.resolve();
const MIN_GAP_MS = 350;

function throttledFetch(url: string): Promise<Response> {
  const request = requestQueue.then(async () => {
    const wait = MIN_GAP_MS - (Date.now() - lastRequestAt);
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
    lastRequestAt = Date.now();

    let res: Response;
    try {
      res = await fetch(url, {
        headers: {
          "User-Agent": "PivotScope/1.0 (market data client)",
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(7000),
        cache: "no-store",
      });
    } catch (e) {
      throw new ProviderError(
        e instanceof Error && e.name === "TimeoutError"
          ? "انتهت مهلة الاتصال بمزود البيانات. تحقق من اتصال الخادم بالإنترنت."
          : "تعذر الاتصال بمزود البيانات من الخادم.",
        "NETWORK",
        true,
      );
    }

    if (res.status === 429) {
      throw new ProviderError("تم تجاوز حد الطلبات من مزود البيانات", "RATE_LIMIT", true);
    }
    if (!res.ok) {
      throw new ProviderError(
        `فشل مزود البيانات: HTTP ${res.status}`,
        res.status === 404 ? "NOT_FOUND" : "NETWORK",
        res.status >= 500,
      );
    }
    return res;
  });
  requestQueue = request.then(() => undefined, () => undefined);
  return request;
}

interface YahooChartResult {
  chart?: {
    result?: Array<{
      meta?: {
        symbol?: string;
        currency?: string;
        exchangeName?: string;
        regularMarketPrice?: number;
        chartPreviousClose?: number;
        previousClose?: number;
        regularMarketVolume?: number;
        instrumentType?: string;
        currentTradingPeriod?: {
          pre?: { start?: number; end?: number };
          regular?: { start?: number; end?: number };
          post?: { start?: number; end?: number };
        };
      };
      timestamp?: number[];
      indicators?: {
        quote?: Array<{
          open?: Array<number | null>;
          high?: Array<number | null>;
          low?: Array<number | null>;
          close?: Array<number | null>;
          volume?: Array<number | null>;
        }>;
        adjclose?: Array<{ adjclose?: Array<number | null> }>;
      };
      events?: {
        splits?: Record<
          string,
          { date: number; numerator: number; denominator: number; splitRatio: string }
        >;
      };
    }>;
    error?: { code?: string; description?: string } | null;
  };
}

function resampleTo4h(bars: PriceBar[]): PriceBar[] {
  if (bars.length === 0) return [];
  const groups = new Map<string, PriceBar[]>();

  for (const b of bars) {
    const d = new Date(b.barTime);
    const h = d.getUTCHours();
    const bucketH = Math.floor(h / 4) * 4;
    const keyDate = new Date(
      Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), bucketH),
    );
    const key = keyDate.toISOString();
    const arr = groups.get(key) || [];
    arr.push(b);
    groups.set(key, arr);
  }

  const out: PriceBar[] = [];
  for (const [key, group] of [...groups.entries()].sort((a, b) =>
    a[0].localeCompare(b[0]),
  )) {
    const open = group[0].open;
    const close = group[group.length - 1].close;
    const high = Math.max(...group.map((g) => g.high));
    const low = Math.min(...group.map((g) => g.low));
    const volume = group.reduce((s, g) => s + g.volume, 0);
    out.push({
      timeframe: "4h",
      barTime: key,
      open,
      high,
      low,
      close,
      volume,
      vwap: null,
      source: "yahoo",
    });
  }
  return out;
}

function parseBars(
  data: YahooChartResult,
  timeframe: Timeframe,
): PriceBar[] {
  const result = data.chart?.result?.[0];
  if (!result?.timestamp?.length) return [];

  const q = result.indicators?.quote?.[0];
  if (!q) return [];

  const bars: PriceBar[] = [];
  for (let i = 0; i < result.timestamp.length; i++) {
    const o = q.open?.[i];
    const h = q.high?.[i];
    const l = q.low?.[i];
    const c = q.close?.[i];
    const v = q.volume?.[i];
    if (o == null || h == null || l == null || c == null) continue;
    if (![o, h, l, c].every(Number.isFinite)) continue;

    bars.push({
      timeframe: timeframe === "4h" ? "4h" : timeframe,
      barTime: new Date(result.timestamp[i] * 1000).toISOString(),
      open: o,
      high: h,
      low: l,
      close: c,
      volume: v != null && Number.isFinite(v) ? v : 0,
      vwap: null,
      source: "yahoo",
    });
  }

  const normalized = normalizeBars(bars);
  if (timeframe === "4h") return resampleTo4h(normalized);
  return normalized;
}

export class YahooProvider implements MarketDataProvider {
  readonly name = "yahoo";

  async getBars(
    symbol: string,
    market: Market,
    timeframe: Timeframe,
    from: string,
    to: string,
  ): Promise<PriceBar[]> {
    const map = TF_MAP[timeframe];
    const period1 = Math.floor(new Date(from).getTime() / 1000);
    const period2 = Math.floor(new Date(to).getTime() / 1000);

    // Prefer period1/period2 when valid; fall back to range
    let url: string;
    if (Number.isFinite(period1) && Number.isFinite(period2) && period2 > period1) {
      url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol(symbol, market))}?interval=${map.interval}&period1=${period1}&period2=${period2}&events=div%7Csplit&includePrePost=true`;
    } else {
      url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol(symbol, market))}?interval=${map.interval}&range=${map.range}&events=div%7Csplit&includePrePost=true`;
    }

    try {
      const res = await throttledFetch(url);
      const data = (await res.json()) as YahooChartResult;
      if (data.chart?.error) {
        throw new ProviderError(
          data.chart.error.description || "خطأ من مزود البيانات",
          "NOT_FOUND",
        );
      }
      return parseBars(data, timeframe);
    } catch (e) {
      if (e instanceof ProviderError) throw e;
      throw new ProviderError(
        e instanceof Error ? e.message : "خطأ شبكة غير معروف",
        "NETWORK",
        true,
      );
    }
  }

  async getCorporateActions(
    symbol: string,
    market: Market,
  ): Promise<CorporateAction[]> {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol(symbol, market))}?interval=1d&range=5y&events=split`;
    try {
      const res = await throttledFetch(url);
      const data = (await res.json()) as YahooChartResult;
      const splits = data.chart?.result?.[0]?.events?.splits || {};
      const actions: CorporateAction[] = [];

      for (const s of Object.values(splits)) {
        const num = s.numerator;
        const den = s.denominator;
        if (!num || !den) continue;
        // reverse split: numerator < denominator (e.g. 1-for-10 → num=1 den=10)
        // Yahoo: splitRatio like "1:10" means 1 new for 10 old = reverse
        const isReverse = num < den;
        const ratio = isReverse ? den / num : num / den;
        actions.push({
          actionType: isReverse ? "reverse_split" : "split",
          actionDate: new Date(s.date * 1000).toISOString().slice(0, 10),
          splitRatio: ratio,
          source: "yahoo",
          isConfirmed: true,
        });
      }

      return actions.sort((a, b) => b.actionDate.localeCompare(a.actionDate));
    } catch (e) {
      if (e instanceof ProviderError) throw e;
      throw new ProviderError(
        e instanceof Error ? e.message : "فشل جلب إجراءات الشركة",
        "NETWORK",
        true,
      );
    }
  }

  async getQuote(symbol: string, market: Market): Promise<Quote> {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol(symbol, market))}?interval=1d&range=5d`;
    try {
      const res = await throttledFetch(url);
      const data = (await res.json()) as YahooChartResult;
      const meta = data.chart?.result?.[0]?.meta;
      if (!meta?.regularMarketPrice) {
        throw new ProviderError(`الرمز ${symbol} غير موجود`, "NOT_FOUND");
      }
      return {
        symbol: meta.symbol || symbol,
        market,
        price: meta.regularMarketPrice,
        open: null,
        high: null,
        low: null,
        previousClose: meta.chartPreviousClose ?? meta.previousClose ?? null,
        volume: meta.regularMarketVolume ?? null,
        currency: meta.currency || "USD",
        asOf: new Date().toISOString(),
        source: "yahoo",
      };
    } catch (e) {
      if (e instanceof ProviderError) throw e;
      throw new ProviderError(
        e instanceof Error ? e.message : "فشل جلب السعر",
        "NETWORK",
        true,
      );
    }
  }

  async getExtendedHours(
    symbol: string,
    market: Market,
  ): Promise<ExtendedQuote> {
    // Yahoo chart with includePrePost can expose pre/post in meta periods,
    // but prices for AH/PM are not always reliable via free chart endpoint.
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol(symbol, market))}?interval=1m&range=1d&includePrePost=true`;
    try {
      const res = await throttledFetch(url);
      const data = (await res.json()) as YahooChartResult;
      const result = data.chart?.result?.[0];
      const meta = result?.meta;
      if (!meta) {
        return {
          symbol,
          market,
          premarketPrice: null,
          premarketVolume: null,
          afterHoursPrice: null,
          afterHoursVolume: null,
          sessionStart: null,
          asOf: new Date().toISOString(),
          source: "yahoo",
          available: false,
          message: "بيانات الأفتر/البري ماركت غير متوفرة من المصدر الحالي.",
        };
      }

      const timestamps = result.timestamp || [];
      const q = result.indicators?.quote?.[0];
      const regular = meta.currentTradingPeriod?.regular;
      const pre = meta.currentTradingPeriod?.pre;
      const post = meta.currentTradingPeriod?.post;

      let premarketPrice: number | null = null;
      let premarketVolume = 0;
      let afterHoursPrice: number | null = null;
      let afterHoursVolume = 0;

      if (q && timestamps.length && regular?.start && regular?.end) {
        for (let i = 0; i < timestamps.length; i++) {
          const t = timestamps[i];
          const c = q.close?.[i];
          const v = q.volume?.[i] ?? 0;
          if (c == null || !Number.isFinite(c)) continue;
          if (pre?.start && pre?.end && t >= pre.start && t < regular.start) {
            premarketPrice = c;
            premarketVolume += v || 0;
          }
          if (post?.start && post?.end && t >= regular.end && t <= post.end) {
            afterHoursPrice = c;
            afterHoursVolume += v || 0;
          }
        }
      }

      const available = premarketPrice != null || afterHoursPrice != null;
      return {
        symbol,
        market,
        premarketPrice,
        premarketVolume: premarketVolume || null,
        afterHoursPrice,
        afterHoursVolume: afterHoursVolume || null,
        sessionStart: regular?.start
          ? new Date(regular.start * 1000).toISOString()
          : null,
        asOf: new Date().toISOString(),
        source: "yahoo",
        available,
        message: available
          ? undefined
          : "بيانات الأفتر/البري ماركت غير متوفرة من المصدر الحالي.",
      };
    } catch (e) {
      return {
        symbol,
        market,
        premarketPrice: null,
        premarketVolume: null,
        afterHoursPrice: null,
        afterHoursVolume: null,
        sessionStart: null,
        asOf: new Date().toISOString(),
        source: "yahoo",
        available: false,
        message: "بيانات الأفتر/البري ماركت غير متوفرة من المصدر الحالي.",
      };
    }
  }

  async getMarketCap(
    symbol: string,
    market: Market,
  ): Promise<MarketCap | null> {
    // Free chart endpoint does not reliably expose market cap.
    // Return null rather than inventing a value.
    void symbol;
    void market;
    return null;
  }
}
