import { describe, expect, it } from "vitest";
import { yahooSymbol } from "./yahoo";

describe("Yahoo ticker mapping", () => {
  it("adds the Tadawul suffix for Saudi symbols", () => {
    expect(yahooSymbol("2222", "SA")).toBe("2222.SR");
    expect(yahooSymbol("2222.SR", "SA")).toBe("2222.SR");
  });

  it("preserves US and explicitly suffixed tickers", () => {
    expect(yahooSymbol("aapl", "US")).toBe("AAPL");
    expect(yahooSymbol("BRK.B", "US")).toBe("BRK.B");
    expect(yahooSymbol("^GSPC", "OTHER")).toBe("^GSPC");
  });
});
