import type { MarketDataProvider } from "./types";
import { YahooProvider } from "./yahoo";
import { DemoProvider } from "./demo";
import { getAppSettings } from "@/server/db/repositories";

export * from "./types";
export { YahooProvider } from "./yahoo";
export { DemoProvider } from "./demo";

const providers: Record<string, () => MarketDataProvider> = {
  yahoo: () => new YahooProvider(),
  demo: () => new DemoProvider(),
};

export function getProvider(name?: string): MarketDataProvider {
  const settingsName =
    name ||
    process.env.MARKET_DATA_PROVIDER ||
    (() => {
      try {
        return getAppSettings().dataProvider;
      } catch {
        return "yahoo";
      }
    })();

  const factory = providers[settingsName];
  if (!factory) {
    // Fall back to yahoo; never invent a fake live provider
    return new YahooProvider();
  }
  return factory();
}

export function listProviders(): string[] {
  return Object.keys(providers);
}
