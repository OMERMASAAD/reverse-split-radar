import type {
  PriceBar,
  Timeframe,
  Market,
  CorporateAction,
  Quote,
  ExtendedQuote,
  MarketCap,
} from "@/types";
import { MarketDataProvider, normalizeBars } from "./types";

/**
 * Demo provider — clearly synthetic data for UI/testing only.
 * Never used as live analysis without demo mode flag.
 */

function seededRandom(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function hashSymbol(symbol: string): number {
  let h = 0;
  for (let i = 0; i < symbol.length; i++) {
    h = (h * 31 + symbol.charCodeAt(i)) >>> 0;
  }
  return h || 1;
}

function timeframeMs(tf: Timeframe): number {
  switch (tf) {
    case "5m":
      return 5 * 60 * 1000;
    case "15m":
      return 15 * 60 * 1000;
    case "4h":
      return 4 * 60 * 60 * 1000;
    case "1d":
      return 24 * 60 * 60 * 1000;
    case "1w":
      return 7 * 24 * 60 * 60 * 1000;
  }
}

function detectScenario(
  symbol: string,
): "reverse_split" | "after_hours" | "channel" | "generic" {
  const s = symbol.toUpperCase();
  if (s.startsWith("RS") || s.includes("SPLIT")) return "reverse_split";
  if (s.startsWith("AH") || s.includes("WAVE")) return "after_hours";
  if (s.startsWith("CH") || s.includes("CHAN")) return "channel";
  return "generic";
}

/** Fixed split date: 35 calendar days ago */
function demoSplitDate(): Date {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - 35);
  return d;
}

function generateReverseSplitDaily(symbol: string): PriceBar[] {
  const rand = seededRandom(hashSymbol(symbol + "rs"));
  const split = demoSplitDate();
  const bars: PriceBar[] = [];

  // 10 pre-split bars
  let price = 1.2;
  for (let i = -10; i < 0; i++) {
    const t = new Date(split);
    t.setUTCDate(split.getUTCDate() + i);
    const open = price;
    const close = price * (1 + (rand() - 0.5) * 0.03);
    bars.push({
      timeframe: "1d",
      barTime: t.toISOString(),
      open: +open.toFixed(4),
      high: +Math.max(open, close).toFixed(4) * 1.01,
      low: +Math.min(open, close).toFixed(4) * 0.99,
      close: +close.toFixed(4),
      volume: Math.floor(800_000 + rand() * 400_000),
      vwap: +((open + close) / 2).toFixed(4),
      source: "demo",
    });
    price = close;
  }

  // Post-split path over 35 sessions
  // Day 0 open = 10
  // Days 1-3 rally to ~11.5 (+15%)
  // Days 4-18 decline to ~5.2 (~55% from peak)
  // Days 19-28 support base
  // Days 29-34 higher low + breakout
  const path: number[] = [];
  path.push(10); // 0 open reference via close series
  let p = 10;
  for (let i = 0; i < 35; i++) {
    if (i === 0) p = 10.2;
    else if (i === 1) p = 10.9;
    else if (i === 2) p = 11.4;
    else if (i === 3) p = 11.7; // peak area
    else if (i <= 18) {
      // decline toward 5.2
      const target = 5.2;
      p = p + (target - p) * 0.22;
    } else if (i <= 28) {
      p = 5.2 + (rand() - 0.5) * 0.15;
    } else if (i === 29) p = 5.5;
    else if (i === 30) p = 5.9;
    else if (i === 31) p = 6.2;
    else if (i === 32) p = 7.0; // breakout
    else if (i === 33) p = 7.1;
    else p = 7.0;

    const t = new Date(split);
    t.setUTCDate(split.getUTCDate() + i);
    const open = i === 0 ? 10 : bars[bars.length - 1]?.close ?? p;
    const close = p;
    const high = Math.max(open, close) * (1 + rand() * 0.01 + (i === 3 ? 0.02 : 0));
    const low = Math.min(open, close) * (1 - rand() * 0.01);
    const volume =
      i >= 32 ? Math.floor(2_500_000 + rand() * 500_000) : Math.floor(900_000 + rand() * 600_000);

    bars.push({
      timeframe: "1d",
      barTime: t.toISOString(),
      open: +open.toFixed(4),
      high: +high.toFixed(4),
      low: +low.toFixed(4),
      close: +close.toFixed(4),
      volume,
      vwap: +((open + high + low + close) / 4).toFixed(4),
      source: "demo",
    });
  }

  return normalizeBars(bars);
}

function generateChannelDaily(symbol: string): PriceBar[] {
  const rand = seededRandom(hashSymbol(symbol + "ch"));
  const bars: PriceBar[] = [];
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  start.setUTCDate(start.getUTCDate() - 90);

  for (let i = 0; i < 90; i++) {
    const t = new Date(start);
    t.setUTCDate(start.getUTCDate() + i);
    const phase = Math.sin(i / 5);
    const mid = 7.5;
    const amp = 1.35;
    const c = mid + phase * amp + (rand() - 0.5) * 0.05;
    const open = c - 0.08;
    const close = c + 0.05 * (rand() - 0.5);
    bars.push({
      timeframe: "1d",
      barTime: t.toISOString(),
      open: +open.toFixed(4),
      high: +(Math.max(open, close) + 0.25).toFixed(4),
      low: +(Math.min(open, close) - 0.25).toFixed(4),
      close: +close.toFixed(4),
      volume: Math.floor(1_000_000 + rand() * 500_000),
      vwap: +c.toFixed(4),
      source: "demo",
    });
  }
  return normalizeBars(bars);
}

function generateAfterHoursIntraday(
  symbol: string,
  timeframe: Timeframe,
): PriceBar[] {
  const rand = seededRandom(hashSymbol(symbol + timeframe + "ah"));
  const step = timeframeMs(timeframe);
  const bars: PriceBar[] = [];
  // Session start today 13:30 UTC
  const start = new Date();
  start.setUTCHours(13, 30, 0, 0);
  // Deterministic OHLC path: W1 10→12, W2 to 11 (50%), W3 breakout
  const closes = [
    10.0, 10.4, 10.9, 11.5, 12.0, // wave 1
    11.7, 11.4, 11.1, 11.0, // wave 2 ~50% of 2.0 range
    11.2, 11.5, 11.8, 12.1, 12.4, // wave 3 start
  ];
  while (closes.length < 40) {
    closes.push(closes[closes.length - 1] + (rand() - 0.4) * 0.1);
  }
  let price = closes[0];
  for (let i = 0; i < closes.length; i++) {
    const open = price;
    const close = closes[i];
    const high = Math.max(open, close) + 0.05;
    const low = Math.min(open, close) - 0.05;
    bars.push({
      timeframe,
      barTime: new Date(start.getTime() + i * step).toISOString(),
      open: +open.toFixed(4),
      high: +high.toFixed(4),
      low: +low.toFixed(4),
      close: +close.toFixed(4),
      volume: Math.floor(
        i >= 12 ? 200_000 + rand() * 50_000 : 100_000 + rand() * 30_000,
      ),
      vwap: +((open + high + low + close) / 4).toFixed(4),
      source: "demo",
    });
    price = close;
  }
  return normalizeBars(bars);
}

function generateGeneric(
  symbol: string,
  timeframe: Timeframe,
  from: string,
  to: string,
): PriceBar[] {
  const rand = seededRandom(hashSymbol(symbol + timeframe));
  const start = new Date(from).getTime();
  const end = new Date(to).getTime();
  const step = timeframeMs(timeframe);
  const bars: PriceBar[] = [];
  let price = 25 + (hashSymbol(symbol) % 50);
  let i = 0;
  for (let t = start; t <= end && i < 400; t += step) {
    i++;
    const open = price;
    const close = Math.max(1, open * (1 + (rand() - 0.49) * 0.02));
    bars.push({
      timeframe,
      barTime: new Date(t).toISOString(),
      open: +open.toFixed(4),
      high: +Math.max(open, close).toFixed(4) * 1.005,
      low: +Math.min(open, close).toFixed(4) * 0.995,
      close: +close.toFixed(4),
      volume: Math.floor(500_000 + rand() * 500_000),
      vwap: null,
      source: "demo",
    });
    price = close;
  }
  return normalizeBars(bars);
}

export class DemoProvider implements MarketDataProvider {
  readonly name = "demo";

  async getBars(
    symbol: string,
    _market: Market,
    timeframe: Timeframe,
    from: string,
    to: string,
  ): Promise<PriceBar[]> {
    const scenario = detectScenario(symbol);

    if (scenario === "reverse_split") {
      if (timeframe === "1d" || timeframe === "1w" || timeframe === "4h") {
        const daily = generateReverseSplitDaily(symbol);
        if (timeframe === "1d") return daily;
        if (timeframe === "1w") {
          // downsample roughly
          return daily.filter((_, idx) => idx % 5 === 0).map((b) => ({
            ...b,
            timeframe: "1w" as const,
          }));
        }
        // 4h: 2 bars per session day with realistic OHLC path (for reverse-split 4h analysis)
        const out: PriceBar[] = [];
        for (const b of daily) {
          const t0 = new Date(b.barTime).getTime();
          const mid = (b.open + b.close) / 2;
          const volHalf = Math.max(1, Math.floor(b.volume / 2));
          // morning bar
          out.push({
            timeframe: "4h",
            barTime: new Date(t0 + 14 * 3600 * 1000).toISOString(), // ~14:00 UTC
            open: b.open,
            high: Math.max(b.open, mid, b.high * 0.995),
            low: Math.min(b.open, mid, b.low * 1.002),
            close: mid,
            volume: volHalf,
            vwap: mid,
            source: "demo",
          });
          // afternoon bar
          out.push({
            timeframe: "4h",
            barTime: new Date(t0 + 18 * 3600 * 1000).toISOString(), // ~18:00 UTC
            open: mid,
            high: Math.max(mid, b.close, b.high),
            low: Math.min(mid, b.close, b.low),
            close: b.close,
            volume: volHalf,
            vwap: (mid + b.close) / 2,
            source: "demo",
          });
        }
        return normalizeBars(out);
      }
    }

    if (scenario === "channel") {
      if (timeframe === "1d" || timeframe === "1w" || timeframe === "4h") {
        const daily = generateChannelDaily(symbol);
        if (timeframe === "1d") return daily;
        if (timeframe === "1w") {
          return daily.filter((_, idx) => idx % 5 === 0).map((b) => ({
            ...b,
            timeframe: "1w" as const,
          }));
        }
        const out: PriceBar[] = [];
        for (const b of daily) {
          const t0 = new Date(b.barTime).getTime();
          out.push({
            ...b,
            timeframe: "4h",
            barTime: new Date(t0).toISOString(),
          });
          out.push({
            ...b,
            timeframe: "4h",
            barTime: new Date(t0 + 4 * 3600 * 1000).toISOString(),
            open: b.close,
          });
        }
        return normalizeBars(out);
      }
    }

    if (scenario === "after_hours") {
      if (timeframe === "5m" || timeframe === "15m" || timeframe === "4h") {
        return generateAfterHoursIntraday(symbol, timeframe);
      }
    }

    return generateGeneric(symbol, timeframe, from, to);
  }

  async getCorporateActions(
    symbol: string,
    _market: Market,
  ): Promise<CorporateAction[]> {
    if (detectScenario(symbol) !== "reverse_split") return [];
    const d = demoSplitDate();
    return [
      {
        actionType: "reverse_split",
        actionDate: d.toISOString().slice(0, 10),
        splitRatio: 10,
        source: "demo",
        isConfirmed: true,
      },
    ];
  }

  async getQuote(symbol: string, market: Market): Promise<Quote> {
    const scenario = detectScenario(symbol);
    // Keep AH demo quote consistent with extended-hours scenario (prev close 10)
    if (scenario === "after_hours") {
      return {
        symbol,
        market,
        price: 11.5,
        open: 10.2,
        high: 12.2,
        low: 10.0,
        previousClose: 10,
        volume: 2_000_000,
        currency: "USD",
        asOf: new Date().toISOString(),
        source: "demo",
      };
    }
    const to = new Date();
    const from = new Date(to.getTime() - 10 * 86400000);
    const bars = await this.getBars(
      symbol,
      market,
      "1d",
      from.toISOString(),
      to.toISOString(),
    );
    const last = bars[bars.length - 1];
    return {
      symbol,
      market,
      price: last?.close ?? 10,
      open: last?.open ?? null,
      high: last?.high ?? null,
      low: last?.low ?? null,
      previousClose: bars[bars.length - 2]?.close ?? last?.open ?? null,
      volume: last?.volume ?? null,
      currency: "USD",
      asOf: new Date().toISOString(),
      source: "demo",
    };
  }

  async getExtendedHours(
    symbol: string,
    market: Market,
  ): Promise<ExtendedQuote> {
    const scenario = detectScenario(symbol);
    if (scenario === "after_hours") {
      const sessionStart = new Date();
      sessionStart.setUTCHours(13, 30, 0, 0);
      return {
        symbol,
        market,
        premarketPrice: 10.5,
        premarketVolume: 800_000,
        afterHoursPrice: 13.5, // +35% vs prev close 10
        afterHoursVolume: 50_000_000, // high vs intraday avg
        // minutes since open ~ 25 so observation window is satisfied in daytime runs
        sessionStart: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        asOf: new Date().toISOString(),
        source: "demo",
        available: true,
      };
    }
    return {
      symbol,
      market,
      premarketPrice: null,
      premarketVolume: null,
      afterHoursPrice: null,
      afterHoursVolume: null,
      sessionStart: null,
      asOf: new Date().toISOString(),
      source: "demo",
      available: false,
      message: "بيانات الأفتر/البري ماركت غير متوفرة من المصدر الحالي.",
    };
  }

  async getMarketCap(
    symbol: string,
    market: Market,
  ): Promise<MarketCap | null> {
    const scenario = detectScenario(symbol);
    return {
      symbol,
      market,
      marketCap: scenario === "channel" ? 2_500_000_000 : 150_000_000,
      currency: "USD",
      asOf: new Date().toISOString(),
      source: "demo",
    };
  }
}
