import type {
  PriceBar,
  Timeframe,
  Market,
  CorporateAction,
  Quote,
  ExtendedQuote,
  MarketCap,
} from "@/types";

/**
 * Market data provider adapter.
 * Strategy engines must NEVER reference a concrete provider name.
 */
export interface MarketDataProvider {
  readonly name: string;

  getBars(
    symbol: string,
    market: Market,
    timeframe: Timeframe,
    from: string,
    to: string,
  ): Promise<PriceBar[]>;

  getCorporateActions(
    symbol: string,
    market: Market,
  ): Promise<CorporateAction[]>;

  getQuote(symbol: string, market: Market): Promise<Quote>;

  getExtendedHours(symbol: string, market: Market): Promise<ExtendedQuote>;

  getMarketCap(symbol: string, market: Market): Promise<MarketCap | null>;
}

export class ProviderError extends Error {
  constructor(
    message: string,
    public readonly code:
      | "RATE_LIMIT"
      | "NETWORK"
      | "NOT_FOUND"
      | "UNSUPPORTED"
      | "PARSE"
      | "UNKNOWN",
    public readonly retryable = false,
  ) {
    super(message);
    this.name = "ProviderError";
  }
}

/** Validate bar ordering and uniqueness */
export function normalizeBars(bars: PriceBar[]): PriceBar[] {
  const seen = new Set<string>();
  const cleaned: PriceBar[] = [];

  const sorted = [...bars].sort(
    (a, b) => new Date(a.barTime).getTime() - new Date(b.barTime).getTime(),
  );

  for (const bar of sorted) {
    if (!bar.barTime || !Number.isFinite(bar.open) || !Number.isFinite(bar.close)) {
      continue;
    }
    if (bar.high < bar.low) continue;
    if (bar.high < Math.max(bar.open, bar.close)) continue;
    if (bar.low > Math.min(bar.open, bar.close)) continue;
    if (seen.has(bar.barTime)) continue;
    seen.add(bar.barTime);
    cleaned.push(bar);
  }
  return cleaned;
}
