import Database from "better-sqlite3";
import fs from "fs";
import path from "path";

const globalForDb = globalThis as unknown as {
  __pivotscopeDb?: Database.Database;
};

function resolveDbPath(): string {
  const configured = process.env.DATABASE_PATH || "./data/pivotscope.db";
  return path.isAbsolute(configured)
    ? configured
    : path.join(process.cwd(), configured);
}

function ensureSchema(db: Database.Database): void {
  const schemaPath = path.join(process.cwd(), "src/server/db/schema.sql");
  const sql = fs.readFileSync(schemaPath, "utf8");
  db.exec(sql);

  const applied = db
    .prepare(
      "SELECT 1 AS ok FROM schema_migrations WHERE name = ? LIMIT 1",
    )
    .get("001_initial") as { ok: number } | undefined;

  if (!applied) {
    db.prepare("INSERT INTO schema_migrations (name) VALUES (?)").run(
      "001_initial",
    );
  }
}

export function getDb(): Database.Database {
  if (globalForDb.__pivotscopeDb) {
    return globalForDb.__pivotscopeDb;
  }

  const dbPath = resolveDbPath();
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  const db = new Database(dbPath);
  db.pragma("foreign_keys = ON");
  db.pragma("journal_mode = WAL");
  ensureSchema(db);

  globalForDb.__pivotscopeDb = db;
  return db;
}

export function closeDb(): void {
  if (globalForDb.__pivotscopeDb) {
    globalForDb.__pivotscopeDb.close();
    globalForDb.__pivotscopeDb = undefined;
  }
}

/** Decimal helpers — store as string, compute as number carefully */
export function toDecimalString(value: number | string | null | undefined): string | null {
  if (value === null || value === undefined || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return null;
  return n.toFixed(8).replace(/\.?0+$/, (m) => (m.includes(".") ? m.replace(/0+$/, "").replace(/\.$/, "") : m)) || "0";
}

export function fromDecimal(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}
