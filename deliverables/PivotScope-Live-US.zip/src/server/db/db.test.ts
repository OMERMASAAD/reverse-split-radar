import { describe, it, expect, beforeAll, afterAll } from "vitest";
import fs from "fs";
import path from "path";
import os from "os";

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "pivotscope-db-"));
const dbPath = path.join(tmpDir, "test.db");
process.env.DATABASE_PATH = dbPath;

// Import after env set
import { getDb, closeDb } from "./client";
import {
  upsertSymbol,
  getSymbolByTicker,
  upsertBars,
  getBars,
  insertCorporateAction,
  getCorporateActions,
  addWatchlistItem,
  listWatchlist,
  upsertManualShortData,
  getLatestShortData,
  saveAnalysisRun,
  getAppSettings,
  setAppSettings,
  validateTimeframe,
} from "./repositories";
import { DEFAULT_APP_SETTINGS } from "@/types";

describe("database layer", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(() => {
    closeDb();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it("migrates from empty DB and creates tables", () => {
    const tables = getDb()
      .prepare(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name",
      )
      .all() as Array<{ name: string }>;
    const names = tables.map((t) => t.name);
    expect(names).toContain("symbols");
    expect(names).toContain("price_bars");
    expect(names).toContain("corporate_actions");
    expect(names).toContain("watchlist_items");
    expect(names).toContain("manual_short_data");
    expect(names).toContain("analysis_runs");
  });

  it("prevents duplicate symbol+market", () => {
    const a = upsertSymbol({ symbol: "aaa", market: "US", companyName: "A" });
    const b = upsertSymbol({ symbol: "AAA", market: "US", companyName: "A2" });
    expect(a.id).toBe(b.id);
    expect(getSymbolByTicker("AAA", "US")?.companyName).toBe("A2");
  });

  it("stores only allowed timeframes", () => {
    expect(validateTimeframe("1d")).toBe(true);
    expect(validateTimeframe("1h")).toBe(false);
    const sym = upsertSymbol({ symbol: "BARS", market: "US" });
    expect(() =>
      upsertBars(sym.id, [
        {
          timeframe: "1h" as never,
          barTime: "2024-01-01T00:00:00Z",
          open: 1,
          high: 1,
          low: 1,
          close: 1,
          volume: 1,
          vwap: null,
          source: "t",
        },
      ]),
    ).toThrow();
  });

  it("upserts bars and retrieves ordered", () => {
    const sym = upsertSymbol({ symbol: "OHLC", market: "US" });
    upsertBars(sym.id, [
      {
        timeframe: "1d",
        barTime: "2024-01-02T00:00:00Z",
        open: 2,
        high: 3,
        low: 1,
        close: 2.5,
        volume: 100,
        vwap: null,
        source: "t",
      },
      {
        timeframe: "1d",
        barTime: "2024-01-01T00:00:00Z",
        open: 1,
        high: 2,
        low: 0.5,
        close: 1.5,
        volume: 50,
        vwap: null,
        source: "t",
      },
    ]);
    const bars = getBars(sym.id, "1d");
    expect(bars.length).toBe(2);
    expect(bars[0].barTime < bars[1].barTime).toBe(true);
  });

  it("accepts empty short data without error", () => {
    const sym = upsertSymbol({ symbol: "SHORT", market: "US" });
    const data = upsertManualShortData({
      symbolId: sym.id,
      shortInterestShares: null,
      shortInterestPercent: null,
      daysToCover: null,
      borrowRatePercent: null,
      borrowAvailability: null,
      reportedAt: null,
      notes: null,
    });
    expect(data.id).toBeTruthy();
    expect(getLatestShortData(sym.id)?.shortInterestShares).toBeNull();
  });

  it("stores corporate actions", () => {
    const sym = upsertSymbol({ symbol: "SPLIT", market: "US" });
    insertCorporateAction(sym.id, {
      actionType: "reverse_split",
      actionDate: "2024-06-01",
      splitRatio: 10,
      source: "t",
      isConfirmed: true,
    });
    const actions = getCorporateActions(sym.id);
    expect(actions[0].actionType).toBe("reverse_split");
  });

  it("watchlist CRUD", () => {
    const sym = upsertSymbol({ symbol: "WATCH", market: "US" });
    addWatchlistItem({
      symbolId: sym.id,
      notes: "test",
      priority: 5,
      strategyHint: "reverse_split_support",
    });
    const list = listWatchlist();
    expect(list.some((w) => w.symbol === "WATCH")).toBe(true);
  });

  it("saves analysis run with data source time", () => {
    const sym = upsertSymbol({ symbol: "AN", market: "US" });
    const run = saveAnalysisRun({
      symbolId: sym.id,
      strategyKey: "reverse_split_support",
      timeframe: "1d",
      analysisDate: new Date().toISOString(),
      status: "INSUFFICIENT_DATA",
      score: null,
      resultJson: "{}",
      dataSourceTime: "2024-01-01T00:00:00Z",
    });
    expect(run.dataSourceTime).toBe("2024-01-01T00:00:00Z");
  });

  it("settings round-trip", () => {
    const s = getAppSettings();
    expect(s.language).toBe("ar");
    const next = setAppSettings({
      ...DEFAULT_APP_SETTINGS,
      cacheTtlSeconds: 120,
    });
    expect(next.cacheTtlSeconds).toBe(120);
  });
});
