import { getDb, closeDb } from "./client";

function main() {
  const db = getDb();
  const rows = db
    .prepare("SELECT name, applied_at FROM schema_migrations ORDER BY id")
    .all() as Array<{ name: string; applied_at: string }>;

  console.log("PivotScope migrations:");
  for (const row of rows) {
    console.log(`  ✓ ${row.name} @ ${row.applied_at}`);
  }

  const tables = db
    .prepare(
      "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name",
    )
    .all() as Array<{ name: string }>;
  console.log("Tables:", tables.map((t) => t.name).join(", "));
  closeDb();
}

main();
