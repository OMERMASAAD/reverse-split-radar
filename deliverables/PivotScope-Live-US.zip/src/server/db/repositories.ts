import { getDb, toDecimalString, fromDecimal } from "./client";
import type {
  Symbol,
  Market,
  PriceBar,
  Timeframe,
  CorporateAction,
  CorporateActionType,
  WatchlistItem,
  ManualShortData,
  AnalysisRun,
  StrategyKey,
  AnalysisStatus,
  AppSettings,
} from "@/types";
import { DEFAULT_APP_SETTINGS, ALLOWED_TIMEFRAMES } from "@/types";

/* ---------- Symbols ---------- */

interface SymbolRow {
  id: number;
  symbol: string;
  market: string;
  company_name: string | null;
  exchange: string | null;
  is_active: number;
  created_at: string;
  updated_at: string;
}

function mapSymbol(row: SymbolRow): Symbol {
  return {
    id: row.id,
    symbol: row.symbol,
    market: row.market as Market,
    companyName: row.company_name,
    exchange: row.exchange,
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function upsertSymbol(input: {
  symbol: string;
  market: Market;
  companyName?: string | null;
  exchange?: string | null;
}): Symbol {
  const db = getDb();
  const sym = input.symbol.trim().toUpperCase();
  const existing = db
    .prepare("SELECT * FROM symbols WHERE symbol = ? AND market = ?")
    .get(sym, input.market) as SymbolRow | undefined;

  if (existing) {
    db.prepare(
      `UPDATE symbols SET
        company_name = COALESCE(?, company_name),
        exchange = COALESCE(?, exchange),
        is_active = 1,
        updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
       WHERE id = ?`,
    ).run(input.companyName ?? null, input.exchange ?? null, existing.id);
    return getSymbolById(existing.id)!;
  }

  const result = db
    .prepare(
      `INSERT INTO symbols (symbol, market, company_name, exchange)
       VALUES (?, ?, ?, ?)`,
    )
    .run(sym, input.market, input.companyName ?? null, input.exchange ?? null);

  return getSymbolById(Number(result.lastInsertRowid))!;
}

export function getSymbolById(id: number): Symbol | null {
  const row = getDb()
    .prepare("SELECT * FROM symbols WHERE id = ?")
    .get(id) as SymbolRow | undefined;
  return row ? mapSymbol(row) : null;
}

export function getSymbolByTicker(
  symbol: string,
  market: Market = "US",
): Symbol | null {
  const row = getDb()
    .prepare("SELECT * FROM symbols WHERE symbol = ? AND market = ?")
    .get(symbol.trim().toUpperCase(), market) as SymbolRow | undefined;
  return row ? mapSymbol(row) : null;
}

export function listSymbols(activeOnly = true): Symbol[] {
  const sql = activeOnly
    ? "SELECT * FROM symbols WHERE is_active = 1 ORDER BY symbol"
    : "SELECT * FROM symbols ORDER BY symbol";
  return (getDb().prepare(sql).all() as SymbolRow[]).map(mapSymbol);
}

/* ---------- Price bars ---------- */

interface BarRow {
  id: number;
  symbol_id: number;
  timeframe: string;
  bar_time: string;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  vwap: string | null;
  source: string;
  created_at: string;
}

function mapBar(row: BarRow): PriceBar {
  return {
    id: row.id,
    symbolId: row.symbol_id,
    timeframe: row.timeframe as Timeframe,
    barTime: row.bar_time,
    open: fromDecimal(row.open) ?? 0,
    high: fromDecimal(row.high) ?? 0,
    low: fromDecimal(row.low) ?? 0,
    close: fromDecimal(row.close) ?? 0,
    volume: fromDecimal(row.volume) ?? 0,
    vwap: fromDecimal(row.vwap),
    source: row.source,
    createdAt: row.created_at,
  };
}

export function validateTimeframe(tf: string): tf is Timeframe {
  return (ALLOWED_TIMEFRAMES as readonly string[]).includes(tf);
}

export function upsertBars(symbolId: number, bars: PriceBar[]): number {
  const db = getDb();
  const stmt = db.prepare(
    `INSERT INTO price_bars
      (symbol_id, timeframe, bar_time, open, high, low, close, volume, vwap, source)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(symbol_id, timeframe, bar_time) DO UPDATE SET
       open = excluded.open,
       high = excluded.high,
       low = excluded.low,
       close = excluded.close,
       volume = excluded.volume,
       vwap = excluded.vwap,
       source = excluded.source`,
  );

  const tx = db.transaction((items: PriceBar[]) => {
    let count = 0;
    for (const b of items) {
      if (!validateTimeframe(b.timeframe)) {
        throw new Error(`Invalid timeframe: ${b.timeframe}`);
      }
      stmt.run(
        symbolId,
        b.timeframe,
        b.barTime,
        toDecimalString(b.open),
        toDecimalString(b.high),
        toDecimalString(b.low),
        toDecimalString(b.close),
        toDecimalString(b.volume) ?? "0",
        toDecimalString(b.vwap),
        b.source,
      );
      count += 1;
    }
    return count;
  });

  return tx(bars);
}

export function getBars(
  symbolId: number,
  timeframe: Timeframe,
  from?: string,
  to?: string,
  limit = 500,
): PriceBar[] {
  if (!validateTimeframe(timeframe)) {
    throw new Error(`Invalid timeframe: ${timeframe}`);
  }

  let sql = `SELECT * FROM price_bars
             WHERE symbol_id = ? AND timeframe = ?`;
  const params: unknown[] = [symbolId, timeframe];

  if (from) {
    sql += " AND bar_time >= ?";
    params.push(from);
  }
  if (to) {
    sql += " AND bar_time <= ?";
    params.push(to);
  }
  sql += " ORDER BY bar_time ASC LIMIT ?";
  params.push(limit);

  return (getDb().prepare(sql).all(...params) as BarRow[]).map(mapBar);
}

/* ---------- Corporate actions ---------- */

interface CorpRow {
  id: number;
  symbol_id: number;
  action_type: string;
  action_date: string;
  split_ratio: string | null;
  source: string;
  is_confirmed: number;
  created_at: string;
}

function mapCorp(row: CorpRow): CorporateAction {
  return {
    id: row.id,
    symbolId: row.symbol_id,
    actionType: row.action_type as CorporateActionType,
    actionDate: row.action_date,
    splitRatio: fromDecimal(row.split_ratio),
    source: row.source,
    isConfirmed: Boolean(row.is_confirmed),
    createdAt: row.created_at,
  };
}

export function insertCorporateAction(
  symbolId: number,
  action: Omit<CorporateAction, "id" | "symbolId" | "createdAt">,
): CorporateAction {
  const db = getDb();
  const result = db
    .prepare(
      `INSERT INTO corporate_actions
        (symbol_id, action_type, action_date, split_ratio, source, is_confirmed)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(
      symbolId,
      action.actionType,
      action.actionDate,
      toDecimalString(action.splitRatio),
      action.source,
      action.isConfirmed ? 1 : 0,
    );
  const row = db
    .prepare("SELECT * FROM corporate_actions WHERE id = ?")
    .get(Number(result.lastInsertRowid)) as CorpRow;
  return mapCorp(row);
}

export function getCorporateActions(symbolId: number): CorporateAction[] {
  return (
    getDb()
      .prepare(
        `SELECT * FROM corporate_actions
         WHERE symbol_id = ?
         ORDER BY action_date DESC`,
      )
      .all(symbolId) as CorpRow[]
  ).map(mapCorp);
}

export function getLatestReverseSplit(
  symbolId: number,
): CorporateAction | null {
  const row = getDb()
    .prepare(
      `SELECT * FROM corporate_actions
       WHERE symbol_id = ? AND action_type = 'reverse_split' AND is_confirmed = 1
       ORDER BY action_date DESC LIMIT 1`,
    )
    .get(symbolId) as CorpRow | undefined;
  return row ? mapCorp(row) : null;
}

/* ---------- Watchlist ---------- */

interface WatchRow {
  id: number;
  symbol_id: number;
  list_name: string;
  notes: string | null;
  priority: number;
  strategy_hint: string | null;
  reference_price: string | null;
  last_analysis_status: string | null;
  last_analysis_score: number | null;
  is_active: number;
  created_at: string;
  updated_at: string;
  symbol?: string;
  company_name?: string | null;
}

function mapWatch(row: WatchRow): WatchlistItem {
  return {
    id: row.id,
    symbolId: row.symbol_id,
    symbol: row.symbol,
    companyName: row.company_name ?? null,
    listName: row.list_name,
    notes: row.notes,
    priority: row.priority,
    strategyHint: (row.strategy_hint as StrategyKey) || null,
    referencePrice: fromDecimal(row.reference_price),
    lastAnalysisStatus: (row.last_analysis_status as AnalysisStatus) || null,
    lastAnalysisScore: row.last_analysis_score,
    isActive: Boolean(row.is_active),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function addWatchlistItem(input: {
  symbolId: number;
  listName?: string;
  notes?: string | null;
  priority?: number;
  strategyHint?: StrategyKey | null;
  referencePrice?: number | null;
}): WatchlistItem {
  const db = getDb();
  const result = db
    .prepare(
      `INSERT INTO watchlist_items
        (symbol_id, list_name, notes, priority, strategy_hint, reference_price)
       VALUES (?, ?, ?, ?, ?, ?)`,
    )
    .run(
      input.symbolId,
      input.listName ?? "default",
      input.notes ?? null,
      input.priority ?? 0,
      input.strategyHint ?? null,
      toDecimalString(input.referencePrice ?? null),
    );
  return getWatchlistItem(Number(result.lastInsertRowid))!;
}

export function getWatchlistItem(id: number): WatchlistItem | null {
  const row = getDb()
    .prepare(
      `SELECT w.*, s.symbol, s.company_name
       FROM watchlist_items w
       JOIN symbols s ON s.id = w.symbol_id
       WHERE w.id = ?`,
    )
    .get(id) as WatchRow | undefined;
  return row ? mapWatch(row) : null;
}

export function listWatchlist(activeOnly = true): WatchlistItem[] {
  const sql = activeOnly
    ? `SELECT w.*, s.symbol, s.company_name
       FROM watchlist_items w
       JOIN symbols s ON s.id = w.symbol_id
       WHERE w.is_active = 1
       ORDER BY w.priority DESC, w.updated_at DESC`
    : `SELECT w.*, s.symbol, s.company_name
       FROM watchlist_items w
       JOIN symbols s ON s.id = w.symbol_id
       ORDER BY w.priority DESC, w.updated_at DESC`;
  return (getDb().prepare(sql).all() as WatchRow[]).map(mapWatch);
}

export function updateWatchlistItem(
  id: number,
  patch: Partial<{
    notes: string | null;
    priority: number;
    strategyHint: StrategyKey | null;
    referencePrice: number | null;
    lastAnalysisStatus: AnalysisStatus | null;
    lastAnalysisScore: number | null;
    isActive: boolean;
    listName: string;
  }>,
): WatchlistItem | null {
  const db = getDb();
  const current = getWatchlistItem(id);
  if (!current) return null;

  db.prepare(
    `UPDATE watchlist_items SET
      notes = ?,
      priority = ?,
      strategy_hint = ?,
      reference_price = ?,
      last_analysis_status = ?,
      last_analysis_score = ?,
      is_active = ?,
      list_name = ?,
      updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
     WHERE id = ?`,
  ).run(
    patch.notes !== undefined ? patch.notes : current.notes,
    patch.priority !== undefined ? patch.priority : current.priority,
    patch.strategyHint !== undefined
      ? patch.strategyHint
      : current.strategyHint,
    toDecimalString(
      patch.referencePrice !== undefined
        ? patch.referencePrice
        : current.referencePrice,
    ),
    patch.lastAnalysisStatus !== undefined
      ? patch.lastAnalysisStatus
      : current.lastAnalysisStatus,
    patch.lastAnalysisScore !== undefined
      ? patch.lastAnalysisScore
      : current.lastAnalysisScore,
    (patch.isActive !== undefined ? patch.isActive : current.isActive) ? 1 : 0,
    patch.listName !== undefined ? patch.listName : current.listName,
    id,
  );
  return getWatchlistItem(id);
}

export function deleteWatchlistItem(id: number): boolean {
  const result = getDb()
    .prepare("DELETE FROM watchlist_items WHERE id = ?")
    .run(id);
  return result.changes > 0;
}

/* ---------- Manual short data ---------- */

interface ShortRow {
  id: number;
  symbol_id: number;
  short_interest_shares: string | null;
  short_interest_percent: string | null;
  days_to_cover: string | null;
  borrow_rate_percent: string | null;
  borrow_availability: string | null;
  reported_at: string | null;
  notes: string | null;
  created_at: string;
}

function mapShort(row: ShortRow): ManualShortData {
  return {
    id: row.id,
    symbolId: row.symbol_id,
    shortInterestShares: fromDecimal(row.short_interest_shares),
    shortInterestPercent: fromDecimal(row.short_interest_percent),
    daysToCover: fromDecimal(row.days_to_cover),
    borrowRatePercent: fromDecimal(row.borrow_rate_percent),
    borrowAvailability: row.borrow_availability,
    reportedAt: row.reported_at,
    notes: row.notes,
    createdAt: row.created_at,
  };
}

export function upsertManualShortData(
  data: ManualShortData,
): ManualShortData {
  const db = getDb();
  const result = db
    .prepare(
      `INSERT INTO manual_short_data
        (symbol_id, short_interest_shares, short_interest_percent, days_to_cover,
         borrow_rate_percent, borrow_availability, reported_at, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      data.symbolId,
      toDecimalString(data.shortInterestShares),
      toDecimalString(data.shortInterestPercent),
      toDecimalString(data.daysToCover),
      toDecimalString(data.borrowRatePercent),
      data.borrowAvailability ?? null,
      data.reportedAt ?? null,
      data.notes ?? null,
    );
  const row = db
    .prepare("SELECT * FROM manual_short_data WHERE id = ?")
    .get(Number(result.lastInsertRowid)) as ShortRow;
  return mapShort(row);
}

export function getLatestShortData(
  symbolId: number,
): ManualShortData | null {
  const row = getDb()
    .prepare(
      `SELECT * FROM manual_short_data
       WHERE symbol_id = ?
       ORDER BY created_at DESC LIMIT 1`,
    )
    .get(symbolId) as ShortRow | undefined;
  return row ? mapShort(row) : null;
}

/* ---------- Analysis runs ---------- */

export function saveAnalysisRun(input: {
  symbolId: number;
  strategyKey: StrategyKey;
  timeframe: Timeframe;
  analysisDate: string;
  status: AnalysisStatus;
  score: number | null;
  resultJson: string;
  dataSourceTime: string | null;
}): AnalysisRun {
  if (!validateTimeframe(input.timeframe)) {
    throw new Error(`Invalid timeframe: ${input.timeframe}`);
  }
  const db = getDb();
  const result = db
    .prepare(
      `INSERT INTO analysis_runs
        (symbol_id, strategy_key, timeframe, analysis_date, status, score, result_json, data_source_time)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      input.symbolId,
      input.strategyKey,
      input.timeframe,
      input.analysisDate,
      input.status,
      input.score,
      input.resultJson,
      input.dataSourceTime,
    );
  const row = db
    .prepare("SELECT * FROM analysis_runs WHERE id = ?")
    .get(Number(result.lastInsertRowid)) as {
    id: number;
    symbol_id: number;
    strategy_key: string;
    timeframe: string;
    analysis_date: string;
    status: string;
    score: number | null;
    result_json: string;
    data_source_time: string | null;
    created_at: string;
  };

  return {
    id: row.id,
    symbolId: row.symbol_id,
    strategyKey: row.strategy_key as StrategyKey,
    timeframe: row.timeframe as Timeframe,
    analysisDate: row.analysis_date,
    status: row.status as AnalysisStatus,
    score: row.score,
    resultJson: row.result_json,
    dataSourceTime: row.data_source_time,
    createdAt: row.created_at,
  };
}

export function getLatestAnalysis(
  symbolId: number,
  strategyKey: StrategyKey,
): AnalysisRun | null {
  const row = getDb()
    .prepare(
      `SELECT * FROM analysis_runs
       WHERE symbol_id = ? AND strategy_key = ?
       ORDER BY created_at DESC LIMIT 1`,
    )
    .get(symbolId, strategyKey) as
    | {
        id: number;
        symbol_id: number;
        strategy_key: string;
        timeframe: string;
        analysis_date: string;
        status: string;
        score: number | null;
        result_json: string;
        data_source_time: string | null;
        created_at: string;
      }
    | undefined;

  if (!row) return null;
  return {
    id: row.id,
    symbolId: row.symbol_id,
    strategyKey: row.strategy_key as StrategyKey,
    timeframe: row.timeframe as Timeframe,
    analysisDate: row.analysis_date,
    status: row.status as AnalysisStatus,
    score: row.score,
    resultJson: row.result_json,
    dataSourceTime: row.data_source_time,
    createdAt: row.created_at,
  };
}

/* ---------- Settings ---------- */

export function getAppSettings(): AppSettings {
  const row = getDb()
    .prepare("SELECT value_json FROM app_settings WHERE key = 'app'")
    .get() as { value_json: string } | undefined;

  if (!row) {
    setAppSettings(DEFAULT_APP_SETTINGS);
    return { ...DEFAULT_APP_SETTINGS };
  }

  try {
    const parsed = JSON.parse(row.value_json) as Partial<AppSettings>;
    return {
      ...DEFAULT_APP_SETTINGS,
      ...parsed,
      reverseSplit: {
        ...DEFAULT_APP_SETTINGS.reverseSplit,
        ...(parsed.reverseSplit || {}),
      },
      afterHoursWave: {
        ...DEFAULT_APP_SETTINGS.afterHoursWave,
        ...(parsed.afterHoursWave || {}),
      },
      weeklyChannel: {
        ...DEFAULT_APP_SETTINGS.weeklyChannel,
        ...(parsed.weeklyChannel || {}),
      },
    };
  } catch {
    return { ...DEFAULT_APP_SETTINGS };
  }
}

export function setAppSettings(settings: AppSettings): AppSettings {
  getDb()
    .prepare(
      `INSERT INTO app_settings (key, value_json, updated_at)
       VALUES ('app', ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
       ON CONFLICT(key) DO UPDATE SET
         value_json = excluded.value_json,
         updated_at = excluded.updated_at`,
    )
    .run(JSON.stringify(settings));
  return getAppSettings();
}

/* ---------- Market cache ---------- */

export function getCache(key: string): {
  payload: string;
  source: string;
  fetchedAt: string;
  expiresAt: string;
} | null {
  const row = getDb()
    .prepare(
      `SELECT payload_json, source, fetched_at, expires_at
       FROM market_cache WHERE cache_key = ?`,
    )
    .get(key) as
    | {
        payload_json: string;
        source: string;
        fetched_at: string;
        expires_at: string;
      }
    | undefined;
  if (!row) return null;
  return {
    payload: row.payload_json,
    source: row.source,
    fetchedAt: row.fetched_at,
    expiresAt: row.expires_at,
  };
}

export function setCache(
  key: string,
  payload: string,
  source: string,
  ttlSeconds: number,
): void {
  const now = new Date();
  const expires = new Date(now.getTime() + ttlSeconds * 1000);
  getDb()
    .prepare(
      `INSERT INTO market_cache (cache_key, payload_json, source, fetched_at, expires_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(cache_key) DO UPDATE SET
         payload_json = excluded.payload_json,
         source = excluded.source,
         fetched_at = excluded.fetched_at,
         expires_at = excluded.expires_at`,
    )
    .run(key, payload, source, now.toISOString(), expires.toISOString());
}

export function isCacheFresh(expiresAt: string): boolean {
  return new Date(expiresAt).getTime() > Date.now();
}
