import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "../../..");
const dbPath = process.env.DATABASE_PATH
  ? path.isAbsolute(process.env.DATABASE_PATH)
    ? process.env.DATABASE_PATH
    : path.join(root, process.env.DATABASE_PATH)
  : path.join(root, "data/pivotscope.db");

fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("foreign_keys = ON");
db.pragma("journal_mode = WAL");
const sql = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
db.exec(sql);
const applied = db.prepare("SELECT 1 AS ok FROM schema_migrations WHERE name = ? LIMIT 1").get("001_initial");
if (!applied) {
  db.prepare("INSERT INTO schema_migrations (name) VALUES (?)").run("001_initial");
}
const rows = db.prepare("SELECT name, applied_at FROM schema_migrations ORDER BY id").all();
console.log("PivotScope migrations:");
for (const row of rows) console.log(`  ✓ ${row.name} @ ${row.applied_at}`);
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all();
console.log("Tables:", tables.map((t) => t.name).join(", "));
db.close();
