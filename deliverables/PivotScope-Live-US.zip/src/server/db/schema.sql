-- PivotScope schema — all timestamps stored as UTC ISO strings
-- Prices stored as TEXT decimals where precision matters; REAL for analytics

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS symbols (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol TEXT NOT NULL COLLATE NOCASE,
  market TEXT NOT NULL DEFAULT 'US',
  company_name TEXT,
  exchange TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(symbol, market)
);

CREATE TABLE IF NOT EXISTS price_bars (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  timeframe TEXT NOT NULL CHECK (timeframe IN ('5m', '15m', '4h', '1d', '1w')),
  bar_time TEXT NOT NULL,
  open TEXT NOT NULL,
  high TEXT NOT NULL,
  low TEXT NOT NULL,
  close TEXT NOT NULL,
  volume TEXT NOT NULL DEFAULT '0',
  vwap TEXT,
  source TEXT NOT NULL DEFAULT 'unknown',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(symbol_id, timeframe, bar_time)
);

CREATE INDEX IF NOT EXISTS idx_price_bars_lookup
  ON price_bars(symbol_id, timeframe, bar_time);

CREATE TABLE IF NOT EXISTS corporate_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL CHECK (action_type IN ('reverse_split', 'split', 'other')),
  action_date TEXT NOT NULL,
  split_ratio TEXT,
  source TEXT NOT NULL DEFAULT 'unknown',
  is_confirmed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_corp_actions_symbol
  ON corporate_actions(symbol_id, action_date);

CREATE TABLE IF NOT EXISTS watchlist_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  list_name TEXT NOT NULL DEFAULT 'default',
  notes TEXT,
  priority INTEGER NOT NULL DEFAULT 0,
  strategy_hint TEXT,
  reference_price TEXT,
  last_analysis_status TEXT,
  last_analysis_score REAL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_watchlist_active
  ON watchlist_items(is_active, priority DESC);

CREATE TABLE IF NOT EXISTS manual_short_data (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  short_interest_shares TEXT,
  short_interest_percent TEXT,
  days_to_cover TEXT,
  borrow_rate_percent TEXT,
  borrow_availability TEXT,
  reported_at TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS analysis_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  symbol_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
  strategy_key TEXT NOT NULL,
  timeframe TEXT NOT NULL CHECK (timeframe IN ('5m', '15m', '4h', '1d', '1w')),
  analysis_date TEXT NOT NULL,
  status TEXT NOT NULL,
  score REAL,
  result_json TEXT NOT NULL,
  data_source_time TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_analysis_runs_lookup
  ON analysis_runs(symbol_id, strategy_key, analysis_date DESC);

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS market_cache (
  cache_key TEXT PRIMARY KEY,
  payload_json TEXT NOT NULL,
  source TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS schema_migrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
