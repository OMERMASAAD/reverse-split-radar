import { NextRequest, NextResponse } from "next/server";
import { fetchBars } from "@/server/services/market-data";
import type { Market, Timeframe } from "@/types";
import { ALLOWED_TIMEFRAMES } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const symbol = (sp.get("symbol") || "").trim().toUpperCase();
  const timeframe = sp.get("timeframe") as Timeframe;
  const market = (sp.get("market") || "US") as Market;
  const forceRefresh = sp.get("refresh") === "1";

  if (!symbol) {
    return NextResponse.json({ error: "رمز مطلوب" }, { status: 400 });
  }
  if (!ALLOWED_TIMEFRAMES.includes(timeframe)) {
    return NextResponse.json(
      { error: "فريم غير مسموح. المسموح: 5m, 15m, 4h, 1d, 1w" },
      { status: 400 },
    );
  }

  try {
    const result = await fetchBars({
      symbol,
      market,
      timeframe,
      forceRefresh,
      from: sp.get("from") || undefined,
      to: sp.get("to") || undefined,
    });
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل جلب الشموع" },
      { status: 502 },
    );
  }
}
