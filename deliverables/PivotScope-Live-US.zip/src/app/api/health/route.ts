import { NextResponse } from "next/server";
import { getDb } from "@/server/db/client";
import { getAppSettings } from "@/server/db/repositories";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const db = getDb();
    const row = db.prepare("SELECT 1 AS ok").get() as { ok: number };
    const settings = getAppSettings();
    return NextResponse.json({
      ok: row.ok === 1,
      provider: settings.dataProvider,
      db: "sqlite",
      time: new Date().toISOString(),
      app: "PivotScope",
    });
  } catch (e) {
    return NextResponse.json(
      {
        ok: false,
        error: e instanceof Error ? e.message : "health failed",
      },
      { status: 500 },
    );
  }
}
