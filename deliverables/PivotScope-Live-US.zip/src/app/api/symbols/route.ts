import { NextRequest, NextResponse } from "next/server";
import {
  listSymbols,
  upsertSymbol,
  getSymbolByTicker,
} from "@/server/db/repositories";
import type { Market } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const symbol = req.nextUrl.searchParams.get("symbol");
  const market = (req.nextUrl.searchParams.get("market") || "US") as Market;
  if (symbol) {
    const s = getSymbolByTicker(symbol, market);
    return NextResponse.json({ symbol: s });
  }
  return NextResponse.json({ symbols: listSymbols(true) });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const symbol = String(body.symbol || "")
      .trim()
      .toUpperCase();
    if (!symbol) {
      return NextResponse.json({ error: "رمز مطلوب" }, { status: 400 });
    }
    const s = upsertSymbol({
      symbol,
      market: (body.market || "US") as Market,
      companyName: body.companyName || null,
      exchange: body.exchange || null,
    });
    return NextResponse.json({ symbol: s }, { status: 201 });
  } catch (e) {
    // Unique constraint etc.
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل" },
      { status: 400 },
    );
  }
}
