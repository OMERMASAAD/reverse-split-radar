import { NextRequest, NextResponse } from "next/server";
import { runAnalysis } from "@/server/services/analysis";
import type { Market, StrategyKey, Timeframe } from "@/types";
import { ALLOWED_TIMEFRAMES } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const STRATEGIES: StrategyKey[] = [
  "reverse_split_support",
  "after_hours_wave",
  "weekly_price_channel",
];
const MARKETS: Market[] = ["US", "SA", "OTHER"];

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const symbol = (sp.get("symbol") || "").trim().toUpperCase();
  const strategy = sp.get("strategy") as StrategyKey;
  const timeframe = (sp.get("timeframe") || undefined) as Timeframe | undefined;
  const market = (sp.get("market") || "US") as Market;
  const demo = sp.get("demo") === "1";

  if (!symbol || symbol.length > 12 || !/^[A-Z0-9.^=_-]+$/.test(symbol)) {
    return NextResponse.json({ error: "رمز غير صالح" }, { status: 400 });
  }
  if (!STRATEGIES.includes(strategy)) {
    return NextResponse.json({ error: "استراتيجية غير معروفة" }, { status: 400 });
  }
  if (!MARKETS.includes(market)) {
    return NextResponse.json({ error: "السوق غير مدعوم" }, { status: 400 });
  }
  if (timeframe && !ALLOWED_TIMEFRAMES.includes(timeframe)) {
    return NextResponse.json({ error: "فريم غير مسموح" }, { status: 400 });
  }

  try {
    const { result, bars } = await runAnalysis({
      symbol,
      market,
      strategy,
      timeframe,
      demo,
    });

    return NextResponse.json({
      result,
      bars: bars || [],
      barsCount: bars?.length || 0,
      demo,
      timeframe: result.timeframe,
      disclaimer:
        "تحليل فني مشروط فقط. ليست توصية تداول ولا أمراً بالشراء أو البيع.",
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل التحليل" },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const url = new URL(req.url);
  if (body.symbol) url.searchParams.set("symbol", body.symbol);
  if (body.strategy) url.searchParams.set("strategy", body.strategy);
  if (body.timeframe) url.searchParams.set("timeframe", body.timeframe);
  if (body.market) url.searchParams.set("market", body.market);
  if (body.demo) url.searchParams.set("demo", "1");
  return GET(new NextRequest(url));
}
