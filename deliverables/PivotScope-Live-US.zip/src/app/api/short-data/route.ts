import { NextRequest, NextResponse } from "next/server";
import {
  upsertSymbol,
  upsertManualShortData,
  getLatestShortData,
} from "@/server/db/repositories";
import type { Market } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get("symbol") || "")
    .trim()
    .toUpperCase();
  const market = (req.nextUrl.searchParams.get("market") || "US") as Market;
  if (!symbol) {
    return NextResponse.json({ error: "رمز مطلوب" }, { status: 400 });
  }
  const sym = upsertSymbol({ symbol, market });
  const data = getLatestShortData(sym.id);
  return NextResponse.json({
    data,
    warning: data ? null : "بيانات الشورت غير متوفرة.",
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const symbol = String(body.symbol || "")
      .trim()
      .toUpperCase();
    if (!symbol) {
      return NextResponse.json({ error: "رمز مطلوب" }, { status: 400 });
    }
    const market = (body.market || "US") as Market;
    const sym = upsertSymbol({ symbol, market });

    // All short fields optional — empty insert must succeed
    const data = upsertManualShortData({
      symbolId: sym.id,
      shortInterestShares:
        body.shortInterestShares != null && body.shortInterestShares !== ""
          ? Number(body.shortInterestShares)
          : null,
      shortInterestPercent:
        body.shortInterestPercent != null && body.shortInterestPercent !== ""
          ? Number(body.shortInterestPercent)
          : null,
      daysToCover:
        body.daysToCover != null && body.daysToCover !== ""
          ? Number(body.daysToCover)
          : null,
      borrowRatePercent:
        body.borrowRatePercent != null && body.borrowRatePercent !== ""
          ? Number(body.borrowRatePercent)
          : null,
      borrowAvailability: body.borrowAvailability ?? null,
      reportedAt: body.reportedAt ?? null,
      notes: body.notes ?? null,
    });

    return NextResponse.json({ data }, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل" },
      { status: 500 },
    );
  }
}
