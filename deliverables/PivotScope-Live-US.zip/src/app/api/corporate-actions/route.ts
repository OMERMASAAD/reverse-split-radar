import { NextRequest, NextResponse } from "next/server";
import { fetchCorporateActions } from "@/server/services/market-data";
import type { Market } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const symbol = (req.nextUrl.searchParams.get("symbol") || "")
    .trim()
    .toUpperCase();
  const market = (req.nextUrl.searchParams.get("market") || "US") as Market;
  if (!symbol) {
    return NextResponse.json({ error: "رمز مطلوب" }, { status: 400 });
  }
  try {
    const result = await fetchCorporateActions(symbol, market);
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل" },
      { status: 502 },
    );
  }
}
