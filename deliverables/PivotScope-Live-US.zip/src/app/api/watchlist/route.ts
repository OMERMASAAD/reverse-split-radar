import { NextRequest, NextResponse } from "next/server";
import {
  listWatchlist,
  addWatchlistItem,
  updateWatchlistItem,
  deleteWatchlistItem,
  upsertSymbol,
} from "@/server/db/repositories";
import type { Market, StrategyKey } from "@/types";
import { sanitizeNotes } from "@/lib/utils/format";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = listWatchlist(true);
  return NextResponse.json({ items });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const symbol = String(body.symbol || "")
      .trim()
      .toUpperCase();
    if (!symbol || symbol.length > 12) {
      return NextResponse.json({ error: "رمز غير صالح" }, { status: 400 });
    }
    const market = (body.market || "US") as Market;
    const sym = upsertSymbol({
      symbol,
      market,
      companyName: body.companyName || null,
    });

    const item = addWatchlistItem({
      symbolId: sym.id,
      listName: body.listName || "default",
      notes: body.notes ? sanitizeNotes(String(body.notes)) : null,
      priority: Number(body.priority) || 0,
      strategyHint: (body.strategyHint as StrategyKey) || null,
      referencePrice:
        body.referencePrice != null && body.referencePrice !== ""
          ? Number(body.referencePrice)
          : null,
    });

    return NextResponse.json({ item }, { status: 201 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل الإضافة" },
      { status: 500 },
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const id = Number(body.id);
    if (!id) {
      return NextResponse.json({ error: "معرّف مطلوب" }, { status: 400 });
    }
    const item = updateWatchlistItem(id, {
      notes:
        body.notes !== undefined
          ? body.notes
            ? sanitizeNotes(String(body.notes))
            : null
          : undefined,
      priority: body.priority !== undefined ? Number(body.priority) : undefined,
      strategyHint:
        body.strategyHint !== undefined ? body.strategyHint : undefined,
      referencePrice:
        body.referencePrice !== undefined
          ? body.referencePrice == null
            ? null
            : Number(body.referencePrice)
          : undefined,
      isActive: body.isActive !== undefined ? Boolean(body.isActive) : undefined,
      listName: body.listName,
      lastAnalysisStatus: body.lastAnalysisStatus,
      lastAnalysisScore: body.lastAnalysisScore,
    });
    if (!item) {
      return NextResponse.json({ error: "غير موجود" }, { status: 404 });
    }
    return NextResponse.json({ item });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل التحديث" },
      { status: 500 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  const id = Number(req.nextUrl.searchParams.get("id"));
  if (!id) {
    return NextResponse.json({ error: "معرّف مطلوب" }, { status: 400 });
  }
  const ok = deleteWatchlistItem(id);
  return NextResponse.json({ ok });
}
