import { NextRequest, NextResponse } from "next/server";
import {
  getAppSettings,
  setAppSettings,
} from "@/server/db/repositories";
import { validateSettings, resetSettings } from "@/lib/validators/settings";
import type { AppSettings } from "@/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const settings = getAppSettings();
  return NextResponse.json({ settings });
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    if (body?.reset === true) {
      const settings = setAppSettings(resetSettings());
      return NextResponse.json({ settings });
    }

    const result = validateSettings(body);
    if (!result.ok) {
      return NextResponse.json(
        { error: "إعدادات غير صالحة", errors: result.errors },
        { status: 400 },
      );
    }

    const settings = setAppSettings(result.data as AppSettings);
    return NextResponse.json({ settings });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "فشل الحفظ" },
      { status: 500 },
    );
  }
}
