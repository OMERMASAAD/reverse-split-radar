"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { EmptyState, LoadingState } from "@/components/ui/EmptyState";
import type { StrategyKey, WatchlistItem } from "@/types";
import { STRATEGY_LABELS_AR } from "@/types";
import { sanitizeNotes } from "@/lib/utils/format";

export default function WatchlistPage() {
  const [items, setItems] = useState<WatchlistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [symbol, setSymbol] = useState("");
  const [notes, setNotes] = useState("");
  const [priority, setPriority] = useState(0);
  const [strategy, setStrategy] = useState<StrategyKey | "">("");
  const [refPrice, setRefPrice] = useState("");
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/watchlist");
      const data = await res.json();
      setItems(data.items || []);
    } catch {
      setError("تعذر تحميل قائمة المتابعة");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function add() {
    setError(null);
    if (!symbol.trim()) {
      setError("أدخل رمزاً صالحاً");
      return;
    }
    const res = await fetch("/api/watchlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbol: symbol.trim().toUpperCase(),
        notes: notes ? sanitizeNotes(notes) : null,
        priority,
        strategyHint: strategy || null,
        referencePrice: refPrice ? Number(refPrice) : null,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "فشل الإضافة");
      return;
    }
    setSymbol("");
    setNotes("");
    setRefPrice("");
    setPriority(0);
    setStrategy("");
    await load();
  }

  async function remove(id: number) {
    await fetch(`/api/watchlist?id=${id}`, { method: "DELETE" });
    await load();
  }

  async function updateNotes(id: number, value: string) {
    await fetch("/api/watchlist", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, notes: sanitizeNotes(value) }),
    });
  }

  return (
    <AppShell title="قائمة المتابعة">
      <div className="mb-4">
        <h2 className="page-title">قائمة المتابعة</h2>
        <p className="page-sub">
          أضف رموزاً مع ملاحظات وأولوية واستراتيجية — ثم افتح التحليل مباشرة.
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader title="إضافة رمز" />
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          <div>
            <label className="label">الرمز</label>
            <input
              className="input"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              placeholder="AAPL"
            />
          </div>
          <div>
            <label className="label">الاستراتيجية</label>
            <select
              className="input"
              value={strategy}
              onChange={(e) =>
                setStrategy(e.target.value as StrategyKey | "")
              }
            >
              <option value="">— بدون —</option>
              <option value="reverse_split_support">
                {STRATEGY_LABELS_AR.reverse_split_support}
              </option>
              <option value="after_hours_wave">
                {STRATEGY_LABELS_AR.after_hours_wave}
              </option>
              <option value="weekly_price_channel">
                {STRATEGY_LABELS_AR.weekly_price_channel}
              </option>
            </select>
          </div>
          <div>
            <label className="label">الأولوية</label>
            <input
              className="input"
              type="number"
              value={priority}
              onChange={(e) => setPriority(Number(e.target.value))}
            />
          </div>
          <div>
            <label className="label">سعر مرجعي</label>
            <input
              className="input"
              type="number"
              step="any"
              value={refPrice}
              onChange={(e) => setRefPrice(e.target.value)}
            />
          </div>
          <div className="md:col-span-2">
            <label className="label">ملاحظات</label>
            <input
              className="input"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={500}
            />
          </div>
        </div>
        {error ? (
          <p className="mt-2 text-sm text-[var(--danger)]">{error}</p>
        ) : null}
        <div className="mt-4">
          <Button type="button" onClick={add}>
            إضافة
          </Button>
        </div>
      </Card>

      {loading ? <LoadingState /> : null}

      {!loading && items.length === 0 ? (
        <EmptyState
          title="القائمة فارغة"
          description="أضف أول رمز للمتابعة."
        />
      ) : null}

      <div className="grid gap-3">
        {items.map((item) => (
          <Card key={item.id}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xl font-black">{item.symbol}</span>
                  <Badge tone="muted">أولوية {item.priority}</Badge>
                  {item.strategyHint ? (
                    <Badge tone="brand">
                      {STRATEGY_LABELS_AR[item.strategyHint]}
                    </Badge>
                  ) : null}
                </div>
                {item.companyName ? (
                  <p className="text-xs text-[var(--text-muted)]">
                    {item.companyName}
                  </p>
                ) : null}
                {item.lastAnalysisStatus ? (
                  <p className="mt-1 text-xs">
                    آخر تحليل: {item.lastAnalysisStatus}
                    {item.lastAnalysisScore != null
                      ? ` · ${item.lastAnalysisScore}`
                      : ""}
                  </p>
                ) : null}
              </div>
              <div className="flex flex-wrap gap-2">
                {item.strategyHint ? (
                  <Link
                    className="btn-primary !py-2 text-xs"
                    href={`/strategies/${pathFor(item.strategyHint)}?symbol=${item.symbol}`}
                  >
                    فتح التحليل
                  </Link>
                ) : (
                  <Link
                    className="btn-ghost !py-2 text-xs"
                    href={`/dashboard?symbol=${item.symbol}`}
                  >
                    لوحة التحكم
                  </Link>
                )}
                <Button
                  variant="danger"
                  type="button"
                  className="!py-2 text-xs"
                  onClick={() => remove(item.id)}
                >
                  حذف
                </Button>
              </div>
            </div>
            <div className="mt-3">
              <label className="label">ملاحظات</label>
              <textarea
                className="input min-h-[64px]"
                defaultValue={item.notes || ""}
                onBlur={(e) => updateNotes(item.id, e.target.value)}
              />
            </div>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}

function pathFor(key: StrategyKey): string {
  switch (key) {
    case "reverse_split_support":
      return "reverse-split";
    case "after_hours_wave":
      return "after-hours-wave";
    case "weekly_price_channel":
      return "weekly-channel";
  }
}
