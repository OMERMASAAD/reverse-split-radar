"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { LoadingState } from "@/components/ui/EmptyState";
import type { AppSettings } from "@/types";
import { DEFAULT_APP_SETTINGS } from "@/types";
import { useTheme } from "@/components/layout/ThemeProvider";

export default function SettingsPage() {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [draft, setDraft] = useState<AppSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const { setTheme } = useTheme();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/settings");
      const data = await res.json();
      setSettings(data.settings);
      setDraft(structuredClone(data.settings));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function save() {
    if (!draft) return;
    setSaving(true);
    setMessage(null);
    setErrors([]);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(draft),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrors(data.errors || [data.error || "فشل الحفظ"]);
        return;
      }
      setSettings(data.settings);
      setDraft(structuredClone(data.settings));
      setTheme(data.settings.theme);
      setMessage("تم حفظ الإعدادات.");
    } finally {
      setSaving(false);
    }
  }

  function cancel() {
    if (settings) setDraft(structuredClone(settings));
    setErrors([]);
    setMessage("تم إلغاء التعديلات.");
  }

  function resetDefaults() {
    setDraft(structuredClone(DEFAULT_APP_SETTINGS));
    setMessage("تمت استعادة القيم الافتراضية (لم تُحفظ بعد).");
  }

  if (loading || !draft) {
    return (
      <AppShell title="الإعدادات">
        <LoadingState />
      </AppShell>
    );
  }

  return (
    <AppShell title="الإعدادات">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="page-title">الإعدادات</h2>
          <p className="page-sub">
            كل النسب والحدود قابلة للتعديل هنا — لا قيم ثابتة داخل منطق الواجهة.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="ghost" type="button" onClick={cancel}>
            إلغاء
          </Button>
          <Button variant="ghost" type="button" onClick={resetDefaults}>
            إعادة الافتراضي
          </Button>
          <Button type="button" onClick={save} disabled={saving}>
            {saving ? "جاري الحفظ..." : "حفظ"}
          </Button>
        </div>
      </div>

      {message ? (
        <div className="mb-4 rounded-xl border border-[var(--brand)]/30 bg-[var(--brand-soft)] px-3 py-2 text-sm font-bold">
          {message}
        </div>
      ) : null}
      {errors.length ? (
        <div className="mb-4 rounded-xl border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-700 dark:text-red-300">
          <ul className="list-disc pr-5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className="space-y-4">
        <Card>
          <CardHeader title="إعدادات عامة" />
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            <Field label="الوضع">
              <select
                className="input"
                value={draft.theme}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    theme: e.target.value as "light" | "dark",
                  })
                }
              >
                <option value="dark">أسود</option>
                <option value="light">أبيض</option>
              </select>
            </Field>
            <Field label="اللغة">
              <input className="input" value="العربية" disabled />
            </Field>
            <Field label="السوق الافتراضي">
              <select
                className="input"
                value={draft.defaultMarket}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    defaultMarket: e.target.value as AppSettings["defaultMarket"],
                  })
                }
              >
                <option value="US">US</option>
                <option value="SA">SA</option>
                <option value="OTHER">OTHER</option>
              </select>
            </Field>
            <Field label="العملة">
              <input
                className="input"
                value={draft.currency}
                onChange={(e) =>
                  setDraft({ ...draft, currency: e.target.value })
                }
              />
            </Field>
            <Field label="المنطقة الزمنية">
              <input
                className="input"
                value={draft.timezone}
                onChange={(e) =>
                  setDraft({ ...draft, timezone: e.target.value })
                }
              />
            </Field>
            <Field label="مصدر البيانات">
              <select
                className="input"
                value={draft.dataProvider}
                onChange={(e) =>
                  setDraft({ ...draft, dataProvider: e.target.value })
                }
              >
                <option value="yahoo">Yahoo Finance (حي)</option>
                <option value="demo">Demo (اصطناعي — للاختبار)</option>
              </select>
            </Field>
            <Field label="مدة التخزين المؤقت (ثوانٍ)">
              <input
                className="input"
                type="number"
                value={draft.cacheTtlSeconds}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    cacheTtlSeconds: Number(e.target.value),
                  })
                }
              />
            </Field>
          </div>
        </Card>

        <Card>
          <CardHeader
            title="ما بعد التقسيم العكسي"
            subtitle="reverse_split_support"
          />
          <NumGrid
            values={draft.reverseSplit}
            onChange={(reverseSplit) => setDraft({ ...draft, reverseSplit })}
            fields={[
              ["splitLookbackMinSessions", "أدنى جلسات بعد التقسيم"],
              ["splitLookbackMaxSessions", "أقصى جلسات بعد التقسيم"],
              ["initialRallyMinPercent", "أدنى ارتفاع أولي %"],
              ["initialRallyMaxPercent", "أقصى ارتفاع أولي %"],
              ["declineMinPercent", "أدنى هبوط من القمة %"],
              ["declineMaxPercent", "أقصى هبوط من القمة %"],
              ["supportSessions", "جلسات ثبات الدعم"],
              ["supportTolerancePercent", "تسامح الدعم %"],
              ["higherLowMinPercent", "أدنى قاع أعلى %"],
              ["breakoutVolumeMultiplier", "مضاعف حجم الاختراق"],
            ]}
          />
        </Card>

        <Card>
          <CardHeader
            title="موجات ما بعد الإغلاق"
            subtitle="after_hours_wave"
          />
          <NumGrid
            values={draft.afterHoursWave}
            onChange={(afterHoursWave) =>
              setDraft({ ...draft, afterHoursWave })
            }
            fields={[
              ["minAfterHoursMovePercent", "أدنى صعود أفتر %"],
              ["minVolumeMultiplier", "مضاعف الحجم"],
              ["premarketObservationMinutes", "بداية نافذة الرصد (د)"],
              ["premarketObservationMaxMinutes", "نهاية نافذة الرصد (د)"],
              ["wave2RetracementMinPercent", "أدنى تصحيح موجة 2 %"],
              ["wave2RetracementMaxPercent", "أقصى تصحيح موجة 2 %"],
              ["wave2InvalidationBufferPercent", "هامش إبطال الموجة 2 %"],
              ["wave3VolumeMultiplier", "مضاعف حجم الموجة 3"],
            ]}
          />
        </Card>

        <Card>
          <CardHeader
            title="القنوات الأسبوعية"
            subtitle="weekly_price_channel"
          />
          <NumGrid
            values={draft.weeklyChannel}
            onChange={(weeklyChannel) =>
              setDraft({ ...draft, weeklyChannel })
            }
            fields={[
              ["minPrice", "أدنى سعر"],
              ["maxPrice", "أقصى سعر"],
              ["minMarketCap", "أدنى قيمة سوقية"],
              ["holdingMinSessions", "أدنى مدة صفقة (جلسات)"],
              ["holdingMaxSessions", "أقصى مدة صفقة (جلسات)"],
              ["channelTouchCount", "عدد لمسات القناة"],
              ["channelTolerancePercent", "تسامح القناة %"],
              ["breakoutConfirmationSessions", "جلسات تأكيد الاختراق"],
            ]}
          />
          <label className="mt-3 flex items-center gap-2 text-sm font-bold">
            <input
              type="checkbox"
              checked={draft.weeklyChannel.allowBreakoutRetestEntry}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  weeklyChannel: {
                    ...draft.weeklyChannel,
                    allowBreakoutRetestEntry: e.target.checked,
                  },
                })
              }
            />
            السماح بدخول إعادة اختبار الاختراق
          </label>
        </Card>

        <Card>
          <CardHeader title="معاينة أثر الإعداد" />
          <pre className="max-h-64 overflow-auto rounded-xl bg-[var(--bg)] p-3 text-[11px] leading-relaxed" dir="ltr">
            {JSON.stringify(draft, null, 2)}
          </pre>
        </Card>
      </div>
    </AppShell>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}

function NumGrid<T extends object>({
  values,
  onChange,
  fields,
}: {
  values: T;
  onChange: (v: T) => void;
  fields: Array<[keyof T & string, string]>;
}) {
  return (
    <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
      {fields.map(([key, label]) => (
        <Field key={key} label={label}>
          <input
            className="input"
            type="number"
            step="any"
            value={Number(values[key as keyof T])}
            onChange={(e) =>
              onChange({ ...values, [key]: Number(e.target.value) })
            }
          />
        </Field>
      ))}
    </div>
  );
}
