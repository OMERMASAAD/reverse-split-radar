"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { LoadingState } from "@/components/ui/EmptyState";
import { STRATEGY_LABELS_AR } from "@/types";
import type { StrategyKey, WatchlistItem } from "@/types";
import { Split, Waves, CandlestickChart, Star } from "lucide-react";

const STRATEGIES: Array<{
  key: StrategyKey;
  href: string;
  icon: typeof Split;
  desc: string;
}> = [
  {
    key: "reverse_split_support",
    href: "/strategies/reverse-split",
    icon: Split,
    desc: "أسهم بعد تقسيم عكسي · دعم · قاع أعلى · اختراق",
  },
  {
    key: "after_hours_wave",
    href: "/strategies/after-hours-wave",
    icon: Waves,
    desc: "موجات بعد صعود الأفتر · 5د / 15د / 4س",
  },
  {
    key: "weekly_price_channel",
    href: "/strategies/weekly-channel",
    icon: CandlestickChart,
    desc: "قناة سعرية أسبوعية · أسهم 5–10$ · قيمة سوقية كبيرة",
  },
];

function DashboardInner() {
  const params = useSearchParams();
  const initialSymbol = params.get("symbol") || "";
  const [symbol, setSymbol] = useState(initialSymbol);
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [health, setHealth] = useState<{
    ok: boolean;
    provider: string;
    db: string;
  } | null>(null);

  const load = useCallback(async () => {
    try {
      const [w, h] = await Promise.all([
        fetch("/api/watchlist").then((r) => r.json()),
        fetch("/api/health").then((r) => r.json()),
      ]);
      if (w.items) setWatchlist(w.items);
      setHealth(h);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (initialSymbol) setSymbol(initialSymbol);
  }, [initialSymbol]);

  const qs = symbol.trim()
    ? `?symbol=${encodeURIComponent(symbol.trim().toUpperCase())}`
    : "";

  return (
    <AppShell title="لوحة التحكم">
      <div className="mb-6">
        <h2 className="page-title">مرحباً بك في PivotScope</h2>
        <p className="page-sub">
          اختر استراتيجية ثم مرّر رمز السهم — التحليل فني مشروط فقط، بلا أوامر
          تداول.
        </p>
      </div>

      <Card className="mb-6">
        <label className="label" htmlFor="dash-sym">
          رمز السهم للتحليل
        </label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            id="dash-sym"
            className="input flex-1"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            placeholder="مثال: AAPL أو RSDEMO (وضع Demo)"
          />
        </div>
        {symbol ? (
          <p className="mt-2 text-xs text-[var(--text-muted)]">
            سيتم ربط الرمز <strong>{symbol}</strong> بصفحات الاستراتيجيات.
          </p>
        ) : null}
      </Card>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        {STRATEGIES.map((s) => {
          const Icon = s.icon;
          return (
            <Link key={s.key} href={`${s.href}${qs}`} className="group">
              <Card className="h-full transition group-hover:-translate-y-0.5 group-hover:shadow-lg">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--brand-soft)] text-[var(--brand)]">
                  <Icon size={22} />
                </div>
                <h3 className="font-black">{STRATEGY_LABELS_AR[s.key]}</h3>
                <p className="mt-2 text-sm text-[var(--text-muted)]">{s.desc}</p>
                <div className="mt-4 text-xs font-bold text-[var(--brand)]">
                  فتح التحليل ←
                </div>
              </Card>
            </Link>
          );
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="قائمة المتابعة السريعة"
            action={
              <Link href="/watchlist" className="btn-ghost !py-1.5 text-xs">
                <Star size={14} /> عرض الكل
              </Link>
            }
          />
          {watchlist.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">
              لا توجد عناصر بعد. أضف رموزاً من صفحة قائمة المتابعة.
            </p>
          ) : (
            <ul className="divide-y divide-[var(--border)]">
              {watchlist.slice(0, 8).map((w) => (
                <li
                  key={w.id}
                  className="flex items-center justify-between gap-3 py-3"
                >
                  <div>
                    <div className="font-black">{w.symbol}</div>
                    <div className="text-xs text-[var(--text-muted)]">
                      {w.companyName || w.listName}
                      {w.strategyHint
                        ? ` · ${STRATEGY_LABELS_AR[w.strategyHint]}`
                        : ""}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {w.lastAnalysisStatus ? (
                      <Badge tone="muted">{w.lastAnalysisStatus}</Badge>
                    ) : null}
                    {w.strategyHint ? (
                      <Link
                        className="btn-ghost !py-1 text-xs"
                        href={`/strategies/${strategyPath(w.strategyHint)}?symbol=${w.symbol}`}
                      >
                        تحليل
                      </Link>
                    ) : null}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <CardHeader title="حالة النظام" />
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between">
              <span className="text-[var(--text-muted)]">الخدمة</span>
              <Badge tone={health?.ok ? "success" : "danger"}>
                {health?.ok ? "تعمل" : "…"}
              </Badge>
            </li>
            <li className="flex justify-between">
              <span className="text-[var(--text-muted)]">مزود البيانات</span>
              <span className="font-bold">{health?.provider || "—"}</span>
            </li>
            <li className="flex justify-between">
              <span className="text-[var(--text-muted)]">قاعدة البيانات</span>
              <span className="font-bold">{health?.db || "—"}</span>
            </li>
          </ul>
          <p className="mt-4 text-[11px] leading-relaxed text-[var(--text-muted)]">
            لا يُنفَّذ شراء أو بيع. النتائج إشارات مشروطة مبنية على بيانات
            موقعة زمنياً. عند نقص البيانات تُعرض تحذيرات بدل إشارات وهمية.
          </p>
        </Card>
      </div>
    </AppShell>
  );
}

function strategyPath(key: StrategyKey): string {
  switch (key) {
    case "reverse_split_support":
      return "reverse-split";
    case "after_hours_wave":
      return "after-hours-wave";
    case "weekly_price_channel":
      return "weekly-channel";
  }
}

export default function DashboardPage() {
  return (
    <Suspense fallback={<AppShell title="لوحة التحكم"><LoadingState /></AppShell>}>
      <DashboardInner />
    </Suspense>
  );
}
