import type { Metadata, Viewport } from "next";
import "@/styles/globals.css";
import { ThemeProvider } from "@/components/layout/ThemeProvider";

export const metadata: Metadata = {
  title: "PivotScope — تحليل فني للأسهم",
  description:
    "منصة عربية لتحليل الأسهم وفق ثلاث استراتيجيات فنية مستقلة. إشارات مشروطة — بدون تنفيذ أوامر.",
  applicationName: "PivotScope",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#071821" },
    { media: "(prefers-color-scheme: light)", color: "#f4f7f6" },
  ],
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className="dark" suppressHydrationWarning>
      <body>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
