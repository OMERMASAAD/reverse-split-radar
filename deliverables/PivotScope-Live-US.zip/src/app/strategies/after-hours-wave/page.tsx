"use client";

import { Suspense } from "react";
import { StrategyPage } from "@/components/strategy/StrategyPage";
import { AppShell } from "@/components/layout/AppShell";
import { LoadingState } from "@/components/ui/EmptyState";

export default function AfterHoursPage() {
  return (
    <Suspense
      fallback={
        <AppShell title="موجات ما بعد الإغلاق">
          <LoadingState />
        </AppShell>
      }
    >
      <StrategyPage strategy="after_hours_wave" />
    </Suspense>
  );
}
