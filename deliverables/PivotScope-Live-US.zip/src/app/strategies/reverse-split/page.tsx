"use client";

import { Suspense } from "react";
import { StrategyPage } from "@/components/strategy/StrategyPage";
import { AppShell } from "@/components/layout/AppShell";
import { LoadingState } from "@/components/ui/EmptyState";

export default function ReverseSplitPage() {
  return (
    <Suspense
      fallback={
        <AppShell title="ما بعد التقسيم العكسي">
          <LoadingState />
        </AppShell>
      }
    >
      <StrategyPage strategy="reverse_split_support" />
    </Suspense>
  );
}
