"use client";

import { Suspense } from "react";
import { StrategyPage } from "@/components/strategy/StrategyPage";
import { AppShell } from "@/components/layout/AppShell";
import { LoadingState } from "@/components/ui/EmptyState";

export default function WeeklyChannelPage() {
  return (
    <Suspense
      fallback={
        <AppShell title="التداول الأسبوعي بالقنوات">
          <LoadingState />
        </AppShell>
      }
    >
      <StrategyPage strategy="weekly_price_channel" />
    </Suspense>
  );
}
