/** PivotScope shared domain types */

export type Timeframe = "5m" | "15m" | "4h" | "1d" | "1w";

export const ALLOWED_TIMEFRAMES: readonly Timeframe[] = [
  "5m",
  "15m",
  "4h",
  "1d",
  "1w",
] as const;

export type StrategyKey =
  | "reverse_split_support"
  | "after_hours_wave"
  | "weekly_price_channel";

export type ThemeMode = "light" | "dark";

export type Market = "US" | "SA" | "OTHER";

export type CorporateActionType = "reverse_split" | "split" | "other";

export type DataQuality = "good" | "partial" | "insufficient" | "stale";

export type AnalysisStatus =
  | "INSUFFICIENT_DATA"
  | "SPLIT_DATA_UNAVAILABLE"
  | "OUTSIDE_SESSION_WINDOW"
  | "INITIAL_RALLY_NOT_MET"
  | "DECLINE_FORMING"
  | "SUPPORT_FORMING"
  | "SUPPORT_CONFIRMED"
  | "TESTING_RESISTANCE_1"
  | "HIGHER_LOW_POSSIBLE"
  | "BREAKOUT_PENDING"
  | "PATTERN_COMPLETE"
  | "PATTERN_FAILED_SUPPORT_BROKEN"
  | "AH_DATA_UNAVAILABLE"
  | "AH_MOVE_INSUFFICIENT"
  | "VOLUME_INSUFFICIENT"
  | "WAITING_OBSERVATION_WINDOW"
  | "WAVE_1_FORMING"
  | "WAVE_2_FORMING"
  | "WAVE_2_DONE_WAVE_3_FORMING"
  | "READY_CONDITIONAL_SIGNAL"
  | "WAVE_3_STARTED"
  | "FAILED_WAVE_2_BROKEN"
  | "PRICE_OUT_OF_RANGE"
  | "MARKET_CAP_UNAVAILABLE"
  | "CHANNEL_UNCLEAR"
  | "NEAR_SUPPORT"
  | "POSSIBLE_BOUNCE"
  | "MID_CHANNEL"
  | "NEAR_RESISTANCE"
  | "RESISTANCE_BREAKOUT"
  | "SUPPORT_BROKEN"
  | "TARGET_HIT"
  | "IDLE"
  | "ERROR";

export interface Symbol {
  id: number;
  symbol: string;
  market: Market;
  companyName: string | null;
  exchange: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PriceBar {
  id?: number;
  symbolId?: number;
  timeframe: Timeframe;
  barTime: string; // ISO UTC
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  vwap: number | null;
  source: string;
  createdAt?: string;
}

export interface CorporateAction {
  id?: number;
  symbolId?: number;
  actionType: CorporateActionType;
  actionDate: string; // ISO date
  splitRatio: number | null; // e.g. 10 means 1-for-10 reverse
  source: string;
  isConfirmed: boolean;
  createdAt?: string;
}

export interface WatchlistItem {
  id: number;
  symbolId: number;
  symbol?: string;
  companyName?: string | null;
  listName: string;
  notes: string | null;
  priority: number;
  strategyHint: StrategyKey | null;
  referencePrice: number | null;
  lastAnalysisStatus: AnalysisStatus | null;
  lastAnalysisScore: number | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ManualShortData {
  id?: number;
  symbolId: number;
  shortInterestShares: number | null;
  shortInterestPercent: number | null;
  daysToCover: number | null;
  borrowRatePercent: number | null;
  borrowAvailability: string | null;
  reportedAt: string | null;
  notes: string | null;
  createdAt?: string;
}

export interface AnalysisRun {
  id: number;
  symbolId: number;
  strategyKey: StrategyKey;
  timeframe: Timeframe;
  analysisDate: string;
  status: AnalysisStatus;
  score: number | null;
  resultJson: string;
  dataSourceTime: string | null;
  createdAt: string;
}

export interface Quote {
  symbol: string;
  market: Market;
  price: number;
  open: number | null;
  high: number | null;
  low: number | null;
  previousClose: number | null;
  volume: number | null;
  currency: string;
  asOf: string;
  source: string;
}

export interface ExtendedQuote {
  symbol: string;
  market: Market;
  premarketPrice: number | null;
  premarketVolume: number | null;
  afterHoursPrice: number | null;
  afterHoursVolume: number | null;
  sessionStart: string | null;
  asOf: string;
  source: string;
  available: boolean;
  message?: string;
}

export interface MarketCap {
  symbol: string;
  market: Market;
  marketCap: number | null;
  currency: string;
  asOf: string;
  source: string;
}

export interface Zone {
  id: string;
  label: string;
  priceLow: number;
  priceHigh: number;
  kind: "support" | "resistance" | "entry" | "target" | "stop";
}

export interface Level {
  id: string;
  label: string;
  price: number;
  kind:
    | "support"
    | "resistance"
    | "entry"
    | "target"
    | "stop"
    | "fibonacci"
    | "ema"
    | "vwap"
    | "split"
    | "wave";
  style?: "solid" | "dashed" | "dotted";
  color?: string;
}

export interface ChartAnnotation {
  levels: Level[];
  zones: Zone[];
  markers: Array<{
    id: string;
    time: string;
    price: number;
    label: string;
    shape?: "circle" | "arrowUp" | "arrowDown" | "square";
  }>;
  fibonacci?: {
    highPrice: number;
    lowPrice: number;
    highTime?: string;
    lowTime?: string;
    levels: number[];
  };
}

export interface AnalysisResult {
  strategy: StrategyKey;
  symbol: string;
  market: Market;
  timeframe: Timeframe;
  status: AnalysisStatus;
  statusLabel: string;
  score: number | null;
  dataQuality: DataQuality;
  lastUpdatedAt: string;
  dataSource: string;
  dataSourceTime: string | null;
  supportZones: Zone[];
  resistanceLevels: Level[];
  entryZones: Zone[];
  stopLoss: Level | null;
  targets: Level[];
  indicators: Record<string, number | null>;
  warnings: string[];
  explanation: string[];
  annotations: ChartAnnotation;
  meta?: Record<string, unknown>;
}

export interface ReverseSplitSettings {
  splitLookbackMinSessions: number;
  splitLookbackMaxSessions: number;
  initialRallyMinPercent: number;
  initialRallyMaxPercent: number;
  declineMinPercent: number;
  declineMaxPercent: number;
  supportSessions: number;
  supportTolerancePercent: number;
  higherLowMinPercent: number;
  breakoutVolumeMultiplier: number;
}

export interface AfterHoursWaveSettings {
  minAfterHoursMovePercent: number;
  minVolumeMultiplier: number;
  premarketObservationMinutes: number;
  premarketObservationMaxMinutes: number;
  wave2RetracementMinPercent: number;
  wave2RetracementMaxPercent: number;
  wave2InvalidationBufferPercent: number;
  wave3VolumeMultiplier: number;
}

export interface WeeklyChannelSettings {
  minPrice: number;
  maxPrice: number;
  minMarketCap: number;
  holdingMinSessions: number;
  holdingMaxSessions: number;
  channelTouchCount: number;
  channelTolerancePercent: number;
  breakoutConfirmationSessions: number;
  allowBreakoutRetestEntry: boolean;
}

export interface AppSettings {
  theme: ThemeMode;
  language: "ar";
  defaultMarket: Market;
  currency: string;
  timezone: string;
  dataProvider: string;
  cacheTtlSeconds: number;
  reverseSplit: ReverseSplitSettings;
  afterHoursWave: AfterHoursWaveSettings;
  weeklyChannel: WeeklyChannelSettings;
}

export const DEFAULT_REVERSE_SPLIT_SETTINGS: ReverseSplitSettings = {
  splitLookbackMinSessions: 20,
  splitLookbackMaxSessions: 50,
  initialRallyMinPercent: 10,
  initialRallyMaxPercent: 20,
  declineMinPercent: 50,
  declineMaxPercent: 60,
  supportSessions: 5,
  supportTolerancePercent: 3,
  higherLowMinPercent: 2,
  breakoutVolumeMultiplier: 1.2,
};

export const DEFAULT_AFTER_HOURS_SETTINGS: AfterHoursWaveSettings = {
  minAfterHoursMovePercent: 30,
  minVolumeMultiplier: 2,
  premarketObservationMinutes: 15,
  premarketObservationMaxMinutes: 30,
  wave2RetracementMinPercent: 38.2,
  wave2RetracementMaxPercent: 61.8,
  wave2InvalidationBufferPercent: 1,
  wave3VolumeMultiplier: 1.2,
};

export const DEFAULT_WEEKLY_CHANNEL_SETTINGS: WeeklyChannelSettings = {
  minPrice: 5,
  maxPrice: 10,
  minMarketCap: 1_000_000_000,
  holdingMinSessions: 2,
  holdingMaxSessions: 7,
  channelTouchCount: 2,
  channelTolerancePercent: 2.5,
  breakoutConfirmationSessions: 1,
  allowBreakoutRetestEntry: true,
};

export const DEFAULT_APP_SETTINGS: AppSettings = {
  theme: "dark",
  language: "ar",
  defaultMarket: "US",
  currency: "USD",
  timezone: "Asia/Riyadh",
  dataProvider: "yahoo",
  cacheTtlSeconds: 300,
  reverseSplit: DEFAULT_REVERSE_SPLIT_SETTINGS,
  afterHoursWave: DEFAULT_AFTER_HOURS_SETTINGS,
  weeklyChannel: DEFAULT_WEEKLY_CHANNEL_SETTINGS,
};

/** Arabic status labels — never use English jargon in UI */
export const STATUS_LABELS_AR: Record<AnalysisStatus, string> = {
  INSUFFICIENT_DATA: "بيانات غير كافية",
  SPLIT_DATA_UNAVAILABLE: "بيانات التقسيم غير متوفرة",
  OUTSIDE_SESSION_WINDOW: "خارج نطاق 20–50 جلسة",
  INITIAL_RALLY_NOT_MET: "ارتفاع أولي غير متحقق",
  DECLINE_FORMING: "هبوط لاحق قيد التكوين",
  SUPPORT_FORMING: "الدعم قيد التكوين",
  SUPPORT_CONFIRMED: "الدعم مؤكد",
  TESTING_RESISTANCE_1: "اختبار المقاومة الأولى",
  HIGHER_LOW_POSSIBLE: "قاع أعلى محتمل",
  BREAKOUT_PENDING: "اختراق قيد الانتظار",
  PATTERN_COMPLETE: "النموذج مكتمل فنياً",
  PATTERN_FAILED_SUPPORT_BROKEN: "النموذج فشل — الدعم مكسور",
  AH_DATA_UNAVAILABLE: "بيانات الأفتر ماركت غير متوفرة",
  AH_MOVE_INSUFFICIENT: "صعود الأفتر غير كافٍ",
  VOLUME_INSUFFICIENT: "الحجم غير كافٍ",
  WAITING_OBSERVATION_WINDOW: "انتظار نافذة 15–30 دقيقة",
  WAVE_1_FORMING: "الموجة الأولى قيد التكوين",
  WAVE_2_FORMING: "الموجة الثانية قيد التكوين",
  WAVE_2_DONE_WAVE_3_FORMING: "الموجة الثانية انتهت — الموجة الثالثة قيد التكوين",
  READY_CONDITIONAL_SIGNAL: "جاهز للمراقبة — إشارة مشروطة",
  WAVE_3_STARTED: "الموجة الثالثة بدأت — اختراق مؤكد",
  FAILED_WAVE_2_BROKEN: "فشل — كسر قاع الموجة الثانية",
  PRICE_OUT_OF_RANGE: "خارج نطاق السعر",
  MARKET_CAP_UNAVAILABLE: "القيمة السوقية غير متوفرة",
  CHANNEL_UNCLEAR: "القناة غير واضحة",
  NEAR_SUPPORT: "قريب من الدعم",
  POSSIBLE_BOUNCE: "ارتداد محتمل",
  MID_CHANNEL: "داخل منتصف القناة",
  NEAR_RESISTANCE: "قريب من المقاومة",
  RESISTANCE_BREAKOUT: "اختراق المقاومة",
  SUPPORT_BROKEN: "كسر الدعم",
  TARGET_HIT: "هدف متحقق",
  IDLE: "بانتظار التحليل",
  ERROR: "خطأ في التحليل",
};

export const STRATEGY_LABELS_AR: Record<StrategyKey, string> = {
  reverse_split_support: "ما بعد التقسيم العكسي",
  after_hours_wave: "موجات ما بعد الإغلاق",
  weekly_price_channel: "التداول الأسبوعي بالقنوات",
};

export const TIMEFRAME_LABELS_AR: Record<Timeframe, string> = {
  "5m": "5 دقائق",
  "15m": "15 دقيقة",
  "4h": "4 ساعات",
  "1d": "يومي",
  "1w": "أسبوعي",
};
