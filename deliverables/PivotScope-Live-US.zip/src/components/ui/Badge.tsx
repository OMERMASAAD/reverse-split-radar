import { cn } from "@/lib/utils/cn";

const tones = {
  brand: "bg-[var(--brand-soft)] text-[var(--brand)]",
  warn: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
  danger: "bg-red-500/15 text-red-700 dark:text-red-300",
  muted: "bg-slate-500/10 text-[var(--text-muted)]",
  success: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
} as const;

export function Badge({
  children,
  tone = "brand",
  className,
}: {
  children: React.ReactNode;
  tone?: keyof typeof tones;
  className?: string;
}) {
  return (
    <span className={cn("badge", tones[tone], className)}>{children}</span>
  );
}
