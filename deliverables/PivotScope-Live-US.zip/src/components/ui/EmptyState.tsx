export function EmptyState({
  title,
  description,
}: {
  title: string;
  description?: string;
}) {
  return (
    <div className="card flex flex-col items-center justify-center gap-2 border-dashed p-10 text-center">
      <p className="text-base font-bold">{title}</p>
      {description ? (
        <p className="max-w-md text-sm text-[var(--text-muted)]">{description}</p>
      ) : null}
    </div>
  );
}

export function LoadingState({ label = "جاري التحميل..." }: { label?: string }) {
  return (
    <div className="flex flex-col gap-3 p-4">
      <div className="skeleton h-8 w-48" />
      <div className="skeleton h-40 w-full" />
      <div className="skeleton h-24 w-full" />
      <p className="text-center text-sm text-[var(--text-muted)]">{label}</p>
    </div>
  );
}

export function ErrorState({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div className="card border-red-500/30 p-6 text-center">
      <p className="font-bold text-[var(--danger)]">حدث خطأ</p>
      <p className="mt-2 text-sm text-[var(--text-muted)]">{message}</p>
      {onRetry ? (
        <button className="btn-primary mt-4" onClick={onRetry} type="button">
          إعادة المحاولة
        </button>
      ) : null}
    </div>
  );
}
