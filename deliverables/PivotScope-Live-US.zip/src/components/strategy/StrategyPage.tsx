"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AppShell } from "@/components/layout/AppShell";
import { CandleChart } from "@/components/chart/CandleChart";
import {
  AnalysisPanel,
  SymbolSearchBar,
} from "@/components/strategy/AnalysisPanel";
import { LoadingState, ErrorState, EmptyState } from "@/components/ui/EmptyState";
import { Button } from "@/components/ui/Button";
import type {
  AnalysisResult,
  PriceBar,
  StrategyKey,
  Timeframe,
  Market,
} from "@/types";
import { STRATEGY_LABELS_AR } from "@/types";

const STRATEGY_TFS: Record<StrategyKey, Timeframe[]> = {
  reverse_split_support: ["1d", "4h", "1w"],
  after_hours_wave: ["5m", "15m", "4h"],
  weekly_price_channel: ["1d", "4h", "1w"],
};

const DEFAULT_TF: Record<StrategyKey, Timeframe> = {
  reverse_split_support: "1d",
  after_hours_wave: "5m",
  weekly_price_channel: "1d",
};

const DEMO_HINT: Record<StrategyKey, string> = {
  reverse_split_support: "RSDEMO",
  after_hours_wave: "AHWAVE",
  weekly_price_channel: "CHANNEL",
};

export function StrategyPage({
  strategy,
  title,
}: {
  strategy: StrategyKey;
  title?: string;
}) {
  const params = useSearchParams();
  const initialSymbol = (params.get("symbol") || "").toUpperCase();
  // Live is the default. Demo is enabled only when the URL explicitly requests it.
  const initialDemo = params.get("demo") === "1";

  const [symbol, setSymbol] = useState(initialSymbol);
  const [demo, setDemo] = useState(initialDemo);
  const [market, setMarket] = useState<Market>("US");
  const [timeframe, setTimeframe] = useState<Timeframe>(DEFAULT_TF[strategy]);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [bars, setBars] = useState<PriceBar[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const booted = useRef(false);
  const lastTf = useRef(timeframe);

  const run = useCallback(
    async (opts?: { symbol?: string; demo?: boolean; timeframe?: Timeframe; market?: Market }) => {
      const sym = (opts?.symbol ?? symbol).trim().toUpperCase();
      const useDemo = opts?.demo ?? demo;
      const tf = opts?.timeframe ?? timeframe;
      const selectedMarket = opts?.market ?? market;
      if (!sym) return;

      setLoading(true);
      setError(null);
      setInfo(null);
      try {
        const q = new URLSearchParams({
          symbol: sym,
          strategy,
          timeframe: tf,
          market: selectedMarket,
          demo: useDemo ? "1" : "0",
        });
        const res = await fetch(`/api/analysis?${q}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "فشل التحليل");

        const nextBars = (data.bars as PriceBar[]) || [];
        const nextResult = data.result as AnalysisResult;

        if (!useDemo && nextResult.status === "ERROR") {
          const providerMessage = nextResult.warnings[0] || "تعذر جلب بيانات السوق الحية.";
          setResult(null);
          setBars([]);
          setError(`${providerMessage} لم يتم استبدال الرمز أو البيانات بوضع Demo.`);
          return;
        }

        setResult(nextResult);
        setBars(nextBars);
        if (nextBars.length === 0 && !useDemo) {
          setInfo("لم يرسل مزود البيانات شموعاً لهذا الرمز/السوق. تحقق من الرمز أو مصدر البيانات؛ لم تُعرض بيانات Demo تلقائياً.");
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "خطأ غير معروف");
        setResult(null);
        setBars([]);
      } finally {
        setLoading(false);
      }
    },
    [symbol, strategy, timeframe, demo, market],
  );

  // Load immediately only when a symbol was supplied in the URL; otherwise wait for entry.
  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    void (async () => {
      let initialMarket: Market = market;
      try {
        const response = await fetch("/api/settings");
        const payload = await response.json();
        if (["US", "SA", "OTHER"].includes(payload.settings?.defaultMarket)) {
          initialMarket = payload.settings.defaultMarket as Market;
          setMarket(initialMarket);
        }
      } catch {
        // Settings endpoint is optional; US remains the safe default.
      }
      await run({ symbol: initialSymbol, demo: initialDemo, market: initialMarket });
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Timeframe change → re-fetch
  useEffect(() => {
    if (!booted.current) return;
    if (lastTf.current === timeframe) return;
    lastTf.current = timeframe;
    if (result) void run({ timeframe });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeframe]);

  async function addToWatchlist() {
    if (!symbol.trim()) return;
    await fetch("/api/watchlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbol: symbol.trim().toUpperCase(),
        market,
        strategyHint: strategy,
        notes: result?.statusLabel || null,
      }),
    });
  }

  const pageTitle = title || STRATEGY_LABELS_AR[strategy];

  return (
    <AppShell title={pageTitle}>
      <div className="mb-4">
        <h2 className="page-title">{pageTitle}</h2>
        <p className="page-sub">
          إشارة مشروطة · تحليل فني · لا يُعد توصية دخول آمن أو مضمون
        </p>
      </div>

      <div className="mb-4">
        <SymbolSearchBar
          symbol={symbol}
          onSymbolChange={setSymbol}
          onAnalyze={() => void run()}
          loading={loading}
          demo={demo}
          onDemoChange={setDemo}
          market={market}
          onMarketChange={setMarket}
        />
        {demo ? (
          <div className="sticky top-0 z-30 mt-2 rounded-xl border border-amber-500/50 bg-amber-100/95 px-3 py-2 text-xs font-black text-amber-900 shadow-sm backdrop-blur dark:bg-amber-950/95 dark:text-amber-100">
            وضع تجريبي — البيانات مصطنعة ولا تصلح لاتخاذ قرار تداول · مثال بصري فقط. الرمز المقترح:{" "}
            <button
              type="button"
              className="underline"
              onClick={() => {
                const s = DEMO_HINT[strategy];
                setSymbol(s);
                void run({ symbol: s, demo: true });
              }}
            >
              {DEMO_HINT[strategy]}
            </button>
          </div>
        ) : (
          <div className="mt-2 rounded-xl border border-[var(--border)] px-3 py-2 text-xs text-[var(--text-muted)]">
            وضع Live — إن فشل المزود لن تُخترع أسعار؛ يمكنك تفعيل Demo لرؤية
            الشارت.
          </div>
        )}
        {info ? (
          <div className="mt-2 rounded-xl border border-sky-500/40 bg-sky-500/10 px-3 py-2 text-xs font-bold text-sky-900 dark:text-sky-200">
            {info}
          </div>
        ) : null}
      </div>

      {loading ? (
        <LoadingState label="جاري جلب الشموع وتشغيل المحرك..." />
      ) : null}
      {error ? <ErrorState message={error} onRetry={() => void run()} /> : null}

      {!loading && !error && !result ? (
        <EmptyState
          title="ابدأ بتحليل رمز"
          description={`اضغط «تشغيل التحليل». للتجربة: ${DEMO_HINT[strategy]} + وضع Demo.`}
        />
      ) : null}

      {result && !loading ? (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Button variant="ghost" type="button" onClick={addToWatchlist}>
              إضافة للمتابعة
            </Button>
            <Button variant="ghost" type="button" onClick={() => void run()}>
              تحديث الشارت
            </Button>
            <Button
              variant="primary"
              type="button"
              onClick={() => {
                const s = DEMO_HINT[strategy];
                setDemo(true);
                setSymbol(s);
                void run({ symbol: s, demo: true });
              }}
            >
              عرض شموع Demo
            </Button>
          </div>

          <CandleChart
            bars={bars}
            annotations={result.annotations}
            timeframe={timeframe}
            timeframes={STRATEGY_TFS[strategy]}
            onTimeframeChange={setTimeframe}
            height={460}
            sourceLabel={
              result.dataSource
                ? `المصدر: ${result.dataSource === "demo" ? "Demo" : result.dataSource} · ${bars.length} شمعة`
                : `${bars.length} شمعة`
            }
          />

          {bars.length === 0 ? (
            <div className="card border-amber-500/40 p-4 text-sm">
              الشارت فارغ لأن مصفوفة الشموع فارغة. اضغط «عرض شموع Demo» أعلاه.
            </div>
          ) : null}

          <AnalysisPanel result={result} isDemo={demo} />
        </div>
      ) : null}
    </AppShell>
  );
}
