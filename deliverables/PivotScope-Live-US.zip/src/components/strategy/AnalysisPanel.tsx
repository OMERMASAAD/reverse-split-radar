"use client";

import type { AnalysisResult, Market } from "@/types";
import { Badge } from "@/components/ui/Badge";
import { Card, CardHeader } from "@/components/ui/Card";
import { formatDateTime, formatPrice, formatPercent } from "@/lib/utils/format";

function statusTone(
  status: string,
): "brand" | "warn" | "danger" | "success" | "muted" {
  if (
    status.includes("FAILED") ||
    status.includes("BROKEN") ||
    status === "ERROR"
  )
    return "danger";
  if (
    status.includes("COMPLETE") ||
    status.includes("STARTED") ||
    status.includes("CONFIRMED") ||
    status.includes("BOUNCE")
  )
    return "success";
  if (
    status.includes("INSUFFICIENT") ||
    status.includes("UNAVAILABLE") ||
    status.includes("OUTSIDE") ||
    status.includes("OUT_OF")
  )
    return "muted";
  if (status.includes("CONDITIONAL") || status.includes("PENDING") || status.includes("FORMING"))
    return "warn";
  return "brand";
}

export function AnalysisPanel({ result, isDemo = false }: { result: AnalysisResult; isDemo?: boolean }) {
  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="text-xs text-[var(--text-muted)]">الحالة الفنية</div>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <Badge tone={isDemo ? "muted" : statusTone(result.status)}>{isDemo ? "مثال بصري فقط" : result.statusLabel}</Badge>
              {result.score != null ? (
                <span className="text-2xl font-black text-[var(--brand)]">
                  {result.score}
                  <span className="text-sm font-bold text-[var(--text-muted)]">
                    /100
                  </span>
                </span>
              ) : (
                <span className="text-sm text-[var(--text-muted)]">بدون درجة</span>
              )}
            </div>
          </div>
          <div className="text-left text-[11px] text-[var(--text-muted)] leading-relaxed">
            <div>المصدر: {result.dataSource}</div>
            <div>نوع البيانات: {isDemo ? "تجريبية" : "Live / من المصدر"}</div>
            <div>حالة التأخر: {dataDelayLabel(result.dataSourceTime)}</div>
            <div>جودة البيانات: {dataQualityAr(result.dataQuality)}</div>
            <div>آخر تحديث: {formatDateTime(result.lastUpdatedAt)}</div>
            {result.dataSourceTime ? (
              <div>وقت البيانات: {formatDateTime(result.dataSourceTime)}</div>
            ) : null}
          </div>
        </div>
      </Card>

      {result.warnings.length > 0 ? (
        <Card className="border-amber-500/30">
          <CardHeader title="تحذيرات" />
          <ul className="space-y-1.5 text-sm text-amber-800 dark:text-amber-200">
            {result.warnings.map((w, i) => (
              <li key={i} className="flex gap-2">
                <span>⚠</span>
                <span>{w}</span>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}

      <Card>
        <CardHeader title="الشرح" subtitle="سبب النتيجة — إشارة مشروطة" />
        <ul className="space-y-2 text-sm leading-relaxed">
          {result.explanation.map((line, i) => (
            <li key={i} className="flex gap-2">
              <span className="text-[var(--brand)]">•</span>
              <span>{isDemo ? line.replace(/جاهز للدخول|إشارة مؤكدة|شراء|النموذج مكتمل فنياً/gi, "مثال بصري فقط") : line}</span>
            </li>
          ))}
        </ul>
      </Card>

      {result.strategy === "reverse_split_support" ? (
        <Card className="border-emerald-500/30 bg-emerald-500/[0.04]">
          <CardHeader title="تسلسل نموذج ما بعد التقسيم" subtitle="تتبع القاعين واختبار المقاومة والدعم الرئيسي" />
          <ol className="grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
            {[
              "القاع الأول بعد موجة الهبوط",
              "القاع الثاني / إعادة اختبار القاع",
              "اختبار أقرب مقاومة",
              "إعادة اختبار القاع المزدوج أو القاع الرئيسي",
            ].map((step, i) => (
              <li key={step} className="flex items-start gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg)] p-3">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--brand)] text-xs font-black text-white">{i + 1}</span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
          <ul className="mt-3 space-y-1 text-xs leading-relaxed text-[var(--text-muted)]">
            {result.explanation
              .filter((line) => /القاع الأول|القاع الثاني|أقرب مقاومة|يعيد اختبار منطقة القاع/.test(line))
              .map((line) => <li key={line}>• {line}</li>)}
          </ul>
          {result.status === "PATTERN_COMPLETE" ? (
            <p className="mt-3 rounded-lg bg-emerald-500/10 p-2 text-sm font-bold text-emerald-700 dark:text-emerald-300">اكتمل النموذج وفق شروط التحليل الحالية؛ راجع مستويات القيعان والمقاومة أعلاه.</p>
          ) : null}
        </Card>
      ) : null}

      {result.strategy === "after_hours_wave" ? (
        <Card className="border-violet-500/30 bg-violet-500/[0.035]">
          <CardHeader title="حالة الموجة والمحَفّز" subtitle="تأكيد متعدد الفريمات؛ فريم 5 دقائق وحده لا يكفي" />
          <dl className="grid gap-3 text-sm sm:grid-cols-2">
            <div><dt className="text-xs text-[var(--text-muted)]">الحالة</dt><dd className="mt-1 font-black">{isDemo ? "مثال بصري فقط" : waveStatusAr(result.status, result.statusLabel)}</dd></div>
            <div><dt className="text-xs text-[var(--text-muted)]">الجاهزية</dt><dd className="mt-1 font-bold">{isDemo ? "مثال بصري فقط" : result.status === "WAVE_3_STARTED" ? "اختراق حدث — تحقّق من البيانات الحية" : "جاهز للمراقبة — إشارة مشروطة"}</dd></div>
            <div className="sm:col-span-2"><dt className="text-xs text-[var(--text-muted)]">المحفز المطلوب</dt><dd className="mt-1">إغلاق شمعة 5 دقائق فوق المقاومة الأولى مع حجم أعلى من المتوسط، وبشرط تأكيد 15 دقيقة و4 ساعات.</dd></div>
            <div><dt className="text-xs text-[var(--text-muted)]">منطقة الدخول</dt><dd className="mt-1 font-black">{result.entryZones[0] ? `${formatPrice(result.entryZones[0].priceLow)} — ${formatPrice(result.entryZones[0].priceHigh)}` : "غير محددة"}</dd></div>
            <div><dt className="text-xs text-[var(--text-muted)]">وقف الخسارة</dt><dd className="mt-1 font-black">{result.stopLoss ? formatPrice(result.stopLoss.price) : "—"}</dd></div>
            {result.targets.slice(0, 2).map((target, i) => <div key={target.id}><dt className="text-xs text-[var(--text-muted)]">الهدف {i + 1}</dt><dd className="mt-1 font-black">{formatPrice(target.price)}</dd></div>)}
          </dl>
        </Card>
      ) : null}

      <div className="grid gap-4 md:grid-cols-3">
        <LevelsCard
          title="مناطق الدخول"
          items={result.entryZones.map((z) => ({
            label: z.label,
            value: `${formatPrice(z.priceLow)} – ${formatPrice(z.priceHigh)}`,
          }))}
        />
        <LevelsCard
          title="الأهداف"
          items={result.targets.map((t) => ({
            label: t.label,
            value: formatPrice(t.price),
          }))}
        />
        <LevelsCard
          title="وقف الخسارة والدعم/المقاومة"
          items={[
            result.stopLoss
              ? {
                  label: result.stopLoss.label,
                  value: formatPrice(result.stopLoss.price),
                }
              : null,
            ...result.supportZones.map((z) => ({
              label: z.label,
              value: `${formatPrice(z.priceLow)} – ${formatPrice(z.priceHigh)}`,
            })),
            ...result.resistanceLevels.map((r) => ({
              label: r.label,
              value: formatPrice(r.price),
            })),
          ].filter(Boolean) as Array<{ label: string; value: string }>}
        />
      </div>

      <Card>
        <CardHeader title="المؤشرات" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {Object.entries(result.indicators).map(([k, v]) => (
            <div
              key={k}
              className="rounded-xl border border-[var(--border)] bg-[var(--bg)] p-3"
            >
              <div className="text-[10px] font-bold text-[var(--text-muted)]">
                {indicatorLabel(k)}
              </div>
              <div className="mt-1 text-sm font-black">
                {v == null ? "—" : k === "rsi14" ? v.toFixed(1) : formatPrice(v)}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function LevelsCard({
  title,
  items,
}: {
  title: string;
  items: Array<{ label: string; value: string }>;
}) {
  return (
    <Card>
      <CardHeader title={title} />
      {items.length === 0 ? (
        <p className="text-sm text-[var(--text-muted)]">لا توجد مستويات بعد.</p>
      ) : (
        <ul className="space-y-2">
          {items.map((it, i) => (
            <li
              key={i}
              className="flex items-center justify-between gap-2 text-sm"
            >
              <span className="text-[var(--text-muted)]">{it.label}</span>
              <span className="font-black">{it.value}</span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function waveStatusAr(status: string, fallback: string): string {
  if (status === "WAVE_2_FORMING") return "الموجة الثانية ما زالت قيد التكوين";
  if (status === "WAVE_2_DONE_WAVE_3_FORMING") return "الموجة الثانية انتهت — الموجة الثالثة قيد التكوين";
  if (status === "WAVE_3_STARTED") return "بداية الموجة الثالثة بعد الاختراق";
  if (status === "FAILED_WAVE_2_BROKEN") return "كسر قاع الموجة الثانية — فشل النموذج";
  return fallback;
}

function dataDelayLabel(sourceTime: string | null): string {
  if (!sourceTime) return "وقت المصدر غير متوفر";
  const ageMinutes = Math.max(0, (Date.now() - new Date(sourceTime).getTime()) / 60000);
  if (!Number.isFinite(ageMinutes)) return "غير معروف";
  if (ageMinutes > 30) return `متأخرة (${Math.round(ageMinutes)} دقيقة)`;
  return "حديثة";
}

function dataQualityAr(q: string): string {
  switch (q) {
    case "good":
      return "جيدة";
    case "partial":
      return "جزئية";
    case "stale":
      return "قديمة";
    default:
      return "غير كافية";
  }
}

function indicatorLabel(k: string): string {
  const map: Record<string, string> = {
    ema20: "EMA 20",
    ema30: "EMA 30",
    ema50: "EMA 50",
    rsi14: "RSI 14",
    vwap: "VWAP",
  };
  return map[k] || k;
}

export function SymbolSearchBar({
  symbol,
  onSymbolChange,
  onAnalyze,
  loading,
  demo,
  onDemoChange,
  market,
  onMarketChange,
}: {
  symbol: string;
  onSymbolChange: (s: string) => void;
  onAnalyze: () => void;
  loading?: boolean;
  demo?: boolean;
  onDemoChange?: (v: boolean) => void;
  market: Market;
  onMarketChange: (market: Market) => void;
}) {
  return (
    <div className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
      <div className="flex-1">
        <label className="label" htmlFor="sym">
          رمز السهم
        </label>
        <input
          id="sym"
          className="input"
          value={symbol}
          onChange={(e) => onSymbolChange(e.target.value.toUpperCase())}
          placeholder="مثال: AAPL أو 2222"
          onKeyDown={(e) => e.key === "Enter" && onAnalyze()}
        />
      </div>
      <div className="sm:w-40">
        <label className="label" htmlFor="market">السوق</label>
        <select id="market" className="input" value={market} onChange={(e) => onMarketChange(e.target.value as Market)}>
          <option value="US">أمريكا</option>
          <option value="SA">السعودية</option>
          <option value="OTHER">أخرى</option>
        </select>
      </div>
      {onDemoChange ? (
        <label className="flex items-center gap-2 text-sm font-bold">
          <input
            type="checkbox"
            checked={!!demo}
            onChange={(e) => onDemoChange(e.target.checked)}
          />
          وضع Demo
        </label>
      ) : null}
      <button
        type="button"
        className="btn-primary"
        onClick={onAnalyze}
        disabled={loading || !symbol.trim()}
      >
        {loading ? "جاري التحليل..." : "تشغيل التحليل"}
      </button>
    </div>
  );
}

// silence unused import warning if tree-shaken oddly
void formatPercent;
