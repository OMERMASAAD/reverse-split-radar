"use client";

import { Menu, Moon, Sun, Search } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useTheme } from "@/components/layout/ThemeProvider";

export function Topbar({
  title,
  onMenu,
}: {
  title?: string;
  onMenu: () => void;
}) {
  const { theme, toggle } = useTheme();
  const router = useRouter();
  const [symbol, setSymbol] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const s = symbol.trim().toUpperCase();
    if (!s) return;
    router.push(`/dashboard?symbol=${encodeURIComponent(s)}`);
  }

  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-[var(--border)] bg-[var(--bg)]/90 px-3 py-3 backdrop-blur md:px-6">
      <button
        type="button"
        className="btn-ghost !px-2.5 md:hidden"
        onClick={onMenu}
        aria-label="فتح القائمة"
      >
        <Menu size={18} />
      </button>

      <div className="min-w-0 flex-1">
        <h1 className="truncate text-base font-black md:text-lg">
          {title || "PivotScope"}
        </h1>
      </div>

      <form onSubmit={submit} className="hidden items-center gap-2 sm:flex">
        <div className="relative">
          <Search
            size={14}
            className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
          />
          <input
            className="input !py-2 pr-9 w-40 md:w-52"
            placeholder="رمز السهم..."
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            aria-label="بحث عن رمز"
          />
        </div>
        <button type="submit" className="btn-primary !py-2">
          تحليل
        </button>
      </form>

      <button
        type="button"
        className="btn-ghost !px-2.5"
        onClick={toggle}
        aria-label={theme === "dark" ? "الوضع الفاتح" : "الوضع الداكن"}
        title={theme === "dark" ? "الوضع الفاتح" : "الوضع الداكن"}
      >
        {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
      </button>
    </header>
  );
}
