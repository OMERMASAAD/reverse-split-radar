"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils/cn";
import {
  LayoutDashboard,
  Split,
  Waves,
  CandlestickChart,
  Star,
  Settings,
  X,
} from "lucide-react";

const NAV = [
  { href: "/dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  {
    href: "/strategies/reverse-split",
    label: "ما بعد التقسيم العكسي",
    icon: Split,
  },
  {
    href: "/strategies/after-hours-wave",
    label: "موجات ما بعد الإغلاق",
    icon: Waves,
  },
  {
    href: "/strategies/weekly-channel",
    label: "القنوات الأسبوعية",
    icon: CandlestickChart,
  },
  { href: "/watchlist", label: "قائمة المتابعة", icon: Star },
  { href: "/settings", label: "الإعدادات", icon: Settings },
];

export function Sidebar({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const pathname = usePathname();

  return (
    <>
      {/* Mobile overlay */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/50 transition md:hidden",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        onClick={onClose}
        aria-hidden
      />

      <aside
        className={cn(
          "fixed bottom-0 top-0 z-50 flex w-72 flex-col border-l border-[var(--border)] transition-transform md:static md:z-0 md:translate-x-0",
          "bg-[var(--bg-sidebar)] text-[#e8f4f1]",
          open ? "translate-x-0" : "translate-x-full md:translate-x-0",
        )}
        style={{ right: 0 }}
      >
        <div className="flex items-center justify-between gap-3 border-b border-white/10 px-5 py-5">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-amber-300 to-amber-600 text-lg font-black text-[#10252b]">
              PS
            </div>
            <div>
              <div className="text-[11px] font-bold tracking-wide text-amber-300">
                ANALYTICS
              </div>
              <div className="text-lg font-black">PivotScope</div>
            </div>
          </div>
          <button
            type="button"
            className="rounded-lg p-2 hover:bg-white/10 md:hidden"
            onClick={onClose}
            aria-label="إغلاق القائمة"
          >
            <X size={18} />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {NAV.map((item) => {
            const active =
              pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold transition",
                  active
                    ? "bg-[var(--brand)] text-white shadow-lg"
                    : "text-[#c5d9d6] hover:bg-white/10 hover:text-white",
                )}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-white/10 p-4 text-[11px] leading-relaxed text-[#8eada8]">
          تحليل فني مشروط · لا أوامر تداول
          <br />
          Paper signals only
        </div>
      </aside>
    </>
  );
}
