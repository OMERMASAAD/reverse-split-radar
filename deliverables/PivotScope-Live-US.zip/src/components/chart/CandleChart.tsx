"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { PriceBar, ChartAnnotation, Timeframe, Level } from "@/types";
import { TIMEFRAME_LABELS_AR } from "@/types";
import { cn } from "@/lib/utils/cn";

interface Props {
  bars: PriceBar[];
  annotations?: ChartAnnotation | null;
  timeframe: Timeframe;
  timeframes?: Timeframe[];
  onTimeframeChange?: (tf: Timeframe) => void;
  height?: number;
  className?: string;
  sourceLabel?: string;
}

type LC = typeof import("lightweight-charts");

/**
 * Professional candlestick chart (TradingView lightweight-charts).
 * - Smooth pan / zoom (mouse + touch)
 * - Fib labels: short % on the right axis only — no clutter on the plot
 * - No floating OHLC tooltip that follows the mouse
 */
export function CandleChart({
  bars,
  annotations,
  timeframe,
  timeframes = ["5m", "15m", "4h", "1d", "1w"],
  onTimeframeChange,
  height = 480,
  className,
  sourceLabel,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<import("lightweight-charts").IChartApi | null>(null);
  const seriesRef = useRef<
    import("lightweight-charts").ISeriesApi<"Candlestick"> | null
  >(null);
  const volumeRef = useRef<import("lightweight-charts").ISeriesApi<"Histogram"> | null>(null);
  const rsiRef = useRef<import("lightweight-charts").ISeriesApi<"Line"> | null>(null);
  const emaRefs = useRef<Array<import("lightweight-charts").ISeriesApi<"Line">>>([]);
  const projectionRef = useRef<import("lightweight-charts").ISeriesApi<"Line"> | null>(null);
  const projectionMarkersRef = useRef<import("lightweight-charts").ISeriesMarkersPluginApi<import("lightweight-charts").Time> | null>(null);
  const volumeAverageRef = useRef<import("lightweight-charts").ISeriesApi<"Line"> | null>(null);
  const barsRef = useRef<PriceBar[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [darkTheme, setDarkTheme] = useState(false);
  const [layers, setLayers] = useState({
    ema: true,
    fib: true,
    zones: true,
    levels: true,
    volume: true,
    rsi: true,
    vwap: true,
    price: true,
  });
  // Selected bar via click only (not mouse-follow)
  const [picked, setPicked] = useState<PriceBar | null>(null);
  const [entryBand, setEntryBand] = useState<{ top: number; height: number } | null>(null);

  const cleanBars = useMemo(() => sanitizeBars(bars), [bars]);
  barsRef.current = cleanBars;

  const candleData = useMemo(() => {
    const seen = new Set<number>();
    const out: Array<{
      time: import("lightweight-charts").UTCTimestamp;
      open: number;
      high: number;
      low: number;
      close: number;
    }> = [];
    for (const b of cleanBars) {
      const t = Math.floor(new Date(b.barTime).getTime() / 1000);
      if (!Number.isFinite(t) || seen.has(t)) continue;
      seen.add(t);
      out.push({
        time: t as import("lightweight-charts").UTCTimestamp,
        open: b.open,
        high: b.high,
        low: b.low,
        close: b.close,
      });
    }
    return out;
  }, [cleanBars]);

  useEffect(() => {
    const syncTheme = () => setDarkTheme(document.documentElement.classList.contains("dark"));
    syncTheme();
    const observer = new MutationObserver(syncTheme);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);

  // Mount chart once per size/theme
  useEffect(() => {
    if (!containerRef.current) return;
    let disposed = false;
    let ro: ResizeObserver | null = null;
    let chart: import("lightweight-charts").IChartApi | null = null;

    async function mount() {
      try {
        const lc: LC = await import("lightweight-charts");
        if (disposed || !containerRef.current) return;

        const el = containerRef.current;
        el.innerHTML = "";

        const isDark = document.documentElement.classList.contains("dark");

        chart = lc.createChart(el, {
          width: el.clientWidth,
          height,
          layout: {
            background: { color: isDark ? "#0b1c24" : "#f7faf9" },
            textColor: isDark ? "#9db4b0" : "#4a6369",
            fontFamily: "Tahoma, Arial, sans-serif",
            fontSize: 11,
            attributionLogo: false,
          },
          grid: {
            vertLines: {
              color: isDark ? "rgba(26,51,64,0.85)" : "rgba(220,231,228,0.9)",
            },
            horzLines: {
              color: isDark ? "rgba(26,51,64,0.85)" : "rgba(220,231,228,0.9)",
            },
          },
          rightPriceScale: {
            borderColor: isDark ? "#1a3340" : "#d0ddd9",
            scaleMargins: { top: 0.08, bottom: 0.08 },
            entireTextOnly: false,
          },
          leftPriceScale: { visible: false },
          timeScale: {
            borderColor: isDark ? "#1a3340" : "#d0ddd9",
            timeVisible:
              timeframe === "5m" ||
              timeframe === "15m" ||
              timeframe === "4h",
            secondsVisible: false,
            rightOffset: 6,
            barSpacing: defaultBarSpacing(timeframe),
            minBarSpacing: 2,
            fixLeftEdge: false,
            fixRightEdge: false,
          },
          crosshair: {
            mode: lc.CrosshairMode.Normal,
            vertLine: {
              color: isDark ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.15)",
              width: 1,
              style: lc.LineStyle.Dashed,
              labelVisible: true,
            },
            horzLine: {
              color: isDark ? "rgba(255,255,255,0.18)" : "rgba(0,0,0,0.15)",
              width: 1,
              style: lc.LineStyle.Dashed,
              labelVisible: true,
            },
          },
          handleScroll: {
            mouseWheel: true,
            pressedMouseMove: true,
            horzTouchDrag: true,
            vertTouchDrag: true,
          },
          handleScale: {
            axisPressedMouseMove: { time: true, price: true },
            axisDoubleClickReset: true,
            mouseWheel: true,
            pinch: true,
          },
          kineticScroll: {
            touch: true,
            mouse: true,
          },
        });

        const series = chart.addSeries(lc.CandlestickSeries, {
          upColor: "#0f9d7a",
          downColor: "#e05a52",
          borderUpColor: "#0f9d7a",
          borderDownColor: "#e05a52",
          wickUpColor: "#0f9d7a",
          wickDownColor: "#e05a52",
          borderVisible: true,
          priceLineVisible: false,
          lastValueVisible: true,
        });

        const volumePane = chart.addPane();
        const rsiPane = chart.addPane();
        volumePane.setHeight(Math.max(70, Math.round(height * 0.18)));
        rsiPane.setHeight(Math.max(75, Math.round(height * 0.2)));
        const volumeSeries = chart.addSeries(lc.HistogramSeries, {
          priceFormat: { type: "volume" },
          priceScaleId: "",
          lastValueVisible: false,
          priceLineVisible: false,
        }, 1);
        const volumeAverage = chart.addSeries(lc.LineSeries, {
          color: "#d6a441",
          lineWidth: 2,
          priceScaleId: "",
          lastValueVisible: false,
          priceLineVisible: false,
          crosshairMarkerVisible: false,
        }, 1);
        chart.priceScale("", 1).applyOptions({ scaleMargins: { top: 0.12, bottom: 0 } });
        const rsiSeries = chart.addSeries(lc.LineSeries, {
          color: "#3b82f6",
          lineWidth: 2,
          priceLineVisible: false,
          lastValueVisible: true,
          autoscaleInfoProvider: () => ({ priceRange: { minValue: 0, maxValue: 100 } }),
        }, 2);
        chart.priceScale("right", 2).applyOptions({ scaleMargins: { top: 0.08, bottom: 0.08 } });
        const rsi30 = chart.addSeries(lc.LineSeries, { color: "#94a3b8", lineStyle: lc.LineStyle.Dashed, lineWidth: 1, priceLineVisible: false, lastValueVisible: false }, 2);
        const rsi40 = chart.addSeries(lc.LineSeries, { color: "#d6a441", lineStyle: lc.LineStyle.Dotted, lineWidth: 1, priceLineVisible: false, lastValueVisible: false }, 2);
        const rsi50 = chart.addSeries(lc.LineSeries, { color: "#94a3b8", lineStyle: lc.LineStyle.Dashed, lineWidth: 1, priceLineVisible: false, lastValueVisible: false }, 2);
        volumeRef.current = volumeSeries;
        volumeAverageRef.current = volumeAverage;
        rsiRef.current = rsiSeries;
        (rsiSeries as unknown as { __thresholds: typeof rsi30[] }).__thresholds = [rsi30, rsi40, rsi50];
        const ema20 = chart.addSeries(lc.LineSeries, { color: "#3b82f6", lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        const ema30 = chart.addSeries(lc.LineSeries, { color: "#d6a441", lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        const ema50 = chart.addSeries(lc.LineSeries, { color: "#8b5cf6", lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
        const projection = chart.addSeries(lc.LineSeries, { color: "#7c5cbf", lineWidth: 2, lineStyle: lc.LineStyle.Dashed, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
        projectionRef.current = projection;
        projectionMarkersRef.current = lc.createSeriesMarkers(projection, []);
        emaRefs.current = [ema20, ema30, ema50];

        chartRef.current = chart;
        seriesRef.current = series;
        setReady(true);
        setError(null);

        // Click picks a bar (static panel) — no mouse-follow tooltip
        chart.subscribeClick((param) => {
          if (!param.time) {
            setPicked(null);
            return;
          }
          const t =
            typeof param.time === "number"
              ? param.time
              : typeof param.time === "string"
                ? Math.floor(new Date(param.time).getTime() / 1000)
                : null;
          if (t == null) {
            setPicked(null);
            return;
          }
          const bar = barsRef.current.find(
            (b) => Math.floor(new Date(b.barTime).getTime() / 1000) === t,
          );
          setPicked((prev) => {
            // toggle off if same bar clicked again
            if (
              prev &&
              Math.floor(new Date(prev.barTime).getTime() / 1000) === t
            ) {
              return null;
            }
            return bar || null;
          });
        });

        ro = new ResizeObserver(() => {
          if (!chart || !el) return;
          chart.applyOptions({ width: el.clientWidth, height });
        });
        ro.observe(el);
      } catch (e) {
        setError(e instanceof Error ? e.message : "فشل تحميل الشارت");
        setReady(false);
      }
    }

    void mount();

    return () => {
      disposed = true;
      ro?.disconnect();
      if (chart) {
        chart.remove();
      }
      chartRef.current = null;
      seriesRef.current = null;
      volumeRef.current = null;
      volumeAverageRef.current = null;
      rsiRef.current = null;
      emaRefs.current = [];
      projectionRef.current = null;
      projectionMarkersRef.current = null;
      setReady(false);
    };
    // re-create when theme-related height/timeframe visibility needs fresh chart
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [height, darkTheme]);

  // Update timeframe time visibility without full remount when possible
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    chart.applyOptions({
      timeScale: {
        timeVisible:
          timeframe === "5m" || timeframe === "15m" || timeframe === "4h",
        barSpacing: defaultBarSpacing(timeframe),
      },
    });
  }, [timeframe]);

  // Push candle data
  useEffect(() => {
    const series = seriesRef.current;
    const chart = chartRef.current;
    if (!series || !chart || !ready) return;
    if (candleData.length === 0) {
      series.setData([]);
      return;
    }
    series.applyOptions({ visible: layers.price });
    series.setData(candleData);
    // Fit a sensible window (last ~80–120 bars) like TradingView default
    const visible = Math.min(
      candleData.length,
      timeframe === "5m" || timeframe === "15m"
        ? 100
        : timeframe === "4h"
          ? 90
          : 80,
    );
    const from = candleData[Math.max(0, candleData.length - visible)].time;
    const to = candleData[candleData.length - 1].time;
    try {
      chart.timeScale().setVisibleRange({ from, to });
    } catch {
      chart.timeScale().fitContent();
    }
    const projected = projectionRef.current;
    const entry = annotations?.zones?.find((z) => z.kind === "entry");
    const targets = annotations?.levels.filter((l) => l.kind === "target").sort((a, b) => a.price - b.price) || [];
    if (projected && entry && targets.length >= 2 && candleData.length > 1) {
      const step = Math.max(60, Number(candleData.at(-1)!.time) - Number(candleData.at(-2)!.time));
      const wave2Marker = annotations?.markers.find((m) => m.label === "②" || m.label.includes("قاع"));
      const start = wave2Marker ? Math.floor(new Date(wave2Marker.time).getTime() / 1000) : Number(candleData.at(-1)!.time);
      const projectionStart = Math.max(start, Number(candleData.at(-1)!.time) - step * 3);
      const entryMid = (entry.priceLow + entry.priceHigh) / 2;
      const endTime = (Number(candleData.at(-1)!.time) + step * 2) as import("lightweight-charts").UTCTimestamp;
      projected.setData([
        { time: projectionStart as import("lightweight-charts").UTCTimestamp, value: entryMid },
        { time: (Number(candleData.at(-1)!.time) + step) as import("lightweight-charts").UTCTimestamp, value: targets[0].price },
        { time: endTime, value: targets[1].price },
      ]);
      projectionMarkersRef.current?.setMarkers([{ time: endTime, position: "aboveBar", color: "#7c5cbf", shape: "arrowUp", text: "" }]);
    } else {
      projected?.setData([]);
      projectionMarkersRef.current?.setMarkers([]);
    }
    const closes = cleanBars.map((b) => b.close);
    const volumes = cleanBars.map((b) => b.volume || 0);
    const emaValues = [20, 30, 50].map((period) => ema(closes, period));
    emaRefs.current.forEach((line, seriesIndex) => {
      line.applyOptions({ visible: layers.ema });
      line.setData(candleData.map((c, i) => ({ time: c.time, value: emaValues[seriesIndex][i] })).filter((p) => Number.isFinite(p.value)));
    });
    volumeRef.current?.applyOptions({ visible: layers.volume });
    volumeAverageRef.current?.applyOptions({ visible: layers.volume });
    volumeRef.current?.setData(candleData.map((c, i) => ({ time: c.time, value: volumes[i], color: cleanBars[i].close >= cleanBars[i].open ? "rgba(15,157,122,0.55)" : "rgba(224,90,82,0.55)" })));
    volumeAverageRef.current?.setData(candleData.map((c, i) => ({ time: c.time, value: volumes.slice(Math.max(0, i - 19), i + 1).reduce((sum, v) => sum + v, 0) / Math.min(i + 1, 20) })));
    const rsiValues = rsi(closes, 14);
    rsiRef.current?.applyOptions({ visible: layers.rsi });
    rsiRef.current?.setData(candleData.map((c, i) => ({ time: c.time, value: rsiValues[i] })).filter((p) => Number.isFinite(p.value)));
    const thresholdLines = (rsiRef.current as unknown as { __thresholds?: Array<import("lightweight-charts").ISeriesApi<"Line">> } | null)?.__thresholds || [];
    [30, 40, 50].forEach((v, n) => thresholdLines[n]?.setData(candleData.map((c) => ({ time: c.time, value: v }))));
    setPicked(null);
  }, [candleData, cleanBars, annotations, ready, timeframe, layers.ema, layers.volume, layers.rsi, layers.price]);

  // Annotations / price lines
  useEffect(() => {
    const series = seriesRef.current;
    if (!series || !ready) return;

    // Clear previous lines by recreating series data path:
    // lightweight-charts has no removeAllPriceLines — track via recreate options
    // Work around: store lines on series via custom property
    const prev =
      (
        series as unknown as {
          __psLines?: Array<import("lightweight-charts").IPriceLine>;
        }
      ).__psLines || [];
    for (const pl of prev) {
      try {
        series.removePriceLine(pl);
      } catch {
        /* ignore */
      }
    }
    const lines: Array<import("lightweight-charts").IPriceLine> = [];

    void import("lightweight-charts").then((lc) => {
      const plotted: Array<{ price: number; title: string }> = [];
      let fixedLabelCount = 0;
      const fixedLabelYs: number[] = [];
      const add = (
        price: number,
        title: string,
        color: string,
        style: number,
        axisLabel: boolean,
      ) => {
        if (!Number.isFinite(price)) return;
        const near = plotted.find((p) => Math.abs(p.price - price) <= Math.max(Math.abs(price) * 0.00015, 0.000001));
        if (near) {
          if ((/مقاومة/.test(near.title) && /الهدف الأول|هدف 1/.test(title)) || (/هدف 1/.test(near.title) && /مقاومة/.test(title))) {
            near.title = "المقاومة الأولى / الهدف 1";
            const prior = lines[plotted.indexOf(near)];
            try { series.removePriceLine(prior); } catch { /* already removed */ }
            lines[plotted.indexOf(near)] = series.createPriceLine({ price: near.price, color, lineWidth: 1, lineStyle: style, axisLabelVisible: true, title: near.title });
          }
          return;
        }
        const item = { price, title };
        plotted.push(item);
        const labelY = series.priceToCoordinate(price);
        const hasVerticalRoom = labelY == null || fixedLabelYs.every((y) => Math.abs(y - labelY) >= 18);
        const showAxisLabel = axisLabel && fixedLabelCount < 5 && hasVerticalRoom;
        if (showAxisLabel) {
          fixedLabelCount += 1;
          if (labelY != null) fixedLabelYs.push(labelY);
        }
        const pl = series.createPriceLine({
          price,
          color,
          lineWidth: 1,
          lineStyle: style,
          axisLabelVisible: showAxisLabel,
          title,
        });
        lines.push(pl);
      };

      if (annotations && layers.levels) {
        for (const lvl of annotations.levels) {
          if (!layers.ema && lvl.kind === "ema") continue;
          if (!layers.vwap && lvl.kind === "vwap") continue;
          if (!layers.fib && lvl.kind === "fibonacci") continue;

          const isFib = lvl.kind === "fibonacci";
          // Fib: short % title only on the RIGHT axis label — keeps plot clean
          const title = isFib
            ? fibShort(lvl.label)
            : levelTitle(lvl);

          const color =
            lvl.color ||
            (lvl.kind === "support"
              ? "#0f9d7a"
              : lvl.kind === "stop"
                ? "#e05a52"
                : lvl.kind === "target"
                  ? "#d6a441"
                  : lvl.kind === "resistance"
                    ? "#e05a52"
                    : isFib
                      ? "#8b7cf0"
                      : "#7a9298");

          const style =
            isFib || lvl.style === "dashed"
              ? lc.LineStyle.Dashed
              : lvl.style === "dotted"
                ? lc.LineStyle.Dotted
                : lc.LineStyle.Solid;

          // Fib: axis label only (title short). Others: title on axis too.
          add(lvl.price, title, color, style, !isFib);
        }
      }

      if (annotations && layers.zones) {
        for (const z of annotations.zones) {
          const color =
            z.kind === "support"
              ? "rgba(15,157,122,0.65)"
              : z.kind === "entry"
                ? "rgba(124,92,191,0.85)"
                : "rgba(224,90,82,0.55)";
          // Show zone edges, while the entry band itself is shaded in the plot.
          add(z.priceLow, shortZone(z.label), color, lc.LineStyle.Dashed, true);
          add(z.priceHigh, "", color, lc.LineStyle.Dashed, false);
        }
      }

      // First/second low and resistance markers are rendered as chart-native pins.
      if (annotations?.markers?.length && candleData.length) {
        const mark = (async () => {
          const { createSeriesMarkers } = await import("lightweight-charts");
          if (!seriesRef.current) return;
          const markerData = annotations.markers.flatMap((m) => {
            const t = Math.floor(new Date(m.time).getTime() / 1000);
            const time = candleData.find((c) => Number(c.time) === t)?.time;
            if (!time) return [];
            const isLow = m.label.includes("قاع") || m.label === "②";
            return [{
              time,
              position: isLow ? "belowBar" as const : "aboveBar" as const,
              color: isLow ? "#0f9d7a" : "#e05a52",
              shape: isLow ? "arrowUp" as const : "arrowDown" as const,
              text: shortMarker(m.label),
            }];
          });
          createSeriesMarkers(seriesRef.current, markerData, { zOrder: "top" });
        })();
        void mark;
      }

      (
        series as unknown as {
          __psLines?: Array<import("lightweight-charts").IPriceLine>;
        }
      ).__psLines = lines;
    });
  }, [annotations, layers, ready, candleData]);

  // Keep a shaded entry strip aligned with the visible price scale.
  useEffect(() => {
    const chart = chartRef.current;
    const series = seriesRef.current;
    const zone = annotations?.zones?.find((z) => z.kind === "entry");
    if (!chart || !series || !zone || !layers.zones) {
      setEntryBand(null);
      return;
    }
    const update = () => {
      const y1 = series.priceToCoordinate(zone.priceHigh);
      const y2 = series.priceToCoordinate(zone.priceLow);
      if (y1 == null || y2 == null) {
        setEntryBand(null);
        return;
      }
      setEntryBand({ top: Math.min(y1, y2), height: Math.max(3, Math.abs(y2 - y1)) });
    };
    update();
    chart.timeScale().subscribeVisibleLogicalRangeChange(update);
    const timer = window.setInterval(update, 350);
    return () => {
      chart.timeScale().unsubscribeVisibleLogicalRangeChange(update);
      window.clearInterval(timer);
    };
  }, [annotations, layers.zones, ready, candleData]);

  function zoomIn() {
    const chart = chartRef.current;
    if (!chart) return;
    const ts = chart.timeScale();
    const spacing = (ts.options().barSpacing || 8) * 1.25;
    ts.applyOptions({ barSpacing: Math.min(48, spacing) });
  }

  function zoomOut() {
    const chart = chartRef.current;
    if (!chart) return;
    const ts = chart.timeScale();
    const spacing = (ts.options().barSpacing || 8) * 0.8;
    ts.applyOptions({ barSpacing: Math.max(2, spacing) });
  }

  function fitAll() {
    chartRef.current?.timeScale().fitContent();
  }

  function fitRecent() {
    const chart = chartRef.current;
    if (!chart || candleData.length === 0) return;
    const n = Math.min(candleData.length, 60);
    const from = candleData[candleData.length - n].time;
    const to = candleData[candleData.length - 1].time;
    try {
      chart.timeScale().setVisibleRange({ from, to });
    } catch {
      chart.timeScale().fitContent();
    }
  }

  return (
    <div className={cn("card overflow-hidden p-0", className)}>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] px-2 py-2 sm:px-3">
        <div className="flex flex-wrap gap-1">
          {timeframes.map((tf) => (
            <button
              key={tf}
              type="button"
              className={cn(
                "rounded-md px-2.5 py-1 text-[11px] font-bold transition sm:rounded-lg",
                tf === timeframe
                  ? "bg-[var(--brand)] text-white"
                  : "bg-[var(--bg)] text-[var(--text-muted)] hover:text-[var(--text)]",
              )}
              onClick={() => onTimeframeChange?.(tf)}
            >
              {TIMEFRAME_LABELS_AR[tf]}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-1 text-[11px]">
          <div className="flex items-center rounded-lg border border-[var(--border)] p-0.5">
            <ToolBtn title="تكبير" onClick={zoomIn}>
              ＋
            </ToolBtn>
            <ToolBtn title="تصغير" onClick={zoomOut}>
              －
            </ToolBtn>
            <ToolBtn title="الكل" onClick={fitAll}>
              الكل
            </ToolBtn>
            <ToolBtn title="حديث" onClick={fitRecent}>
              حديث
            </ToolBtn>
          </div>

          {(
            [
              ["ema", "متوسط"],
              ["fib", "نسب"],
              ["zones", "مناطق"],
              ["levels", "خطوط"],
              ["volume", "حجم"],
              ["rsi", "RSI"],
              ["vwap", "VWAP"],
              ["price", "السعر"],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              className={cn(
                "rounded-full border px-2 py-0.5 font-bold",
                layers[key]
                  ? "border-[var(--brand)] text-[var(--brand)]"
                  : "border-[var(--border)] text-[var(--text-muted)]",
              )}
              onClick={() => setLayers((l) => ({ ...l, [key]: !l[key] }))}
            >
              {label}
            </button>
          ))}

          <span className="hidden text-[var(--text-muted)] sm:inline">
            {sourceLabel || (cleanBars.length ? `${cleanBars.length} شمعة` : "")}
          </span>
        </div>
      </div>

      {/* Chart body */}
      {error ? (
        <div className="flex h-[320px] items-center justify-center text-sm text-[var(--danger)]">
          {error}
        </div>
      ) : cleanBars.length === 0 ? (
        <div className="flex h-[320px] flex-col items-center justify-center gap-2 px-6 text-center text-sm text-[var(--text-muted)]">
          <p className="font-bold text-[var(--text)]">لا توجد شموع للعرض</p>
          <p>
            فعّل <strong>وضع Demo</strong> وجرب{" "}
            <code className="rounded bg-[var(--bg)] px-1">RSDEMO</code>
          </p>
        </div>
      ) : (
        <div className="relative w-full" style={{ height }}>
          <div className="flex h-full w-full">
            <div
              ref={containerRef}
              className="h-full min-w-0 flex-1 touch-pan-x"
              style={{ height }}
            />
            {layers.fib && fibLegendItems(annotations).length > 0 ? (
              <aside className="flex w-[62px] shrink-0 flex-col justify-center gap-1 border-l border-[var(--border)] bg-[var(--bg)]/70 px-1 sm:w-[88px] sm:px-2">
                {fibLegendItems(annotations).map((it) => (
                  <div key={it.label} title={`فيبوناتشي ${it.label} · ${fmt(it.price)}`} className="truncate rounded-md border border-violet-400/30 bg-violet-500/10 px-1 py-1 text-center text-[9px] font-bold text-violet-700 dark:text-violet-300 sm:text-[11px]" dir="ltr">
                    {it.label}
                  </div>
                ))}
              </aside>
            ) : null}
          </div>
          {entryBand ? (
            <div
              className="pointer-events-none absolute left-0 right-[62px] z-[2] border-y border-violet-500/70 bg-violet-500/20 sm:right-[88px]"
              style={{ top: entryBand.top, height: entryBand.height }}
            >
              <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-md bg-violet-700/90 px-2 py-0.5 text-[10px] font-black text-white">
                دخول
              </span>
            </div>
          ) : null}

          {/* Static OHLC — only after click, not mouse-follow */}
          {picked ? (
            <div className="pointer-events-none absolute left-2 top-2 z-10 max-w-[90%] rounded-lg border border-[var(--border)] bg-[var(--bg-elevated)]/95 px-2.5 py-1.5 text-[11px] shadow-md backdrop-blur-sm sm:left-3 sm:top-3">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 font-bold">
                <span className="text-[var(--text-muted)] font-normal">
                  {new Date(picked.barTime).toLocaleString("ar-SA", {
                    month: "short",
                    day: "numeric",
                    hour:
                      timeframe === "1d" || timeframe === "1w"
                        ? undefined
                        : "2-digit",
                    minute:
                      timeframe === "5m" || timeframe === "15m"
                        ? "2-digit"
                        : undefined,
                  })}
                </span>
                <span>
                  O <b dir="ltr">{fmt(picked.open)}</b>
                </span>
                <span>
                  H <b dir="ltr">{fmt(picked.high)}</b>
                </span>
                <span>
                  L <b dir="ltr">{fmt(picked.low)}</b>
                </span>
                <span
                  className={
                    picked.close >= picked.open
                      ? "text-emerald-600 dark:text-emerald-400"
                      : "text-red-600 dark:text-red-400"
                  }
                >
                  C <b dir="ltr">{fmt(picked.close)}</b>
                </span>
              </div>
              <div className="mt-0.5 text-[10px] text-[var(--text-muted)]">
                اضغط على الشارت للإغلاق أو اختيار شمعة أخرى
              </div>
            </div>
          ) : null}

          <div className="pointer-events-none absolute bottom-1 left-2 hidden text-[10px] text-[var(--text-muted)] sm:block">
            سحب للتحريك · عجلة/قرصة للتكبير · نقرة لقراءة الشمعة
          </div>
        </div>
      )}

      {/* Fib legend — placed BELOW chart so plot stays clean */}
      <div className="flex flex-wrap items-center gap-2 border-t border-[var(--border)] px-3 py-2 text-[11px]">
        <span className="rounded-full bg-[var(--bg)] px-2 py-1 font-bold">السعر</span>
        <span className="rounded-full bg-blue-500/10 px-2 py-1 font-bold text-blue-600">EMA20</span>
        <span className="rounded-full bg-amber-500/10 px-2 py-1 font-bold text-amber-600">EMA30</span>
        <span className="rounded-full bg-violet-500/10 px-2 py-1 font-bold text-violet-600">EMA50</span>
        <span className="rounded-full bg-slate-500/10 px-2 py-1 font-bold">VWAP</span>
        <span className="rounded-full bg-violet-500/10 px-2 py-1 font-bold text-violet-600">فيبوناتشي</span>
        <span className="mr-auto text-[var(--text-muted)]">الفريم الحالي: {TIMEFRAME_LABELS_AR[timeframe]}</span>
      </div>
      <div className="flex flex-wrap items-center gap-3 border-t border-[var(--border)] px-3 py-2 text-[11px]">
        <span className="font-bold text-[var(--text-muted)]">الحجم ومتوسط 20 شمعة:</span>
        {cleanBars.length ? (() => {
          const recent = cleanBars.at(-1)?.volume || 0;
          const avg = cleanBars.slice(-20).reduce((sum, b) => sum + (b.volume || 0), 0) / Math.max(1, cleanBars.slice(-20).length);
          const ratio = avg > 0 ? recent / avg : null;
          return <span>{ratio == null ? "بيانات الحجم غير متوفرة" : `الحجم: ${ratio.toFixed(1)}× من متوسط 20 شمعة`}</span>;
        })() : <span>بيانات الحجم غير متوفرة</span>}
        <span className="text-[var(--text-muted)]">RSI 14: {cleanBars.length >= 15 ? `${rsi(cleanBars.map(b => b.close), 14).at(-1)?.toFixed(1)} · ${(() => { const values = rsi(cleanBars.map(b => b.close), 14); const now = values.at(-1); const prev = values.at(-2); return now != null && prev != null && now < 40 && now > prev ? "RSI يتحسن من التشبع البيعي" : "RSI لم يؤكد الدخول بعد"; })()}` : "البيانات غير كافية"}</span>
      </div>
      {layers.fib && fibLegendItems(annotations).length > 0 ? (
        <div className="flex flex-wrap items-center gap-2 border-t border-[var(--border)] px-3 py-2 text-[11px]">
          <span className="font-bold text-[var(--text-muted)]">النسب:</span>
          {fibLegendItems(annotations).map((it) => (
            <span
              key={it.label}
              className="inline-flex items-center gap-1 rounded-full border border-violet-400/40 bg-violet-500/10 px-2 py-0.5 font-bold text-violet-700 dark:text-violet-300"
              dir="ltr"
            >
              <i
                className="inline-block h-0.5 w-3 rounded"
                style={{ background: it.color }}
              />
              {it.label}
              <span className="font-normal text-[var(--text-muted)]">
                {fmt(it.price)}
              </span>
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function ToolBtn({
  children,
  onClick,
  title,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className="rounded-md px-2 py-0.5 font-black hover:bg-[var(--bg)] active:scale-95"
    >
      {children}
    </button>
  );
}

function sanitizeBars(bars: PriceBar[] | undefined): PriceBar[] {
  const seen = new Set<string>();
  const out: PriceBar[] = [];
  const sorted = [...(bars || [])].sort(
    (a, b) => new Date(a.barTime).getTime() - new Date(b.barTime).getTime(),
  );
  for (const b of sorted) {
    if (!b?.barTime) continue;
    if (
      ![b.open, b.high, b.low, b.close].every(
        (n) => typeof n === "number" && Number.isFinite(n),
      )
    ) {
      continue;
    }
    const high = Math.max(b.high, b.open, b.close, b.low);
    const low = Math.min(b.low, b.open, b.close, b.high);
    if (seen.has(b.barTime)) continue;
    seen.add(b.barTime);
    out.push({ ...b, high, low });
  }
  return out;
}

function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const out: number[] = [];
  values.forEach((v, i) => out.push(i === 0 ? v : v * k + out[i - 1] * (1 - k)));
  return out;
}

function rsi(values: number[], period: number): number[] {
  const out = Array(values.length).fill(NaN) as number[];
  if (values.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const delta = values[i] - values[i - 1];
    gain += Math.max(0, delta);
    loss += Math.max(0, -delta);
  }
  let avgGain = gain / period, avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < values.length; i++) {
    const delta = values[i] - values[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(0, delta)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(0, -delta)) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

function defaultBarSpacing(tf: Timeframe): number {
  if (tf === "5m" || tf === "15m") return 7;
  if (tf === "4h") return 8;
  if (tf === "1w") return 10;
  return 8;
}

function fmt(v: number): string {
  if (!Number.isFinite(v)) return "—";
  if (Math.abs(v) >= 100) return v.toFixed(2);
  if (Math.abs(v) >= 1) return v.toFixed(3);
  return v.toFixed(4);
}

/** "50%" only */
function fibShort(label: string): string {
  const m = label.match(/(\d+(?:\.\d+)?)\s*%/);
  if (m) return `${m[1]}%`;
  return label.replace(/فيبوناتشي\s*/gi, "").trim() || label;
}

function shortMarker(label: string): string {
  if (label.includes("الموجة 3") || label === "③") return "③";
  if (label.includes("القمة الأولى") || label === "①") return "①";
  if (label.includes("قاع") || label.includes("الموجة 2") || label === "②") return "②";
  return label.length > 8 ? label.slice(0, 8) : label;
}

function levelTitle(lvl: Level): string {
  if (lvl.kind === "target") {
    if (/الأول|1/.test(lvl.label)) return "هدف 1";
    if (/الثاني|2/.test(lvl.label)) return "هدف 2";
    return "هدف";
  }
  if (lvl.kind === "stop") return "وقف";
  if (lvl.kind === "resistance") {
    if (/الثاني|2/.test(lvl.label)) return "مقاومة 2";
    return "مقاومة 1";
  }
  // Short Arabic names without trailing prices
  const base = lvl.label
    .replace(/\s*[\d.]+\s*$/, "")
    .replace(/فيبوناتشي\s*/gi, "")
    .trim();
  // Keep EMA / VWAP short
  if (lvl.kind === "ema" || lvl.kind === "vwap") return lvl.label;
  // Cap length so axis doesn't overflow
  return base.length > 14 ? base.slice(0, 14) : base;
}

function shortZone(label: string): string {
  if (label.includes("دخول")) return "دخول";
  if (label.includes("دعم")) return "دعم";
  if (label.includes("مقاوم")) return "مقاومة";
  return label.slice(0, 10);
}

function fibLegendItems(
  ann: ChartAnnotation | null | undefined,
): Array<{ label: string; price: number; color: string }> {
  if (!ann?.levels) return [];
  return ann.levels
    .filter((l) => l.kind === "fibonacci")
    .map((l) => ({
      label: fibShort(l.label),
      price: l.price,
      color: l.color || "#8b7cf0",
    }));
}
