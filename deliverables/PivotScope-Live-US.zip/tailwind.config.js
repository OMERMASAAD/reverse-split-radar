/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef9f6",
          100: "#d5f0e9",
          200: "#aee1d4",
          300: "#7ccbb8",
          400: "#4aaf98",
          500: "#118476",
          600: "#0d6b61",
          700: "#0c564f",
          800: "#0c4541",
          900: "#0b3a37",
          950: "#05211f",
        },
        surface: {
          light: "#f4f7f6",
          dark: "#071821",
          card: "#ffffff",
          "card-dark": "#0f2a33",
        },
      },
      fontFamily: {
        sans: ["Tahoma", "Arial", "Segoe UI", "sans-serif"],
      },
      boxShadow: {
        card: "0 8px 28px rgba(7, 40, 50, 0.08)",
        "card-dark": "0 8px 28px rgba(0, 0, 0, 0.35)",
      },
    },
  },
  plugins: [],
};
