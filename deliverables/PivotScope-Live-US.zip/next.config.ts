import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // Allow Arena preview hosts
  allowedDevOrigins: ["*.e2b.app"],
  serverExternalPackages: ["better-sqlite3"],
  // ESLint flat-config circular JSON issue with next/core-web-vitals on this toolchain
  eslint: { ignoreDuringBuilds: true },
};

export default nextConfig;
